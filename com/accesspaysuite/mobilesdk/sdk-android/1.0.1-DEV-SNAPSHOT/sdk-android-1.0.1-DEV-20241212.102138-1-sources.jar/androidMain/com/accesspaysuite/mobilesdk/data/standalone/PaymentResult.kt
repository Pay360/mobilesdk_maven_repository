package com.accesspaysuite.mobilesdk.data.standalone

import com.accesspaysuite.mobilesdk.data.standalone.PaymentResult.Canceled
import com.accesspaysuite.mobilesdk.data.standalone.PaymentResult.Failed
import com.accesspaysuite.mobilesdk.data.standalone.PaymentResult.Success
import kotlinx.serialization.Serializable

/**
 * ## PaymentResult
 *
 * This sealed class is used to represent the result of a payment from the
 * Standalone Payment Page.
 * It can be one of the following:
 * - [Success]
 * - [Failed] with a reason
 * - [Canceled]
 */
@Serializable
sealed class PaymentResult {

    /**
     * ## Success
     * This object represents a successful payment.
     */
    @Serializable
    data object Success : PaymentResult() {
        /**
         * @suppress
         */
        override fun toString(): String {
            return "Success"
        }
    }

    /**
     * ## Failed
     * This object represents a failed payment.
     * @property reason The reason for the failed payment
     */
    @Serializable
    data class Failed(val reason: String?) : PaymentResult() {
        /**
         * @suppress
         */
        override fun toString(): String {
            return reason.toString()
        }
    }

    /**
     * ## Canceled
     * This object represents a canceled payment.
     */
    @Serializable
    data object Canceled : PaymentResult() {
        /**
         * @suppress
         */
        override fun toString(): String {
            return "Canceled"
        }
    }

}
