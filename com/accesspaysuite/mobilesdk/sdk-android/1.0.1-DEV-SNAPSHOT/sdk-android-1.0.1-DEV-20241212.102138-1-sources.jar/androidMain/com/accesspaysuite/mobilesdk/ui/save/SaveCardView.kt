package com.accesspaysuite.mobilesdk.ui.save

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Save card view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
@OptIn(ExperimentalMobileUI::class)
class SaveCardView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf(SaveCardState())

    private var callback by mutableStateOf<((isChecked: Boolean) -> Unit)?>(null)

    init {
        addComposable {
            SaveCardBox(state = state)
        }
    }

    /**
     * Init
     *
     * @param state
     * @param onCheck
     */
    fun init(state: SaveCardState, onCheck: ((isChecked: Boolean) -> Unit)? = null) {
        this.state = state
        this.callback = onCheck
    }
}