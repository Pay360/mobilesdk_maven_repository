package com.accesspaysuite.mobilesdk.ui.googlepay

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.googlepay.newRequest
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.modules.InitiateGooglePay
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.addComposable
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import com.google.pay.button.ButtonType
import com.google.pay.button.PayButton
import io.github.aakira.napier.Napier
import kotlinx.coroutines.delay
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json


/**
 * # Google Pay Button
 *
 * A button that initiates a Google Pay payment.
 * This is an optional component and can be omitted
 * if the merchant wants to control their own button UI
 *
 * @property billingAddress The billing address to use for the payment.
 * @property radius The corner radius of the button.
 * @property buttonType The type of button to display.
 */
@OptIn(ExperimentalMobileUI::class)
class GooglePayButtonView : FrameLayout {

    var billingAddress: BillingAddress? by mutableStateOf(null)
    var radius: Dp by mutableStateOf(16.dp)
    var buttonType: GooglePayButtonType by mutableStateOf(GooglePayButtonType.Pay)

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    init {
        addComposable {
            GooglePayButton(
                billingAddress = billingAddress,
                radius = radius,
                buttonType = buttonType
            )
        }
    }

    override fun setOnClickListener(l: OnClickListener?) {
        // Do nothing
    }

}

enum class GooglePayButtonType(val value: ButtonType) {
    Book(ButtonType.Book),
    Buy(ButtonType.Buy),
    Checkout(ButtonType.Checkout),
    Donate(ButtonType.Donate),
    Order(ButtonType.Order),
    Pay(ButtonType.Pay),
    Plain(ButtonType.Plain),
    Subscribe(ButtonType.Subscribe),
}

/**
 * # Google Pay Button
 *
 * A button that initiates a Google Pay payment.
 * This is an optional component and can be omitted
 * if the merchant wants to control their own button UI
 *
 * @param modifier The modifier to apply to this layout.
 * @param radius The corner radius of the button.
 * @param buttonType The type of button to display.
 * @param billingAddress The billing address to use for the payment.
 */
@ExperimentalMobileUI
@Composable
fun GooglePayButton(
    modifier: Modifier = Modifier,
    radius: Dp = 16.dp,
    buttonType: GooglePayButtonType = GooglePayButtonType.Pay,
    billingAddress: BillingAddress?
) {
    PaymentUITheme {
        InitiateGooglePay()
        val processor = PaymentProcessorFactory.currentProcessor
        var allowedPaymentMethods: String by remember { mutableStateOf("") }
        LaunchedEffect(processor, processor?.initiated) {
            while (processor == null || !processor.initiated) {
                Napier.d { "Waiting for processor on GooglePay Button" }
                delay(100)
            }
            var googlePayAllowed: Boolean
            processor.getAllowedPaymentMethods {
                Napier.d { "Allowed payment methods: $it" }
                googlePayAllowed = it.contains(AcceptPaymentMethods.GOOGLEPAY)
                if (googlePayAllowed) {
                    allowedPaymentMethods = Json.encodeToString(
                        processor.initResponse!!.googlePay!!.newRequest(
                            billingAddressRequired = billingAddress != null,
                            amount = processor.paymentInfo.transaction!!.amount.toString()
                        ).allowedPaymentMethods
                    )
                    googlePayAllowed = processor.isReadyToPay()
                }
            }
        }
        AnimatedVisibility(
            visible = allowedPaymentMethods.isNotEmpty() && processor != null,
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            PayButton(
                modifier = modifier.fillMaxWidth(),
                onClick = {
                    requireNotNull(processor) {
                        "Payment processor must be initialised for Google Pay"
                    }
                    requireNotNull(billingAddress) {
                        "Billing address is required for Google Pay"
                    }
                    processor.processGooglePayPayment(
                        billingAddress = billingAddress
                    )
                },
                allowedPaymentMethods = allowedPaymentMethods,
                type = buttonType.value,
                radius = radius
            )
        }
    }

}