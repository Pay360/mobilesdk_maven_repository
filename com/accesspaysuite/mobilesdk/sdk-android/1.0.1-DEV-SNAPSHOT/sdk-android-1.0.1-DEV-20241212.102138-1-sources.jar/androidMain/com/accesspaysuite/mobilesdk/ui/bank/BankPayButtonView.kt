package com.accesspaysuite.mobilesdk.ui.bank

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.components.Constants
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Bank pay button view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
internal class BankPayButtonView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf<BankPayState?>(null)

    init {
        addComposable {
            state?.let { BankPayButton(state = it) }
                ?: Log.e(Constants.TAG, "BankPayState is not initialized")
        }
    }

    /**
     * Init
     *
     * @param state
     */
    fun init(state: BankPayState) {
        this.state = state
    }
}