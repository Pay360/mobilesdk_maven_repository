package com.accesspaysuite.mobilesdk.ui.card

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.Constants
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Card input view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
@ExperimentalMobileUI
class CardInputView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf<CardInputStyleState?>(null)

    init {
        addComposable {
            state?.let { CardInput(state = it) }
                ?: Log.e(Constants.TAG, "CardInputView is not initialized")
        }
    }

    /**
     * Init
     *
     * @param state
     */
    fun init(state: CardInputStyleState) {
        this.state = state
    }
}