package com.accesspaysuite.mobilesdk.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper

/**
 * Find activity from context
 */
internal fun Context.findActivity(): Activity? {
    var context = this
    while (context is ContextWrapper) {
        if (context is Activity) {
            return context
        }
        context = context.baseContext
    }
    return null
}