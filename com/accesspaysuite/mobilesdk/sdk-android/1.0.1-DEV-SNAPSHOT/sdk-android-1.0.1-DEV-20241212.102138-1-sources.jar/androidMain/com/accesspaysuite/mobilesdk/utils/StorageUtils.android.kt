package com.accesspaysuite.mobilesdk.utils

import android.content.Context
import android.content.Context.MODE_PRIVATE
import androidx.core.content.edit

internal actual class StorageUtils(private val context: Context) {

    private val prefs by lazy { context.getSharedPreferences("internal", MODE_PRIVATE)}

    actual fun getString(key: String, default: String?): String? = prefs.getString(key, default)

    actual fun putString(key: String, value: String?) = prefs.edit {
        putString(key, value)
    }

}