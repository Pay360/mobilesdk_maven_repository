package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.GlobalConfig
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.HttpTimeoutConfig
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json
import okhttp3.CertificatePinner
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

internal actual object NetworkEngine {
    actual val client: HttpClient
        get() = HttpClient(OkHttp) {
            install(HttpTimeout) {
                // Disable timeout for network calls to avoid any drops
                // for slower network connections
                requestTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                connectTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                socketTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
            }
            install(ContentNegotiation) {
                json(
                    json = parser
                )
            }
            if (GlobalConfig.LOGGING) {
                install(Logging) {
                    level = LogLevel.ALL
                }
            }
            engine {
                preconfigured = getOkHttpClient()
                if (GlobalConfig.LOGGING) {
                    addInterceptor(
                        HttpLoggingInterceptor().apply {
                            setLevel(HttpLoggingInterceptor.Level.BODY)
                        }
                    )
                }

            }
        }
    private fun getOkHttpClient(): OkHttpClient {
        val clientBuilder = OkHttpClient.Builder()

        if (ENABLE_SSL_PINNING){
            val certificatePinner = CertificatePinner.Builder()
                .add(pattern = PINNED_HOST_NAME, pins = pins)
                .build()

            clientBuilder.certificatePinner(certificatePinner)
        }

        return clientBuilder.build()
    }
}