package com.accesspaysuite.mobilesdk.ui.save

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Saved cards view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
@OptIn(ExperimentalMobileUI::class)
class SavedCardsView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf(SavedCardsState())

    init {
        addComposable {
            SavedCards(state = state)
        }
    }

    /**
     * Init
     *
     * @param state
     */
    fun init(state: SavedCardsState) {
        this.state = state
    }
}