package com.accesspaysuite.mobilesdk.ui.utils

import android.view.ViewGroup
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.ComposeView

/**
 * Add composable
 *
 * @param content
 * @receiver
 */
internal fun ViewGroup.addComposable(content: @Composable () -> Unit) {
    addView(ComposeView(context).apply { setContent(content) })
}