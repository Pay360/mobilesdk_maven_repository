package com.accesspaysuite.mobilesdk.ui.billing

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.Constants
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Billing address view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
@OptIn(ExperimentalMobileUI::class)
class BillingAddressView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf<BillingAddressState?>(null)

    init {
        addComposable {
            state?.let { BillingAddressComponent(state = it) }
                ?: Log.e(Constants.TAG, "BillingAddressState is not initialized")
        }
    }

    /**
     * Init
     *
     * @param state
     */
    fun init(state: BillingAddressState) {
        this.state = state
    }
}