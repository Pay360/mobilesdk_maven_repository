package com.accesspaysuite.mobilesdk

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.withCreated
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.standalone.PaymentResult
import com.accesspaysuite.mobilesdk.ui.standalone.PaymentPageContent
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Standalone Payment Page Container for Android
 * @suppress
 */
internal class PaymentPage : ComponentActivity() {

    private var billing = mutableStateOf<BillingAddress?>(null)

    // A copy of the billing address provided by payment config
    // Used to fall back when the users opts out from using a different
    // billing address other than the one provided already
    private var originalBilling = mutableStateOf<BillingAddress?>(null)
    private var paymentProcessor: PaymentProcessor? by mutableStateOf(null)
    private val merchantName: String?
        get() = intent.getStringExtra("merchantName")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()
        setContent {
            PaymentUITheme {
                PaymentPageContent(
                    billingAddress = billing,
                    origBillingAddress = originalBilling,
                    merchantName = merchantName,
                    onPaymentFailed = ::setPaymentFailed,
                    onPaymentSuccess = ::setPaymentSuccess,
                    onPaymentCanceled = ::setPaymentCanceled
                )
            }
        }
        lifecycleScope.launch(Dispatchers.IO) {
            lifecycle.withCreated {
                lifecycleScope.launch(Dispatchers.IO) {
                    val config: PaymentConfig? = intent.getStringExtra("config")
                        ?.let { Json.decodeFromString(it) }
                    while (config == null) {
                        delay(100)
                    }
                    withContext(Dispatchers.Main) {
                        initProcessor(config)
                    }
                }
            }
        }
    }

    @Suppress("ConstantConditionIf", "DEPRECATION")
    @Deprecated(
        "Deprecated in Java",
        ReplaceWith("super.onBackPressed()", "androidx.activity.ComponentActivity")
    )
    override fun onBackPressed() {
        // Disable onBackPressed
        if (false) {
            super.onBackPressed()
        }
    }

    private fun setPaymentFailed(reason: String?) = setPaymentResult(
        resultCode = RESULT_OK,
        paymentResult = PaymentResult.Failed(reason)
    )

    private fun setPaymentSuccess() = setPaymentResult(
        resultCode = RESULT_OK,
        paymentResult = PaymentResult.Success
    )

    private fun setPaymentCanceled() = setPaymentResult(
        resultCode = RESULT_CANCELED,
        paymentResult = PaymentResult.Canceled
    )

    private fun setPaymentResult(resultCode: Int, paymentResult: PaymentResult) {
        setResult(resultCode, Intent().putExtra("result", Json.encodeToString(paymentResult)))
        finish()
    }

    private fun initProcessor(config: PaymentConfig) {
        paymentProcessor = PaymentProcessor(
            config = config,
            context = this
        )

        paymentProcessor?.initiate {
            // No need to pass processor again
            // since it's a mutable state and
            // the UI will be updated accordingly
            billing.value = intent.getStringExtra("billingAddress")
                ?.let { it1 -> Json.decodeFromString(it1) }
            originalBilling.value = billing.value
        }
    }

    override fun onStop() {
        super.onStop()
        paymentProcessor?.detach()
    }

    companion object {
        internal fun createPaymentIntent(
            context: Context,
            config: PaymentConfig,
            billingAddress: BillingAddress?
        ): Intent {
            return Intent(context, PaymentPage::class.java).apply {
                putExtra("config", Json.encodeToString(config))
                billingAddress?.let {
                    putExtra(
                        "billingAddress",
                        Json.encodeToString(billingAddress)
                    )
                }
            }
        }
    }

}
