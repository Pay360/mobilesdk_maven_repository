package com.accesspaysuite.mobilesdk

import android.content.Context
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CardError
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.modules.DeviceInfoController
import com.accesspaysuite.mobilesdk.modules.GooglePayController
import com.accesspaysuite.mobilesdk.modules.InitiateGooglePay
import com.accesspaysuite.mobilesdk.modules.OpenBankingController
import com.accesspaysuite.mobilesdk.modules.ThreeDSController
import com.accesspaysuite.mobilesdk.modules.initiateGooglePay
import com.accesspaysuite.mobilesdk.utils.findActivity

/**
 * # Payment Processor (Android)
 *
 *
 *  The [PaymentProcessor] class is responsible for handling the payment process.
 *  It is responsible for initiating the payment process,
 *  processing the Card, Google Pay payment methods, and handling the payment result.
 *
 *  ## Available functions
 *  - [initiate] - Initiates the payment processor
 *  - [processCardPayment] - Processes the card payment
 *  - [processGooglePayPayment] - Processes the Google Pay payment
 *  - [setPaymentResultCallback] - Sets the payment result callback
 *  - [setCardCallback] - Sets the card callback
 *  - [detach] - Detaches the payment processor
 *  - [isCardEntered] - Checks if the card is entered
 *
 *
 *  ## Usage
 *  ```kotlin
 *  val paymentProcessor = PaymentProcessor(
 *      paymentConfig = paymentConfig,
 *      context = context
 *  )
 *  paymentProcessor.initiate {
 *    // Payment Processor is initiated
 *  }
 *    // Set the payment result callback
 *  paymentProcessor.setPaymentResultCallback(
 *      onPaymentSuccess = {
 *          // Payment is successful
 *      },
 *      onPaymentFailed = { error ->
 *          // Payment failed
 *      },
 *      onPaymentMethodCanceled = {
 *          // Payment method is canceled
 *      }
 *  )
 *  // Set the card callback
 *  paymentProcessor.setCardCallback(
 *      onCardSubmittedSuccessfully = {
 *          // Card is submitted successfully
 *      },
 *      onCardSubmittedWithErrors = { errors ->
 *          // Card is submitted with errors
 *      }
 *  )
 *
 *
 *  // Process the card payment
 *  paymentProcessor.processCardPayment(billingAddress)
 *
 *  // Process the Google Pay payment
 *  paymentProcessor.processGooglePayPayment(billingAddress)
 * ```
 *
 *
 *  @param config The payment configuration; see [PaymentConfig]
 *  @param context The Android context
 *
 */
actual class PaymentProcessor(
    config: PaymentConfig,
    context: Context
) : PaymentProcessorInternal(
    config = config,
    deviceInfoController = DeviceInfoController(context),
    threeDSController = ThreeDSController(context.findActivity())
) {

    private val googlePayController by lazy {
        GooglePayController(
            context = context,
            paymentInfo = paymentInfo,
            repository = repository,
            delegate = paymentResultCallback
        )
    }
    private val openBankingController by lazy {
        OpenBankingController(
            context = context,
            repository = repository,
            deviceInfoController = deviceInfoController,
            delegate = paymentResultCallback
        ).apply { setPaymentInfo(paymentInfo) }
    }

    internal suspend fun isReadyToPay(): Boolean {
        return googlePayController.isReadyToPay()
    }

    /**
     * ## Start the Google Pay Payment Process
     *
     * ### Requirements:
     * - The PaymentResultCallback must be set before starting a Google Pay payment
     * - The PaymentProcessor must be initiated before starting a Google Pay payment
     * - The Google Pay Payment Method must be an accepted payment method
     *
     * #### Android Views only:
     * - [initiateGooglePay] must be called on top of the Android Activity or Fragment
     * ##### Example:
     * ```kotlin
     * class MainActivity : ComponentActivity() {
     *     ...
     *     val _initGooglePay = initiateGooglePay()
     *     ...
     * }
     * ```
     * #### Compose Only:
     * - [InitiateGooglePay] must be called on top of the Composable if you're not using the built-in GooglePayButton
     * ##### Example:
     * ```kotlin
     * @Composable
     * fun ComposableExample() {
     *     InitiateGooglePay()
     *     ...
     * }
     * ```
     *
     * ### Usage:
     * ```kotlin
     * paymentProcessor.processGooglePayPayment(billingAddress)
     * ```
     *
     *
     * @throws IllegalArgumentException
     * @param billingAddress required for All Payment Methods
     */
    @Throws(IllegalArgumentException::class)
    fun processGooglePayPayment(billingAddress: BillingAddress) {
        performNullChecks()
        initResponse?.let { response ->
            if (response.acceptPaymentMethods?.contains(AcceptPaymentMethods.GOOGLEPAY) == false) {
                paymentResultCallback.onPaymentResult(Status.Error("Google Pay Payments are not allowed"))
                return
            }
            response.googlePay?.let { googlePay ->
                googlePayController.setGooglePayIntent(googlePay)
                googlePayController.pay(billingAddress)
            } ?: run {
                paymentResultCallback.onPaymentResult(Status.Error("Google Pay Payments are not allowed"))
                return
            }
        }
    }

    /**
     * Process bank payment
     *
     * TODO: Remove private modifier after payment method is complete
     *
     * @throws IllegalArgumentException
     * @param billingAddress
     */
    @Throws(IllegalArgumentException::class)
    private fun processBankPayment(billingAddress: BillingAddress?) {
        performNullChecks()
        initResponse?.let {
            if (it.acceptPaymentMethods?.contains(AcceptPaymentMethods.OPENBANKING) == false) {
                paymentResultCallback.onPaymentResult(Status.Error("Open Banking Payments are not allowed"))
                return
            }
        }
        openBankingController.processBankPayment(billingAddress)
    }

    actual companion object {
        internal actual fun newInstance(
            context: Any?,
            paymentConfig: PaymentConfig
        ): PaymentProcessor {
            require(context is Context) {
                "Context is required for Android"
            }
            return PaymentProcessor(paymentConfig, context)
        }

        internal actual fun newInstance(
            context: Any?,
            paymentConfig: PaymentConfig,
            onPaymentSuccess: PaymentProcessor.() -> Unit,
            onPaymentFailed: PaymentProcessor.(String) -> Unit,
            onPaymentMethodCanceled: PaymentProcessor.() -> Unit,
            onCardSubmittedSuccessfully: PaymentProcessor.() -> Unit,
            onCardSubmittedWithErrors: PaymentProcessor.(Array<CardError>) -> Unit,
            onInitiate: PaymentProcessor.(Status) -> Unit
        ): PaymentProcessor {
            return newInstance(context, paymentConfig).apply {
                setPaymentResultCallback(
                    onPaymentSuccess = { onPaymentSuccess() },
                    onPaymentFailed = { onPaymentFailed(it) },
                    onPaymentMethodCanceled = { onPaymentMethodCanceled() }
                )
                setCardCallback(
                    onCardSubmittedSuccessfully = { onCardSubmittedSuccessfully() },
                    onCardSubmittedWithErrors = { onCardSubmittedWithErrors(it) }
                )
                initiate { onInitiate(it) }
            }
        }
    }

}