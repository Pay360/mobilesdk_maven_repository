@file:Suppress("DEPRECATION")

package com.accesspaysuite.mobilesdk.modules

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Rect
import android.os.Build
import android.view.LayoutInflater
import android.view.WindowInsets
import android.view.WindowManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import com.accesspaysuite.mobilesdk.R
import com.accesspaysuite.mobilesdk.callbacks.internal.ThreeDSResultCallback
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.common.ThreeDSResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponseThreeDSRedirect
import com.accesspaysuite.mobilesdk.ui.utils.MatchParentFrameLayout
import com.accesspaysuite.mobilesdk.utils.Constants
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.apache.http.NameValuePair
import org.apache.http.client.entity.UrlEncodedFormEntity
import org.apache.http.message.BasicNameValuePair
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.LinkedList


/**
 * ThreeDS controller
 *
 * @constructor Create ThreeDS controller
 */
internal actual class ThreeDSController actual constructor() {

    private var activity: Activity? = null

    constructor(activity: Activity?): this() {
        this.activity = activity
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupDialog(
        context: Activity,
        delegate: ThreeDSResultCallback,
        paymentType: PaymentType,
        params: PaymentResponseThreeDSRedirect
    ): BottomSheetDialog {
        var popup: BottomSheetDialog? = null
        val wrapper = LinearLayout(context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bottomsheet)
            clipToOutline = true
        }
        val webView = WebView(wrapper.context).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT
            )
            settings.javaScriptEnabled = true
            webViewClient = ThreeDSWebClient(delegate, paymentType, params) {
                popup?.dismiss()
            }
            val paramsList: MutableList<NameValuePair> = LinkedList()
            paramsList.add(BasicNameValuePair("MD", params.md))
            val isThreeDSv1 =
                params.notificationUrl.isEmpty() || params.threeDSServerTransId.isEmpty()
            if (isThreeDSv1) {
                paramsList.add(BasicNameValuePair("PaReq", params.pareq))
                paramsList.add(BasicNameValuePair("TermUrl", params.termUrl))
            } else {
                paramsList.add(
                    BasicNameValuePair("notificationUrl", params.notificationUrl)
                )
                paramsList.add(
                    BasicNameValuePair("transactionId", params.threeDSServerTransId)
                )
            }
            val encodedParams = ByteArrayOutputStream()
            try {
                val form = UrlEncodedFormEntity(paramsList, "UTF-8")
                form.writeTo(encodedParams)
                postUrl(params.acsUrl, encodedParams.toByteArray())
            } catch (e: IOException) {
                e.printStackTrace()
                delegate.threeDSProcessFailure(Constants.ThreeDS.UNKNOWN_DISPLAY_ERROR, paymentType)
            }
        }

        wrapper.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ).apply { weight = 1f })

        val navigationBarHeight = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.window.decorView.rootWindowInsets.getInsets(WindowInsets.Type.navigationBars()).bottom
            } else {
                context.window.decorView.rootWindowInsets.systemWindowInsetBottom
            }
        } else {
            val rectangle = Rect()
            context.window.decorView.getWindowVisibleDisplayFrame(rectangle)
            rectangle.bottom
        }

        val buttonLayout = LayoutInflater.from(wrapper.context).inflate(R.layout.bottom_sheet_bottom, wrapper, true)
        buttonLayout.findViewById<Button>(R.id.cancelButton).setOnClickListener {
            delegate.threeDSProcessFailure(Constants.ThreeDS.USER_CANCELED_SESSION, paymentType)
            popup?.dismiss()
        }
        val spacer = Space(context).apply {
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, navigationBarHeight)
        }
        wrapper.addView(spacer)
        popup = BottomSheetDialog(context).apply {
            setContentView(MatchParentFrameLayout(context).apply {
                addView(wrapper)
            })
            setCancelable(false)
            setCanceledOnTouchOutside(false)
            window?.setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
            )
            behavior.skipCollapsed = true
            behavior.isDraggable = false
            behavior.state = BottomSheetBehavior.STATE_EXPANDED
        }
        return popup
    }

    @SuppressLint("SetJavaScriptEnabled")
    internal actual fun run3DSProcess(
        delegate: ThreeDSResultCallback,
        paymentType: PaymentType,
        params: PaymentResponseThreeDSRedirect
    ) {
        try {
            activity?.let {
                it.runOnUiThread {
                    setupDialog(
                        it,
                        delegate,
                        paymentType,
                        params
                    ).show()
                }
            } ?: {
                throw ThreeDSException(Constants.ThreeDS.INIT_EXCEPTION)
            }
        } catch (e: ThreeDSException) {
            e.printStackTrace()
        }
    }

    private class ThreeDSException(string: String) : Exception(string)

}

/**
 * Custom Web View Client to enable Javascript Eval
 */
private class ThreeDSWebClient(
    private val delegate: ThreeDSResultCallback,
    private val paymentType: PaymentType,
    private val params: PaymentResponseThreeDSRedirect,
    private val onDismiss: () -> Unit,
) : WebViewClient() {
    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        if (url == params.termUrl || url == params.notificationUrl) {
            val isThreeDSv1 = params.notificationUrl.isEmpty() || params.threeDSServerTransId.isEmpty()
            if (isThreeDSv1) {
                view.evaluateJavascript(Constants.ThreeDS.PARES_EVALUATION) { pares: String? ->
                    view.dismiss(ThreeDSResponse(pares))
                }
            } else {
                view.dismiss()
            }
        }
    }

    private fun WebView.dismiss(response: ThreeDSResponse? = null) {
        delegate.threeDSProcessSuccess(response, paymentType)
        stopLoading()
        onDismiss()
    }

    override fun onReceivedError(
        view: WebView,
        request: WebResourceRequest,
        error: WebResourceError
    ) {
        view.stopLoading()
    }
}