package com.accesspaysuite.mobilesdk

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowCompat
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.management.CardManagementCredentials
import com.accesspaysuite.mobilesdk.ui.management.CardManagementScreen
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class CardManagementPage : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        enableEdgeToEdge()

        val username = intent.getStringExtra("username") ?: throw IllegalArgumentException("Username must be provided")
        val password = intent.getStringExtra("password") ?: throw IllegalArgumentException("Password must be provided")
        val installationId = intent.getStringExtra("installationId") ?: throw IllegalArgumentException("Installation ID must be provided")
        val environment = intent.getStringExtra("environment")
            ?.let { Json.decodeFromString<Environment>(it) } ?: throw IllegalArgumentException("Environment must be provided")
        val customerReference = intent.getStringExtra("customerReference")
            ?: throw IllegalArgumentException("Customer reference must be provided")

        setContent {
            CardManagementScreen(
                credentials = CardManagementCredentials(
                    username = username,
                    password = password,
                    installationId = installationId,
                    environment = environment
                ),
                customerReference = customerReference,
                onBackPress = ::finish
            )
        }
    }

    companion object {
        fun createManagementPage(
            context: Context,
            username: String,
            password: String,
            installationId: String,
            customerReference: String,
            environment: Environment
        ): Intent {
            return Intent(context, CardManagementPage::class.java).apply {
                putExtra("username", username)
                putExtra("password", password)
                putExtra("installationId", installationId)
                putExtra("customerReference", customerReference)
                putExtra("environment", Json.encodeToString(environment))
            }
        }
    }
}