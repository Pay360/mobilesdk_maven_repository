package com.accesspaysuite.mobilesdk.modules

import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.runtime.Composable
import androidx.fragment.app.Fragment
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.callbacks.internal.GooglePayResultCallback
import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentInfo
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePayPayment
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePayPaymentData
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePayPaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePaymentDataPaymentMethods
import com.accesspaysuite.mobilesdk.data.internal.googlepay.newRequest
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateGooglePay
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.utils.URLProvider
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.tasks.Task
import com.google.android.gms.wallet.AutoResolveHelper
import com.google.android.gms.wallet.IsReadyToPayRequest
import com.google.android.gms.wallet.PaymentData
import com.google.android.gms.wallet.PaymentDataRequest
import com.google.android.gms.wallet.PaymentsClient
import com.google.android.gms.wallet.Wallet
import com.google.android.gms.wallet.WalletConstants
import com.google.android.gms.wallet.contract.TaskResultContracts
import io.github.aakira.napier.Napier
import kotlinx.coroutines.tasks.await
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONException
import org.json.JSONObject

private var paymentDataLauncher: ActivityResultLauncher<Task<PaymentData>>? = null
private var googlePayCallback: GooglePayResultCallback? = null

/**
 * ## Initiate Google Pay handler
 *
 * Required to process the Google Pay payment after the user has finished the Google Pay process.
 *
 * It registers a `registerForActivityResult` custom contract to handle the Google Pay payment result.
 */
@Composable
fun InitiateGooglePay() {
    paymentDataLauncher = rememberLauncherForActivityResult(TaskResultContracts.GetPaymentDataResult()) { taskResult ->
        when (taskResult.status.statusCode) {
            CommonStatusCodes.SUCCESS -> {
                googlePayCallback?.onGooglePaySuccess(data = taskResult.result!!)
            }

            CommonStatusCodes.CANCELED -> {
                googlePayCallback?.onGooglePayCanceled()
            }

            AutoResolveHelper.RESULT_ERROR, CommonStatusCodes.INTERNAL_ERROR -> {
                googlePayCallback?.onGooglePayFailed(
                    errorCode = taskResult.status.statusCode,
                    reason = taskResult.status.statusMessage ?: "Unknown error"
                )
            }
        }
    }
}

/**
 * ## Initiate Google Pay handler
 *
 * Required to process the Google Pay payment after the user has finished the Google Pay process.
 *
 * It registers a `registerForActivityResult` custom contract to handle the Google Pay payment result.
 */
fun ComponentActivity.initiateGooglePay() {
    paymentDataLauncher = registerForActivityResult(
        TaskResultContracts.GetPaymentDataResult()
    ) { taskResult ->
        when (taskResult.status.statusCode) {
            CommonStatusCodes.SUCCESS -> {
                googlePayCallback?.onGooglePaySuccess(data = taskResult.result!!)
            }

            CommonStatusCodes.CANCELED -> {
                googlePayCallback?.onGooglePayCanceled()
            }

            AutoResolveHelper.RESULT_ERROR, CommonStatusCodes.INTERNAL_ERROR -> {
                googlePayCallback?.onGooglePayFailed(
                    errorCode = taskResult.status.statusCode,
                    reason = taskResult.status.statusMessage ?: "Unknown error"
                )
            }
        }
    }
}

/**
 * ## Initiate Google Pay handler
 *
 * Required to process the Google Pay payment after the user has finished the Google Pay process.
 *
 * It registers a `registerForActivityResult` custom contract to handle the Google Pay payment result.
 */
fun Fragment.initiateGooglePay() {
    paymentDataLauncher = registerForActivityResult(
        TaskResultContracts.GetPaymentDataResult()
    ) { taskResult ->
        when (taskResult.status.statusCode) {
            CommonStatusCodes.SUCCESS -> {
                googlePayCallback?.onGooglePaySuccess(data = taskResult.result!!)
            }

            CommonStatusCodes.CANCELED -> {
                googlePayCallback?.onGooglePayCanceled()
            }

            AutoResolveHelper.RESULT_ERROR, CommonStatusCodes.INTERNAL_ERROR -> {
                googlePayCallback?.onGooglePayFailed(
                    errorCode = taskResult.status.statusCode,
                    reason = taskResult.status.statusMessage ?: "Unknown error"
                )
            }
        }
    }
}

/**
 * Google pay controller
 *
 * @property context
 * @property paymentInfo
 * @property repository
 * @property delegate
 * @constructor Create Google pay controller
 * @suppress
 */
internal class GooglePayController(
    private val context: Context,
    private val paymentInfo: PaymentInfo,
    private val repository: RequestRepository,
    private val delegate: PaymentResultCallback
) : GooglePayResultCallback, HttpRequestDelegate<PaymentResponse> {

    init {
        googlePayCallback = this
    }

    private var googlePayIntent: InitiateGooglePay? = null
    private var currentBillingAddress: BillingAddress? = null
    private val deviceInfoController = DeviceInfoController(context)
    private val credentials: AuthCredentials by lazy {
        AuthCredentials(
            token = paymentInfo.clientToken,
            providerId = paymentInfo.providerId
        )
    }

    /**
     * Set google pay intent
     *
     * @param googlePayIntent
     */
    fun setGooglePayIntent(googlePayIntent: InitiateGooglePay) {
        this.googlePayIntent = googlePayIntent.copy(
            tokenizationSpecification = googlePayIntent.tokenizationSpecification.copy(
                parameters = googlePayIntent.tokenizationSpecification.parameters.copy(
                    // Ensure the gateway is always lowercase
                    gateway = googlePayIntent.tokenizationSpecification.parameters.gateway.lowercase(),
                    gatewayMerchantId = googlePayIntent.tokenizationSpecification.parameters.gatewayMerchantId.filter { it.isDigit() }
                )
            )
        )
    }

    /**
     * Pay
     *
     * @param billingAddress
     */
    fun pay(
        billingAddress: BillingAddress?
    ) {
        val requireBillingAddress = billingAddress != null
        if (requireBillingAddress) {
            currentBillingAddress = billingAddress
        }
        val requestData = googlePayIntent!!.newRequest(
            billingAddressRequired = requireBillingAddress,
            amount = if (paymentInfo.transaction != null) paymentInfo.transaction.amount.toString() else null
        )
        val request = PaymentDataRequest.fromJson(Json.encodeToString(requestData))
        paymentsClient.loadPaymentData(request).addOnCompleteListener {
            paymentDataLauncher?.launch(it)
        }
    }

    /**
     * Is ready to pay
     *
     * @return
     */
    suspend fun isReadyToPay(): Boolean = try {
        if (googlePayIntent != null) paymentsClient.isReadyToPay().await() else true
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }

    private val paymentsClient: PaymentsClient by lazy {
        val walletOptions = Wallet.WalletOptions.Builder()
            .setEnvironment(googlePayIntent!!.environment.toGooglePayEnvironment())
            .build()

        Wallet.getPaymentsClient(context, walletOptions)
    }

    private fun PaymentsClient.isReadyToPay(): Task<Boolean> {
        return isReadyToPay(
            IsReadyToPayRequest.fromJson(
                Json.encodeToString(
                    ReadyToPayRequest(allowedPaymentMethods = googlePayIntent!!.newRequest().allowedPaymentMethods)
                )
            )
        )
    }

    private fun Environment.toGooglePayEnvironment(): Int {
        return when (this) {
            Environment.TEST -> WalletConstants.ENVIRONMENT_TEST
            Environment.LIVE -> WalletConstants.ENVIRONMENT_PRODUCTION
        }
    }

    private fun PaymentData.buildGooglePayPayment(): GooglePayPayment? {
        val paymentInfo = this.toJson()
        return try {
            val paymentMethodData = JSONObject(paymentInfo).getJSONObject("paymentMethodData")
            val tokenizationData = paymentMethodData.getJSONObject("tokenizationData")
            val token = tokenizationData.getString("token")
            val info = paymentMethodData.getJSONObject("info")
            //val billingName = info.getJSONObject("billingAddress").getString("name")
            val network = info.getString("cardNetwork")
            val displayName = paymentMethodData.getString("description")
            val cardType = paymentMethodData.getString("type")
            return GooglePayPayment(
                paymentData = GooglePayPaymentData(token = token),
                paymentMethod = GooglePayPaymentMethod(
                    displayName = displayName,
                    network = network,
                    details = cardType
                ),
                apiVersion = "2.0"
            )
        } catch (e: JSONException) {
            null
        }
    }

    override fun onGooglePaySuccess(data: Any) {
        if (data is PaymentData) {
            try {
                val request = paymentInfo.newPayment(
                    paymentMethod = PaymentMethod(
                        googlepay = data.buildGooglePayPayment()
                    ),
                    billingAddress = currentBillingAddress,
                    deviceInfoController = deviceInfoController
                )
                val paymentRequestUrl = URLProvider.getPaymentProcessUrl(
                    paymentInfo.environment,
                    paymentInfo.installationId
                )
                repository.request(
                    url = paymentRequestUrl,
                    httpMethod = "POST",
                    requestType = APIRequestType.APIRequestGooglePayPayment,
                    authCredentials = credentials,
                    bodyObject = request,
                    delegate = this
                )
            } catch (e: Exception) {
                e.printStackTrace()
                onGooglePayFailed(errorCode = -1, reason = "Unknown error\n${e.message}")
            }
        } else {
            throw IllegalArgumentException("Expected PaymentData, got ${data::class.simpleName}")
        }
    }

    override fun onGooglePayFailed(errorCode: Int, reason: String) {
        delegate.onPaymentResult(Status.Error(reason))
    }

    override fun onGooglePayCanceled() {
        delegate.onPaymentResult(Status.Canceled)
    }

    override fun responseReceivedWithSuccess(
        requestType: APIRequestType,
        response: PaymentResponse
    ) {
        delegate.onPaymentResult(response.retrieveStatus())
    }

    private fun PaymentResponse.retrieveStatus(): Status {
        return if (outcome.status == STATUS_FAILED) {
            if (outcome.reasonMessage != null) {
                Napier.e { "Payment failed: ${outcome.reasonMessage} | Status: ${outcome.status} | TraceID: $trace" }
                if (outcome.reasonMessage == "Client token expired") {
                    Status.SessionExpired
                } else Status.Error(outcome.reasonMessage)
            }
            // Just for unexpected errors, this should never happen, but it's best to have
            // a way to debug if it does
            Napier.e { "Payment failed: Unknown error | Status: ${outcome.status} | TraceID: $trace" }
            Status.Error("Unknown error\nPlease contact administrator.")
        } else {
           Status.Success
        }
    }

    override fun responseReceivedWithFailure(requestType: APIRequestType, reason: String?) {
        delegate.onPaymentResult(Status.Error(reason ?: "Unknown error"))
    }

    companion object {
        private const val STATUS_FAILED = "FAILED"
    }

}

@Serializable
private data class ReadyToPayRequest(
    val apiVersion: Int = 2,
    val apiVersionMinor: Int = 0,
    val allowedPaymentMethods: List<GooglePaymentDataPaymentMethods>,
)