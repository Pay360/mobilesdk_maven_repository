package com.accesspaysuite.mobilesdk.modules

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.view.LayoutInflater
import android.view.WindowInsets
import android.view.WindowManager
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Space
import com.accesspaysuite.mobilesdk.R
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking.Companion.TEST_RETURN_URL
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.google.android.material.bottomsheet.BottomSheetDialog

/**
 * Open banking controller
 *
 * @constructor Create Open banking controller
 */
internal actual class OpenBankingController : OpenBankingControllerCommon {

    private var popup: BottomSheetDialog? = null
    private var context: Context? = null

    actual constructor(
        repository: RequestRepository,
        deviceInfoController: DeviceInfoController,
        delegate: PaymentResultCallback
    ) : super(repository, deviceInfoController, delegate)

    // Use this for Android
    constructor(
        context: Context,
        repository: RequestRepository,
        deviceInfoController: DeviceInfoController,
        delegate: PaymentResultCallback
    ): this(repository, deviceInfoController, delegate) {
        this.context = context
    }

    /**
     * Process bank payment
     *
     * @param billingAddress
     */
    @Suppress("DEPRECATION")
    @SuppressLint("SetJavaScriptEnabled")
    actual fun processBankPayment(billingAddress: BillingAddress?) {
        preProcessBankPayment(billingAddress) { paymentUrl ->
            context?.let {
                if (it is Activity) {
                    val webView = WebView(it).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT
                        )
                        settings.javaScriptEnabled = true
                        webViewClient = OpenBankingWebClient(returnUrl = TEST_RETURN_URL) { isCancelled ->
                            popup?.dismiss()
                            postProcessBankPayment(isCancelled)
                        }
                        loadUrl(paymentUrl)
                    }

                    val wrapper = LinearLayout(it).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.MATCH_PARENT
                        )
                        orientation = LinearLayout.VERTICAL
                        setBackgroundResource(R.drawable.bottomsheet)
                        clipToOutline = true
                    }
                    wrapper.addView(
                        webView,
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    val navigationBarHeight = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                            it.window.decorView.rootWindowInsets.getInsets(WindowInsets.Type.navigationBars()).bottom
                        } else {
                            it.window.decorView.rootWindowInsets.systemWindowInsetBottom
                        }
                    } else {
                        val rectangle = Rect()
                        it.window.decorView.getWindowVisibleDisplayFrame(rectangle)
                        rectangle.bottom
                    }
                    val buttonLayout = LayoutInflater.from(it).inflate(R.layout.bottom_sheet_bottom, wrapper, true)
                    buttonLayout.findViewById<Button>(R.id.cancelButton).setOnClickListener {
                        postProcessBankPayment(isCancelled = true)
                        popup?.dismiss()
                    }
                    val spacer = Space(it).apply {
                        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, navigationBarHeight)
                    }
                    wrapper.addView(spacer)
                    popup = BottomSheetDialog(it).apply {
                        setContentView(wrapper)
                        setCancelable(false)
                        setCanceledOnTouchOutside(false)
                        window?.setFlags(
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        )
                        behavior.skipCollapsed = true
                    }
                    popup?.show()
                } else {
                    throw IllegalStateException("The context must be an instance of Activity.")
                }
            }
        }
    }

}

private class OpenBankingWebClient(
    private val returnUrl: String,
    private val onDismiss: (isCanceled: Boolean) -> Unit,
) : WebViewClient() {
    override fun onPageFinished(view: WebView, url: String) {
        super.onPageFinished(view, url)
        if (url == returnUrl) {
            view.dismiss(isCancelled = false)
        }
    }

    private fun WebView.dismiss(isCancelled: Boolean = false) {
        stopLoading()
        onDismiss(isCancelled)
    }

    override fun onReceivedError(
        view: WebView,
        request: WebResourceRequest,
        error: WebResourceError
    ) {
        view.stopLoading()
        // TODO: Remove this after API is done and has a valid return Url
        if (view.url == returnUrl) {
            view.dismiss(isCancelled = false)
        }
    }
}