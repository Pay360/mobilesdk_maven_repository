package com.accesspaysuite.mobilesdk.modules

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.text.TextUtils
import com.accesspaysuite.mobilesdk.data.internal.common.DeviceInfo
import com.accesspaysuite.mobilesdk.utils.Constants.PPO_SDK_VERSION
import java.util.Locale
import java.util.UUID

/**
 * Device info controller
 *
 * @property context
 * @constructor Create Device info controller
 */
internal actual class DeviceInfoController(private val context: Context) {

    internal actual val sdkVersion: String = PPO_SDK_VERSION

    private val sdkInstallId: String
        get() {
            val preferences = context.getSharedPreferences(
                SHARED_PREFERENCE_NAME,
                Context.MODE_PRIVATE
            )
            var sdkInstallId = preferences.getString(PREFERENCE_INSTALLATION_ID, null)

            // set installation id if not already set
            if (sdkInstallId == null) {
                sdkInstallId = UUID.randomUUID().toString()
                preferences.edit().putString(PREFERENCE_INSTALLATION_ID, sdkInstallId).apply()
            }
            return sdkInstallId
        }

    /**
     * @return Device OS Family
     */
    private val osFamily: String = checkPropertySet(OS_ANDROID, MAX_LENGTH_OS_FAMILY)

    /**
     * @return OS Name
     */
    private val osName: String =
        checkPropertySet(OS_ANDROID + " " + Build.VERSION.RELEASE, MAX_LENGTH_OS_NAME)

    /**
     * @return Device Family
     */
    private val modelFamily: String = checkPropertySet(FAMILY_ANDROID, MAX_LENGTH_MODEL_FAMILY)

    /**
     * @return Device Model Name
     */
    private val modelName: String = checkPropertySet(Build.MODEL, MAX_LENGTH_MODEL_NAME)

    /**
     * @return Device Manufacturer
     */
    private val manufacturer: String = checkPropertySet(Build.MANUFACTURER, MAX_LENGTH_MANUFACTURER)

    /**
     * @return Screen Resolution (width x height)
     */
    private val screenRes: String
        get() {
            var screenRes = ""
            val metrics = context.resources.displayMetrics
            if (metrics != null) {
                screenRes = String.format(Locale.UK, "%dx%d", metrics.widthPixels, metrics.heightPixels)
            }
            return checkPropertySet(screenRes, MAX_LENGTH_SCREEN_RES)
        }

    /**
     * @return Screen Density (dpi)
     */
    private val screenDpi: String
        get() {
            var dpi = 0
            val metrics = context.resources.displayMetrics
            if (metrics != null) {
                dpi = (metrics.density * 160f).toInt()
            }
            return dpi.toString()
        }

    /**
     * @return Device type ("phone" or "tablet")
     */
    private val type: String = TYPE_SMARTPHONE


    internal actual val merchantAppName: String =
        checkPropertySet(context.packageName, MAX_LENGTH_MERCHANT_APP_NAME)

    internal actual val merchantAppVersion: String
        get() {
            var version: String? = null
            try {
                val packageInfo = context.packageManager.getPackageInfo(
                    context.packageName, 0
                )
                version = packageInfo.versionName
            } catch (e: PackageManager.NameNotFoundException) {
                e.printStackTrace()
            }
            return checkPropertySet(version, MAX_LENGTH_MERCHANT_APP_VERSION)
        }

    private fun checkPropertySet(property: String?, maxLength: Int): String {
        // return "unknown" if property not set
        var newProperty = property
        return if (TextUtils.isEmpty(newProperty)) {
            PROPERTY_UNKNOWN
        } else {
            // check max length
            if (newProperty!!.length > maxLength) {
                newProperty = newProperty.substring(0, maxLength)
            }
            newProperty
        }
    }

    /**
     * To device info
     *
     * @return
     */
    internal actual fun toDeviceInfo(): DeviceInfo = DeviceInfo(
        sdkInstallId = sdkInstallId,
        osFamily = osFamily,
        osName = osName,
        modelFamily = modelFamily,
        modelName = modelName,
        manufacturer = manufacturer,
        type = type,
        screenRes = screenRes,
        screenDpi = screenDpi,
        sdkVersion = sdkVersion,
        merchantAppName = merchantAppName,
        merchantAppVersion = merchantAppVersion
    )

    companion object {
        private const val SHARED_PREFERENCE_NAME = "ppSharedPreferences"
        private const val PREFERENCE_INSTALLATION_ID = "PREFERENCE_INSTALLATION_ID"
        private const val OS_ANDROID = "ANDROID"
        private const val FAMILY_ANDROID = "Android"

        private const val TYPE_SMARTPHONE = "SMARTPHONE"
        private const val TYPE_TABLET = "TABLET"
        private const val PROPERTY_UNKNOWN = "unknown"
        private const val MAX_LENGTH_SDK_INSTALLATION_ID = 36
        private const val MAX_LENGTH_SDK_VERSION = 32
        private const val MAX_LENGTH_MERCHANT_APP_NAME = 256
        private const val MAX_LENGTH_MERCHANT_APP_VERSION = 32
        private const val MAX_LENGTH_OS_FAMILY = 32
        private const val MAX_LENGTH_OS_NAME = 32
        private const val MAX_LENGTH_MODEL_FAMILY = 32
        private const val MAX_LENGTH_MODEL_NAME = 256
        private const val MAX_LENGTH_MANUFACTURER = 32
        private const val MAX_LENGTH_TYPE = 32
        private const val MAX_LENGTH_SCREEN_RES = 32
    }
}
