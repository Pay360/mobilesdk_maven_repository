package com.accesspaysuite.mobilesdk.utils

import io.github.alexzhirkevich.cupertino.adaptive.Theme

/**
 * Determine theme
 *
 * @return
 */
actual fun determineTheme(): Theme = Theme.Material3