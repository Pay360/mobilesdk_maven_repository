package com.accesspaysuite.mobilesdk

import android.app.Activity
import android.content.Context
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContract
import com.accesspaysuite.mobilesdk.data.standalone.PaymentIntent
import com.accesspaysuite.mobilesdk.data.standalone.PaymentResult
import kotlinx.serialization.json.Json

/**
 * # Standalone Payment Contract
 *
 * Creates a Payment Intent to launch the standalone payment page and parses the result on return
 */
class PaymentPageContract : ActivityResultContract<PaymentIntent, PaymentResult?>() {

    /**
     * ## Creates the Payment intent
     */
    override fun createIntent(context: Context, input: PaymentIntent): Intent {
        return PaymentPage.createPaymentIntent(
            context = context,
            config = input.config,
            billingAddress = input.billingAddress
        )
    }

    /**
     * ## Parses the result
     */
    override fun parseResult(resultCode: Int, intent: Intent?): PaymentResult? {
        val result: PaymentResult? =
            intent?.getStringExtra("result")?.let { Json.decodeFromString(it) }
        return when (resultCode) {
            Activity.RESULT_OK, Activity.RESULT_CANCELED -> result
            else -> PaymentResult.Failed("Unknown")
        }
    }

}