package com.accesspaysuite.mobilesdk.ui.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import dev.tmapps.konnection.Konnection
import dev.tmapps.konnection.NetworkConnection.MOBILE
import dev.tmapps.konnection.NetworkConnection.WIFI
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.map

@Composable
@ExperimentalCoroutinesApi
internal actual fun connectivityState(): State<ConnectionState> {
    val context = LocalContext.current
    return remember(context) { Konnection(context, enableDebugLog = false) }
        .observeNetworkConnection().map {
        when(it) {
            WIFI, MOBILE -> ConnectionState.Available
            null -> ConnectionState.Unavailable
        }
    }.collectAsState(initial = ConnectionState.Available)
}