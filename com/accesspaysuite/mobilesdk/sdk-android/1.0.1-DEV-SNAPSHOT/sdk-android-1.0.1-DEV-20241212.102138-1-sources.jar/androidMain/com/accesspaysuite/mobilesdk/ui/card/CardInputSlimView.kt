package com.accesspaysuite.mobilesdk.ui.card

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.widget.FrameLayout
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.Constants
import com.accesspaysuite.mobilesdk.ui.utils.addComposable

/**
 * Card input slim view
 *
 * @constructor
 *
 * @param context
 * @param attrs
 */
@ExperimentalMobileUI
class CardInputSlimView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /**
     * Composable State
     */
    private var state by mutableStateOf<CardInputSlimStyleState?>(null)

    init {
        addComposable {
            state?.let { CardInputSlim(state = it) }
                ?: Log.e(Constants.TAG, "CardInputSlimView is not initialized")
        }
    }

    /**
     * Init
     *
     * @param state
     */
    fun init(state: CardInputSlimStyleState) {
        this.state = state
    }
}