package com.accesspaysuite.mobilesdk.data.standalone

import com.accesspaysuite.mobilesdk.PaymentConfig
import com.accesspaysuite.mobilesdk.PaymentPageContract
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import kotlinx.serialization.Serializable

/**
 * ## PaymentIntent
 *
 * This class is used to create a PaymentIntent object.
 * It's a data class that contains the payment configuration and billing address
 * used for the [PaymentPageContract]
 *
 * @property config The payment configuration
 * @property billingAddress The billing address to be used for the payment
 */
@Serializable
data class PaymentIntent(
    val config: PaymentConfig,
    val billingAddress: BillingAddress?
)