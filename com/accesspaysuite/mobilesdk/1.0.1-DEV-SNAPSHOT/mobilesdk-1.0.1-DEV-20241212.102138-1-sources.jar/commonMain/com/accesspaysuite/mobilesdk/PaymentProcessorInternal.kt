package com.accesspaysuite.mobilesdk

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.callbacks.CardCallback
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.callbacks.internal.EmptyCardCallback
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CardError
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.internal.common.Card
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentInfo
import com.accesspaysuite.mobilesdk.data.internal.common.SaveCardMethods
import com.accesspaysuite.mobilesdk.data.internal.common.StoredCard
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateOutcome
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateResponse
import com.accesspaysuite.mobilesdk.data.internal.initiate.OutcomeStatus
import com.accesspaysuite.mobilesdk.modules.CardController
import com.accesspaysuite.mobilesdk.modules.DeviceInfoController
import com.accesspaysuite.mobilesdk.modules.ThreeDSController
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.repository.RequestRepositoryProd
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import io.github.aakira.napier.DebugAntilog
import io.github.aakira.napier.LogLevel
import io.github.aakira.napier.Napier
import io.github.aakira.napier.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * # Internal Payment Processor
 *
 *  The `PaymentProcessorInternal` class is responsible for handling the payment process
 *  on a platform-agnostic level. It is responsible for initiating the payment process,
 *  processing the card payment, and handling the payment result.
 *  It is not intended to be used directly by the client.
 *
 *  > The `PaymentProcessor` for each platform (e.g., Android, iOS) is responsible for
 *  > providing the platform-specific implementation of the `PaymentProcessorInternal` class.
 *  > For example: Google Pay, Apple Pay, etc.
 *
 *  ## Available functions
 *  - [initiate] - Initiates the payment processor
 *  - [processCardPayment] - Processes the card payment
 *  - [setPaymentResultCallback] - Sets the payment result callback
 *  - [setCardCallback] - Sets the card callback
 *  - [detach] - Detaches the payment processor
 *  - [isCardEntered] - Checks if the card is entered
 *
 *
 *
 *  ## Usage
 *  ```kotlin
 *  val paymentProcessor = PaymentProcessor(paymentConfig)
 *  paymentProcessor.initiate {
 *    // Payment Processor is initiated
 *  }
 *    // Set the payment result callback
 *  paymentProcessor.setPaymentResultCallback(
 *      onPaymentSuccess = {
 *          // Payment is successful
 *      },
 *      onPaymentFailed = { error ->
 *          // Payment failed
 *      },
 *      onPaymentMethodCanceled = {
 *          // Payment method is canceled
 *      }
 *  )
 *  // Set the card callback
 *  paymentProcessor.setCardCallback(
 *      onCardSubmittedSuccessfully = {
 *          // Card is submitted successfully
 *      },
 *      onCardSubmittedWithErrors = { errors ->
 *          // Card is submitted with errors
 *      }
 *  )
 *
 *
 *  // Process the card payment
 *  paymentProcessor.processCardPayment(billingAddress)
 * ```
 *
 * @property config
 * @property deviceInfoController
 * @property threeDSController
 *
 * @suppress
 */
open class PaymentProcessorInternal internal constructor(
    internal val config: PaymentConfig,
    internal val deviceInfoController: DeviceInfoController,
    private val threeDSController: ThreeDSController
) {

    internal val repository: RequestRepository by lazy { RequestRepositoryProd() }

    private var _initiated: Boolean by mutableStateOf(false)
    val initiated: Boolean get() = _initiated

    internal var initResponse: InitiateResponse? = null
    internal val canSaveCards: Boolean
        get() {
            val saveMethod = initResponse?.card?.saveMethod
            return saveMethod == SaveCardMethods.ASK || saveMethod == SaveCardMethods.YES
        }
    internal var isUsingSavedCard by mutableStateOf(false)

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var currentCard: Card? = null
    internal val paymentInfo: PaymentInfo by lazy {
        PaymentInfo(
            environment = config.environment,
            installationId = config.installationId,
            clientToken = config.clientToken,
            providerId = config.providerId,
            customer = config.customer,
            transaction = config.transaction,
            financial = config.financialServices,
            openBankingCountries = initResponse?.openBanking?.availableCountries
        )
    }

    private var cardCallback: CardCallback = EmptyCardCallback
    internal var paymentResultCallback: PaymentResultCallback = object : PaymentResultCallback {
        override fun onPaymentResult(status: Status) {
            detach()
            Napier.e {
                "If you're seeing this, it is because the PaymentResultCallback must be set before starting a payment"
            }
        }
    }

    internal open val availablePaymentMethods: List<AcceptPaymentMethods>
        get() = initResponse?.acceptPaymentMethods ?: emptyList()

    private val cardController by lazy {
        CardController(
            repository = repository,
            deviceInfoController = deviceInfoController,
            threeDSController = threeDSController,
            delegate = paymentResultCallback
        ).apply { setPaymentInfo(paymentInfo) }
    }

    internal val environment get() = config.environment

    // Initialize Logging
    init {
        Napier.base(DebugAntilog("PaysuiteSDK"))
    }

    /**
     * Initiate the payment processor
     *
     * This function is responsible for initiating the payment processor
     *
     * @param onInit
     */
    fun initiate(
        onInit: (Status) -> Unit
    ) {
        scope.launch {
            try {
                initResponse = initiateWithConfig()

                // Make sure we running on the main thread
                withContext(Dispatchers.Main) {
                    initResponse?.let {
                        onInit(Status.Initiated)
                        _initiated = true
                        PaymentProcessorFactory.create(this@PaymentProcessorInternal as PaymentProcessor)
                    } ?: {
                        val error = initResponse?.outcome?.reasonMessage ?: "Unknown error"
                        _initiated = false
                        PaymentProcessorFactory.create(null)
                        throw IllegalStateException(error)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                onInit(Status.Error(e.message ?: "Unknown error"))
            }
        }
    }

    /**
     * # Start Card Payment Process
     *
     * This function is responsible for starting the card payment process.
     *
     * @param billingAddress
     * @throws IllegalArgumentException
     */
    @Throws(IllegalArgumentException::class)
    fun processCardPayment(
        billingAddress: BillingAddress
    ) {
        performNullChecks()
        initResponse?.let {
            if (it.acceptPaymentMethods?.contains(AcceptPaymentMethods.CARD) == false) {
                paymentResultCallback.onPaymentResult(Status.Error("Card payments are not allowed"))
                return
            }
        }
        requireNotNull(currentCard) {
            "Card must be set before starting a card payment"
        }
        currentCard?.let {
            if (it.isTokenized) {
                cardController.processTokenPayment(it, billingAddress)
            } else {
                cardController.processGuestPayment(it, billingAddress)
            }
        }
    }

    fun setSaveCard(isSaveCard: Boolean) {
        if (canSaveCards) {
            cardController.saveCard = isSaveCard
        } else {
            Napier.e { "Save card is not allowed" }
        }
    }

    /**
     * Set payment result callback
     *
     * @param callback
     */
    fun setPaymentResultCallback(callback: PaymentResultCallback) {
        paymentResultCallback = object : PaymentResultCallback {
            override fun onPaymentResult(status: Status) {
                if (status !is Status.Canceled) detach()
                callback.onPaymentResult(status)
            }
        }
    }

    /**
     * Set payment result callback
     *
     * @param onPaymentSuccess
     * @param onPaymentFailed
     * @param onPaymentMethodCanceled
     * @receiver
     * @receiver
     * @receiver
     */
    fun setPaymentResultCallback(
        onPaymentSuccess: () -> Unit,
        onPaymentFailed: (String) -> Unit,
        onPaymentMethodCanceled: () -> Unit
    ) {
        paymentResultCallback = object : PaymentResultCallback {
            override fun onPaymentResult(status: Status) {
                if (status !is Status.Canceled) detach()
                when (status) {
                    is Status.Success -> onPaymentSuccess()
                    is Status.Error -> onPaymentFailed(status.message)
                    is Status.Canceled -> onPaymentMethodCanceled()
                    is Status.SessionExpired -> onPaymentFailed("Session expired")
                    else -> Unit
                }
            }
        }
    }

    /**
     * Set card callback
     *
     * @param callback
     */
    fun setCardCallback(callback: CardCallback) {
        this.cardCallback = callback
    }

    /**
     * Set card callback
     *
     * @param onCardSubmittedSuccessfully
     * @param onCardSubmittedWithErrors
     */
    fun setCardCallback(
        onCardSubmittedSuccessfully: () -> Unit,
        onCardSubmittedWithErrors: (Array<CardError>) -> Unit
    ) {
        cardCallback = object : CardCallback {
            override fun onCardSubmittedSuccessfully() =
                onCardSubmittedSuccessfully()

            override fun onCardSubmittedWithErrors(errors: Array<CardError>) =
                onCardSubmittedWithErrors(errors)
        }
    }

    /**
     * Has payment method
     *
     * @param method
     * @return
     */
    fun hasPaymentMethod(method: AcceptPaymentMethods): Boolean {
        return availablePaymentMethods.contains(method)
    }


    /**
     * Update card
     *
     * @param card
     * @param errors
     */
    internal fun updateCard(card: Card?, errors: Array<CardError>) {
        if (errors.isNotEmpty()) {
            cardCallback.onCardSubmittedWithErrors(errors)
            currentCard = null
            return
        }
        isUsingSavedCard = card?.isTokenized == true
        if (card != null) {
            currentCard = card
            cardCallback.onCardSubmittedSuccessfully()
        } else cardCallback.onCardSubmittedWithErrors(emptyArray())
    }

    /**
     * Get saved methods
     *
     * @param callback
     */
    internal suspend fun getSavedMethods(callback: (methods: List<StoredCard>) -> Unit) =
        withContext(Dispatchers.IO) {
            initResponse?.let {
                callback(it.card?.storedCards ?: emptyList())
            } ?: {
                scope.launch {
                    while (initResponse == null) {
                        delay(100)
                    }

                    callback(initResponse!!.card?.storedCards ?: emptyList())
                }
            }
        }

    /**
     * Is allowed to save card
     */
    internal suspend fun isAllowedToSaveCard(): Boolean {
        return withContext(Dispatchers.IO) {
            if (initResponse != null) {
                val saveMethod = initResponse!!.card?.saveMethod
                saveMethod == SaveCardMethods.ASK || saveMethod == SaveCardMethods.YES
            } else {
                while (initResponse == null) {
                    delay(100)
                }
                val saveMethod = initResponse!!.card?.saveMethod
                saveMethod == SaveCardMethods.ASK || saveMethod == SaveCardMethods.YES
            }
        }
    }

    /**
     * Get allowed payment methods
     *
     * @param callback
     * @receiver
     */
    internal suspend fun getAllowedPaymentMethods(callback: suspend (allowedMethods: List<AcceptPaymentMethods>) -> Unit) =
        withContext(Dispatchers.IO) {
            initResponse?.let {
                callback(it.acceptPaymentMethods!!)
            } ?: {
                scope.launch {
                    while (initResponse == null) {
                        delay(100)
                    }
                    callback(initResponse!!.acceptPaymentMethods!!)
                }
            }
        }

    val isCardEntered get() = currentCard != null && currentCard?.cardType != CardType.NONE

    /**
     * Detach the Payment Processor Instance
     *
     * Required after the Payment Processor is no longer needed
     */
    fun detach() {
        try {
            scope.cancel("Payment Processor is detached")
        } catch (_: Exception) {
            //e.printStackTrace()
        }
        PaymentProcessorFactory.dispose()
        Napier.takeLogarithm()
    }

    internal fun performNullChecks() {
        require(paymentResultCallback != PaymentResultCallback.Empty) {
            "PaymentResultCallback must be set before starting a payment"
        }
        requireNotNull(initResponse) {
            "PaymentProcessor must be initiated before starting a payment"
        }
    }

    /**
     * Initiate with config
     */
    private suspend fun initiateWithConfig() = withContext(Dispatchers.IO) {
        var initResponse: InitiateResponse? = null
        repository.initiatePayment(
            environment = config.environment,
            installationId = config.installationId,
            clientToken = config.clientToken,
            transactionType = config.transactionType,
            currencyCode = config.currencyCode,
            countryCode = config.countryCode,
            onSuccess = { response ->
                initResponse = response
            },
            onFailure = { status ->
                val error = when (status) {
                    is Status.Error -> status.message
                    else -> "Unknown error"
                }
                log(priority = LogLevel.ERROR) { "Initiate error: $error" }
                initResponse = InitiateResponse(
                    outcome = InitiateOutcome(
                        reasonMessage = error,
                        reasonCode = "3",
                        status = OutcomeStatus.FAILED
                    )
                )
            }
        )
        delay(250)
        while (initResponse == null) {
            delay(200)
        }
        return@withContext initResponse
    }

}