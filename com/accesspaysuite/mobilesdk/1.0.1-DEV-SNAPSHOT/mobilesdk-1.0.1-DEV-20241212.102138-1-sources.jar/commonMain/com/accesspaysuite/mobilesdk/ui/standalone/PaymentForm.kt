package com.accesspaysuite.mobilesdk.ui.standalone

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.PaymentProcessor
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.TransactionDetails
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.billing_address
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.billing.BillingAddressComponent
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.standalone.core.BillingCheckBox
import com.accesspaysuite.mobilesdk.ui.standalone.core.BrandingCard
import com.accesspaysuite.mobilesdk.ui.standalone.core.PaymentHeader
import org.jetbrains.compose.resources.stringResource

@OptIn(ExperimentalMobileUI::class)
@Composable
internal fun PaymentForm(
    merchantName: String?,
    processor: PaymentProcessor?,
    origBillingAddress: MutableState<BillingAddress?>,
    billingAddress: MutableState<BillingAddress?>
) {
    val transaction: TransactionDetails? by remember(
        processor,
        processor?.config,
        merchantName
    ) {
        mutableStateOf(processor?.config?.transaction)
    }
    var differentBilling by rememberSaveable { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .padding(top = 16.dp)
            .padding(horizontal = 24.dp)
            .fillMaxSize()
            .verticalScroll(state = rememberScrollState())
    ) {

        PaymentHeader(
            amount = transaction?.amount,
            currencyCode = transaction?.currency,
            //merchantName = merchantName ?: stringResource(id = R.string.payment_details)
        )

        PaymentDetails()

        if (billingAddress.value?.isEmpty() == true) {
            Text(
                modifier = Modifier.padding(bottom = 16.dp),
                text = stringResource(Res.string.billing_address),
                fontSize = 16.sp
            )
        } else {
            BillingCheckBox(
                isChecked = differentBilling,
                isEnabled = true
            ) {
                differentBilling = !differentBilling
                if (!differentBilling) {
                    billingAddress.value = origBillingAddress.value
                }
            }
        }

        val outlineColor = MaterialTheme.colorScheme.outline

        val showBillingComponent by remember(differentBilling, billingAddress.value) {
            derivedStateOf { differentBilling || (billingAddress.value?.isEmpty() == true) }
        }

        AnimatedVisibility(
            visible = showBillingComponent,
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            BillingAddressComponent(
                borderSize = 1.dp,
                borderCornerRadius = 12.dp,
                borderColor = outlineColor,
                useDropdown = true,
                fontSize = 16.sp,
                skipCheckboxUI = true,
                defaultCountryCode = "GBR",
                defaultAddress = billingAddress.value ?: origBillingAddress.value,
                onAddressFilled = {
                    billingAddress.value = it
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        BrandingCard()
    }
}