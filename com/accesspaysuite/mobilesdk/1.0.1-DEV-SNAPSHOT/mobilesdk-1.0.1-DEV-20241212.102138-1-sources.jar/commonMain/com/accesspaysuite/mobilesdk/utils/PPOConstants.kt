package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.GlobalConfig
import com.accesspaysuite.mobilesdk.data.common.Environment

internal object Constants {
    const val PPO_API_REQUEST_BASE_URL_TEST = "https://mobileapi.mite.pay360.com"
    const val PPO_API_REQUEST_BASE_URL_LIVE = "https://mobileapi.pay360.com"
    val PPO_SDK_VERSION = GlobalConfig.SDK_VERSION

    object AP {
        fun baseURL(environment: Environment): String {
            val testingUrl = "https://api.mite.pay360.com"
            val prodUrl = "https://api.pay360.com"
            return if (environment == Environment.TEST) testingUrl else prodUrl
        }

        fun authURL(environment: Environment, instId: String): String =
            "${baseURL(environment)}/acceptor/rest/authorisation/$instId/authoriseClient"

    }

    const val GUEST_AUTHORIZATION = "MOBILE_GUEST_PAYMENT"
    const val CUSTOMER_AUTHORIZATION = "MOBILE_CUSTOMER_PAYMENT"

    object ThreeDS {
        const val PARES_EVALUATION = "(function(){return JSON.parse(get3DSDataAsString()).PaRes;})();"

        const val USER_CANCELED_SESSION = "User cancelled 3DS process"
        const val PARES_PARSE_ERROR = "Couldn't parse 3DS Result"
        const val UNKNOWN_DISPLAY_ERROR = "Error displaying Web View with 3DS Requirements"
        const val INIT_EXCEPTION = "PPOThreeDS is not initialized properly, please set the activity with 'setActivity'"
    }
}