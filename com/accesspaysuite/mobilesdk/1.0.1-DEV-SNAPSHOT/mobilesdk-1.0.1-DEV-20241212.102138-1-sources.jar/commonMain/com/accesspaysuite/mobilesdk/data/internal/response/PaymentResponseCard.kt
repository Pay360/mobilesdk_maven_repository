package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseCard(
    val cardScheme: String,
    val cardUsageType: String,
    val expiryDate: String,
    val lastFour: String?,
    val maskedPan: String,
    val cardToken: String?,
)