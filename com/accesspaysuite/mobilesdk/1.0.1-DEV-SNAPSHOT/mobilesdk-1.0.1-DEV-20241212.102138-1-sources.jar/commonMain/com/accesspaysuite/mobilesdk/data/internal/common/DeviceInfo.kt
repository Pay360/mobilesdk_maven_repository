package com.accesspaysuite.mobilesdk.data.internal.common

import kotlinx.serialization.Serializable

/**
 * Represents Device Info.
 */
@Serializable
internal data class DeviceInfo(
    private val sdkInstallId: String?,
    private val osFamily: String?,
    private val osName: String?,
    private val modelFamily: String?,
    private val modelName: String?,
    private val manufacturer: String?,
    private val type: String?,
    private val screenRes: String?,
    private val screenDpi: String?,
    var sdkVersion: String? = null,
    var merchantAppName: String? = null,
    var merchantAppVersion: String? = null
)