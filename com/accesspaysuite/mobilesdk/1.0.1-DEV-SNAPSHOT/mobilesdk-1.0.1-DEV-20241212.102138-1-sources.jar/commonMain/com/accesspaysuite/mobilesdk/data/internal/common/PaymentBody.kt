package com.accesspaysuite.mobilesdk.data.internal.common

import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CustomerDetails
import com.accesspaysuite.mobilesdk.data.common.FinancialDetails
import com.accesspaysuite.mobilesdk.data.common.TransactionDetails
import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentBody(
    val threeDSecureResponse: ThreeDSResponse? = null,
    val transaction: TransactionDetails? = null,
    val customer: CustomerDetails? = null,
    val deviceInfo: DeviceInfo? = null,
    val financialServices: FinancialDetails? = null,
    val billingAddress: BillingAddress? = null,
    val registered: Boolean? = null,
    val paymentMethod: PaymentMethod? = null,
    val sdkVersion: String? = null,
    val merchantAppName: String? = null,
    val merchantAppVersion: String? = null
)