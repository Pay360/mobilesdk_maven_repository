package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.ui.theme.md_theme_dark_primary
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.billing_address_is_different
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun BillingCheckBox(
    isChecked: Boolean,
    isEnabled: Boolean,
    onToggle: () -> Unit,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .padding(vertical = 8.dp)
            .padding(bottom = 8.dp)
            .then(
                if (isEnabled) {
                    Modifier.clickable(
                        interactionSource = MutableInteractionSource(),
                        indication = null,
                        onClick = onToggle
                    )
                } else Modifier
            )
    ) {
        Text(
            modifier = Modifier.weight(1f),
            text = stringResource(Res.string.billing_address_is_different),
            style = TextStyle(
                fontWeight = FontWeight.W500,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        Switch(
            checked = isChecked,
            onCheckedChange = null,
            enabled = isEnabled,
            colors = SwitchDefaults.colors(
                checkedTrackColor = md_theme_dark_primary
            )
        )
    }
}