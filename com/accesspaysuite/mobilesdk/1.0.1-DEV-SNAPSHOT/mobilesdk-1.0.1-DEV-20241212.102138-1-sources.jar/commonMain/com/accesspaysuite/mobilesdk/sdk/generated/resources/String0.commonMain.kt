@file:OptIn(org.jetbrains.compose.resources.InternalResourceApi::class)

package com.accesspaysuite.mobilesdk.sdk.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.StringResource

private object CommonMainString0 {
  public val add_new_card: StringResource by 
      lazy { init_add_new_card() }

  public val billing_address: StringResource by 
      lazy { init_billing_address() }

  public val billing_address_is_different: StringResource by 
      lazy { init_billing_address_is_different() }

  public val cancel: StringResource by 
      lazy { init_cancel() }

  public val card_ending: StringResource by 
      lazy { init_card_ending() }

  public val card_holder_name_default: StringResource by 
      lazy { init_card_holder_name_default() }

  public val card_number: StringResource by 
      lazy { init_card_number() }

  public val card_number_placeholder: StringResource by 
      lazy { init_card_number_placeholder() }

  public val card_select: StringResource by 
      lazy { init_card_select() }

  public val cardholder_name: StringResource by 
      lazy { init_cardholder_name() }

  public val checkbox_billing_address_different: StringResource by 
      lazy { init_checkbox_billing_address_different() }

  public val checkout: StringResource by 
      lazy { init_checkout() }

  public val client_token_expired: StringResource by 
      lazy { init_client_token_expired() }

  public val cvv_default: StringResource by 
      lazy { init_cvv_default() }

  public val default: StringResource by 
      lazy { init_default() }

  public val delete: StringResource by 
      lazy { init_delete() }

  public val delete_card: StringResource by 
      lazy { init_delete_card() }

  public val delete_card_confirmation: StringResource by 
      lazy { init_delete_card_confirmation() }

  public val done: StringResource by 
      lazy { init_done() }

  public val err_cardholder_mandatory: StringResource by 
      lazy { init_err_cardholder_mandatory() }

  public val err_cvv_incomplete: StringResource by 
      lazy { init_err_cvv_incomplete() }

  public val err_cvv_mandatory: StringResource by 
      lazy { init_err_cvv_mandatory() }

  public val err_date_invalid: StringResource by 
      lazy { init_err_date_invalid() }

  public val err_date_mandatory: StringResource by 
      lazy { init_err_date_mandatory() }

  public val err_date_past: StringResource by 
      lazy { init_err_date_past() }

  public val err_pan_incomplete: StringResource by 
      lazy { init_err_pan_incomplete() }

  public val err_pan_invalid: StringResource by 
      lazy { init_err_pan_invalid() }

  public val err_pan_mandatory: StringResource by 
      lazy { init_err_pan_mandatory() }

  public val err_pan_not_accepted: StringResource by 
      lazy { init_err_pan_not_accepted() }

  public val expiration_date: StringResource by 
      lazy { init_expiration_date() }

  public val expired: StringResource by 
      lazy { init_expired() }

  public val expiry_date_default: StringResource by 
      lazy { init_expiry_date_default() }

  public val go_back_cd: StringResource by 
      lazy { init_go_back_cd() }

  public val google_pay: StringResource by 
      lazy { init_google_pay() }

  public val hint_address_city: StringResource by 
      lazy { init_hint_address_city() }

  public val hint_address_country: StringResource by 
      lazy { init_hint_address_country() }

  public val hint_address_email: StringResource by 
      lazy { init_hint_address_email() }

  public val hint_address_line1: StringResource by 
      lazy { init_hint_address_line1() }

  public val hint_address_line2: StringResource by 
      lazy { init_hint_address_line2() }

  public val hint_address_line3: StringResource by 
      lazy { init_hint_address_line3() }

  public val hint_address_line4: StringResource by 
      lazy { init_hint_address_line4() }

  public val hint_address_postcode: StringResource by 
      lazy { init_hint_address_postcode() }

  public val hint_cardholder: StringResource by 
      lazy { init_hint_cardholder() }

  public val last_four: StringResource by 
      lazy { init_last_four() }

  public val make_default: StringResource by 
      lazy { init_make_default() }

  public val new_card: StringResource by 
      lazy { init_new_card() }

  public val no_internet: StringResource by 
      lazy { init_no_internet() }

  public val no_saved_cards: StringResource by 
      lazy { init_no_saved_cards() }

  public val paid_amount: StringResource by 
      lazy { init_paid_amount() }

  public val pay: StringResource by 
      lazy { init_pay() }

  public val payment_canceled: StringResource by 
      lazy { init_payment_canceled() }

  public val payment_failed: StringResource by 
      lazy { init_payment_failed() }

  public val payment_successfully: StringResource by 
      lazy { init_payment_successfully() }

  public val paysuite_legal_notice: StringResource by 
      lazy { init_paysuite_legal_notice() }

  public val proceed: StringResource by 
      lazy { init_proceed() }

  public val reason_session_expired: StringResource by 
      lazy { init_reason_session_expired() }

  public val save_card: StringResource by 
      lazy { init_save_card() }

  public val saved_cards: StringResource by 
      lazy { init_saved_cards() }

  public val security_code: StringResource by 
      lazy { init_security_code() }

  public val try_again: StringResource by 
      lazy { init_try_again() }

  public val unknown_card: StringResource by 
      lazy { init_unknown_card() }

  public val waiting: StringResource by 
      lazy { init_waiting() }

  public val you_have_to_pay: StringResource by 
      lazy { init_you_have_to_pay() }
}

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("add_new_card", CommonMainString0.add_new_card)
  map.put("billing_address", CommonMainString0.billing_address)
  map.put("billing_address_is_different", CommonMainString0.billing_address_is_different)
  map.put("cancel", CommonMainString0.cancel)
  map.put("card_ending", CommonMainString0.card_ending)
  map.put("card_holder_name_default", CommonMainString0.card_holder_name_default)
  map.put("card_number", CommonMainString0.card_number)
  map.put("card_number_placeholder", CommonMainString0.card_number_placeholder)
  map.put("card_select", CommonMainString0.card_select)
  map.put("cardholder_name", CommonMainString0.cardholder_name)
  map.put("checkbox_billing_address_different",
      CommonMainString0.checkbox_billing_address_different)
  map.put("checkout", CommonMainString0.checkout)
  map.put("client_token_expired", CommonMainString0.client_token_expired)
  map.put("cvv_default", CommonMainString0.cvv_default)
  map.put("default", CommonMainString0.default)
  map.put("delete", CommonMainString0.delete)
  map.put("delete_card", CommonMainString0.delete_card)
  map.put("delete_card_confirmation", CommonMainString0.delete_card_confirmation)
  map.put("done", CommonMainString0.done)
  map.put("err_cardholder_mandatory", CommonMainString0.err_cardholder_mandatory)
  map.put("err_cvv_incomplete", CommonMainString0.err_cvv_incomplete)
  map.put("err_cvv_mandatory", CommonMainString0.err_cvv_mandatory)
  map.put("err_date_invalid", CommonMainString0.err_date_invalid)
  map.put("err_date_mandatory", CommonMainString0.err_date_mandatory)
  map.put("err_date_past", CommonMainString0.err_date_past)
  map.put("err_pan_incomplete", CommonMainString0.err_pan_incomplete)
  map.put("err_pan_invalid", CommonMainString0.err_pan_invalid)
  map.put("err_pan_mandatory", CommonMainString0.err_pan_mandatory)
  map.put("err_pan_not_accepted", CommonMainString0.err_pan_not_accepted)
  map.put("expiration_date", CommonMainString0.expiration_date)
  map.put("expired", CommonMainString0.expired)
  map.put("expiry_date_default", CommonMainString0.expiry_date_default)
  map.put("go_back_cd", CommonMainString0.go_back_cd)
  map.put("google_pay", CommonMainString0.google_pay)
  map.put("hint_address_city", CommonMainString0.hint_address_city)
  map.put("hint_address_country", CommonMainString0.hint_address_country)
  map.put("hint_address_email", CommonMainString0.hint_address_email)
  map.put("hint_address_line1", CommonMainString0.hint_address_line1)
  map.put("hint_address_line2", CommonMainString0.hint_address_line2)
  map.put("hint_address_line3", CommonMainString0.hint_address_line3)
  map.put("hint_address_line4", CommonMainString0.hint_address_line4)
  map.put("hint_address_postcode", CommonMainString0.hint_address_postcode)
  map.put("hint_cardholder", CommonMainString0.hint_cardholder)
  map.put("last_four", CommonMainString0.last_four)
  map.put("make_default", CommonMainString0.make_default)
  map.put("new_card", CommonMainString0.new_card)
  map.put("no_internet", CommonMainString0.no_internet)
  map.put("no_saved_cards", CommonMainString0.no_saved_cards)
  map.put("paid_amount", CommonMainString0.paid_amount)
  map.put("pay", CommonMainString0.pay)
  map.put("payment_canceled", CommonMainString0.payment_canceled)
  map.put("payment_failed", CommonMainString0.payment_failed)
  map.put("payment_successfully", CommonMainString0.payment_successfully)
  map.put("paysuite_legal_notice", CommonMainString0.paysuite_legal_notice)
  map.put("proceed", CommonMainString0.proceed)
  map.put("reason_session_expired", CommonMainString0.reason_session_expired)
  map.put("save_card", CommonMainString0.save_card)
  map.put("saved_cards", CommonMainString0.saved_cards)
  map.put("security_code", CommonMainString0.security_code)
  map.put("try_again", CommonMainString0.try_again)
  map.put("unknown_card", CommonMainString0.unknown_card)
  map.put("waiting", CommonMainString0.waiting)
  map.put("you_have_to_pay", CommonMainString0.you_have_to_pay)
}

internal val Res.string.add_new_card: StringResource
  get() = CommonMainString0.add_new_card

private fun init_add_new_card(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:add_new_card", "add_new_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    10, 36),
    )
)

internal val Res.string.billing_address: StringResource
  get() = CommonMainString0.billing_address

private fun init_billing_address(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:billing_address", "billing_address",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    124, 43),
    )
)

internal val Res.string.billing_address_is_different: StringResource
  get() = CommonMainString0.billing_address_is_different

private fun init_billing_address_is_different(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:billing_address_is_different", "billing_address_is_different",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    47, 76),
    )
)

internal val Res.string.cancel: StringResource
  get() = CommonMainString0.cancel

private fun init_cancel(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:cancel", "cancel",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    168, 22),
    )
)

internal val Res.string.card_ending: StringResource
  get() = CommonMainString0.card_ending

private fun init_card_ending(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:card_ending", "card_ending",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    191, 39),
    )
)

internal val Res.string.card_holder_name_default: StringResource
  get() = CommonMainString0.card_holder_name_default

private fun init_card_holder_name_default(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:card_holder_name_default", "card_holder_name_default",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    231, 52),
    )
)

internal val Res.string.card_number: StringResource
  get() = CommonMainString0.card_number

private fun init_card_number(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:card_number", "card_number",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    344, 35),
    )
)

internal val Res.string.card_number_placeholder: StringResource
  get() = CommonMainString0.card_number_placeholder

private fun init_card_number_placeholder(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:card_number_placeholder", "card_number_placeholder",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    284, 59),
    )
)

internal val Res.string.card_select: StringResource
  get() = CommonMainString0.card_select

private fun init_card_select(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:card_select", "card_select",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    380, 27),
    )
)

internal val Res.string.cardholder_name: StringResource
  get() = CommonMainString0.cardholder_name

private fun init_cardholder_name(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:cardholder_name", "cardholder_name",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    408, 47),
    )
)

internal val Res.string.checkbox_billing_address_different: StringResource
  get() = CommonMainString0.checkbox_billing_address_different

private fun init_checkbox_billing_address_different(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:checkbox_billing_address_different", "checkbox_billing_address_different",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    456, 106),
    )
)

internal val Res.string.checkout: StringResource
  get() = CommonMainString0.checkout

private fun init_checkout(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:checkout", "checkout",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    563, 28),
    )
)

internal val Res.string.client_token_expired: StringResource
  get() = CommonMainString0.client_token_expired

private fun init_client_token_expired(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:client_token_expired", "client_token_expired",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    592, 56),
    )
)

internal val Res.string.cvv_default: StringResource
  get() = CommonMainString0.cvv_default

private fun init_cvv_default(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:cvv_default", "cvv_default",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    649, 23),
    )
)

internal val Res.string.default: StringResource
  get() = CommonMainString0.default

private fun init_default(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:default", "default",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    673, 27),
    )
)

internal val Res.string.delete: StringResource
  get() = CommonMainString0.delete

private fun init_delete(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:delete", "delete",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    866, 22),
    )
)

internal val Res.string.delete_card: StringResource
  get() = CommonMainString0.delete_card

private fun init_delete_card(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:delete_card", "delete_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    830, 35),
    )
)

internal val Res.string.delete_card_confirmation: StringResource
  get() = CommonMainString0.delete_card_confirmation

private fun init_delete_card_confirmation(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:delete_card_confirmation", "delete_card_confirmation",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    701, 128),
    )
)

internal val Res.string.done: StringResource
  get() = CommonMainString0.done

private fun init_done(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:done", "done",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    889, 20),
    )
)

internal val Res.string.err_cardholder_mandatory: StringResource
  get() = CommonMainString0.err_cardholder_mandatory

private fun init_err_cardholder_mandatory(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_cardholder_mandatory", "err_cardholder_mandatory",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    910, 72),
    )
)

internal val Res.string.err_cvv_incomplete: StringResource
  get() = CommonMainString0.err_cvv_incomplete

private fun init_err_cvv_incomplete(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_cvv_incomplete", "err_cvv_incomplete",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    983, 62),
    )
)

internal val Res.string.err_cvv_mandatory: StringResource
  get() = CommonMainString0.err_cvv_mandatory

private fun init_err_cvv_mandatory(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_cvv_mandatory", "err_cvv_mandatory",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1046, 61),
    )
)

internal val Res.string.err_date_invalid: StringResource
  get() = CommonMainString0.err_date_invalid

private fun init_err_date_invalid(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_date_invalid", "err_date_invalid",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1108, 56),
    )
)

internal val Res.string.err_date_mandatory: StringResource
  get() = CommonMainString0.err_date_mandatory

private fun init_err_date_mandatory(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_date_mandatory", "err_date_mandatory",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1165, 58),
    )
)

internal val Res.string.err_date_past: StringResource
  get() = CommonMainString0.err_date_past

private fun init_err_date_past(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:err_date_past", "err_date_past",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1224, 65),
    )
)

internal val Res.string.err_pan_incomplete: StringResource
  get() = CommonMainString0.err_pan_incomplete

private fun init_err_pan_incomplete(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_pan_incomplete", "err_pan_incomplete",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1290, 62),
    )
)

internal val Res.string.err_pan_invalid: StringResource
  get() = CommonMainString0.err_pan_invalid

private fun init_err_pan_invalid(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:err_pan_invalid", "err_pan_invalid",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1353, 51),
    )
)

internal val Res.string.err_pan_mandatory: StringResource
  get() = CommonMainString0.err_pan_mandatory

private fun init_err_pan_mandatory(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_pan_mandatory", "err_pan_mandatory",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1405, 57),
    )
)

internal val Res.string.err_pan_not_accepted: StringResource
  get() = CommonMainString0.err_pan_not_accepted

private fun init_err_pan_not_accepted(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:err_pan_not_accepted", "err_pan_not_accepted",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1463, 60),
    )
)

internal val Res.string.expiration_date: StringResource
  get() = CommonMainString0.expiration_date

private fun init_expiration_date(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:expiration_date", "expiration_date",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1524, 47),
    )
)

internal val Res.string.expired: StringResource
  get() = CommonMainString0.expired

private fun init_expired(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:expired", "expired",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1572, 27),
    )
)

internal val Res.string.expiry_date_default: StringResource
  get() = CommonMainString0.expiry_date_default

private fun init_expiry_date_default(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:expiry_date_default", "expiry_date_default",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1600, 35),
    )
)

internal val Res.string.go_back_cd: StringResource
  get() = CommonMainString0.go_back_cd

private fun init_go_back_cd(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:go_back_cd", "go_back_cd",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1636, 30),
    )
)

internal val Res.string.google_pay: StringResource
  get() = CommonMainString0.google_pay

private fun init_google_pay(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:google_pay", "google_pay",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1667, 34),
    )
)

internal val Res.string.hint_address_city: StringResource
  get() = CommonMainString0.hint_address_city

private fun init_hint_address_city(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_city", "hint_address_city",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1702, 33),
    )
)

internal val Res.string.hint_address_country: StringResource
  get() = CommonMainString0.hint_address_country

private fun init_hint_address_country(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_country", "hint_address_country",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1736, 40),
    )
)

internal val Res.string.hint_address_email: StringResource
  get() = CommonMainString0.hint_address_email

private fun init_hint_address_email(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_email", "hint_address_email",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1777, 34),
    )
)

internal val Res.string.hint_address_line1: StringResource
  get() = CommonMainString0.hint_address_line1

private fun init_hint_address_line1(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_line1", "hint_address_line1",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1812, 46),
    )
)

internal val Res.string.hint_address_line2: StringResource
  get() = CommonMainString0.hint_address_line2

private fun init_hint_address_line2(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_line2", "hint_address_line2",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1859, 46),
    )
)

internal val Res.string.hint_address_line3: StringResource
  get() = CommonMainString0.hint_address_line3

private fun init_hint_address_line3(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_line3", "hint_address_line3",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1906, 46),
    )
)

internal val Res.string.hint_address_line4: StringResource
  get() = CommonMainString0.hint_address_line4

private fun init_hint_address_line4(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_line4", "hint_address_line4",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    1953, 46),
    )
)

internal val Res.string.hint_address_postcode: StringResource
  get() = CommonMainString0.hint_address_postcode

private fun init_hint_address_postcode(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:hint_address_postcode", "hint_address_postcode",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2000, 41),
    )
)

internal val Res.string.hint_cardholder: StringResource
  get() = CommonMainString0.hint_cardholder

private fun init_hint_cardholder(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:hint_cardholder", "hint_cardholder",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2042, 39),
    )
)

internal val Res.string.last_four: StringResource
  get() = CommonMainString0.last_four

private fun init_last_four(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:last_four", "last_four",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2082, 29),
    )
)

internal val Res.string.make_default: StringResource
  get() = CommonMainString0.make_default

private fun init_make_default(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:make_default", "make_default",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2112, 36),
    )
)

internal val Res.string.new_card: StringResource
  get() = CommonMainString0.new_card

private fun init_new_card(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:new_card", "new_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2149, 28),
    )
)

internal val Res.string.no_internet: StringResource
  get() = CommonMainString0.no_internet

private fun init_no_internet(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:no_internet", "no_internet",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2178, 35),
    )
)

internal val Res.string.no_saved_cards: StringResource
  get() = CommonMainString0.no_saved_cards

private fun init_no_saved_cards(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:no_saved_cards", "no_saved_cards",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2214, 42),
    )
)

internal val Res.string.paid_amount: StringResource
  get() = CommonMainString0.paid_amount

private fun init_paid_amount(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:paid_amount", "paid_amount",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2257, 39),
    )
)

internal val Res.string.pay: StringResource
  get() = CommonMainString0.pay

private fun init_pay(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:pay", "pay",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2740, 15),
    )
)

internal val Res.string.payment_canceled: StringResource
  get() = CommonMainString0.payment_canceled

private fun init_payment_canceled(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:payment_canceled", "payment_canceled",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2297, 48),
    )
)

internal val Res.string.payment_failed: StringResource
  get() = CommonMainString0.payment_failed

private fun init_payment_failed(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:payment_failed", "payment_failed",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2346, 42),
    )
)

internal val Res.string.payment_successfully: StringResource
  get() = CommonMainString0.payment_successfully

private fun init_payment_successfully(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:payment_successfully", "payment_successfully",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2389, 56),
    )
)

internal val Res.string.paysuite_legal_notice: StringResource
  get() = CommonMainString0.paysuite_legal_notice

private fun init_paysuite_legal_notice(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:paysuite_legal_notice", "paysuite_legal_notice",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2446, 293),
    )
)

internal val Res.string.proceed: StringResource
  get() = CommonMainString0.proceed

private fun init_proceed(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:proceed", "proceed",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2756, 27),
    )
)

internal val Res.string.reason_session_expired: StringResource
  get() = CommonMainString0.reason_session_expired

private fun init_reason_session_expired(): StringResource =
    org.jetbrains.compose.resources.StringResource(
  "string:reason_session_expired", "reason_session_expired",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2784, 86),
    )
)

internal val Res.string.save_card: StringResource
  get() = CommonMainString0.save_card

private fun init_save_card(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:save_card", "save_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2871, 33),
    )
)

internal val Res.string.saved_cards: StringResource
  get() = CommonMainString0.saved_cards

private fun init_saved_cards(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:saved_cards", "saved_cards",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2905, 35),
    )
)

internal val Res.string.security_code: StringResource
  get() = CommonMainString0.security_code

private fun init_security_code(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:security_code", "security_code",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2941, 41),
    )
)

internal val Res.string.try_again: StringResource
  get() = CommonMainString0.try_again

private fun init_try_again(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:try_again", "try_again",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    2983, 29),
    )
)

internal val Res.string.unknown_card: StringResource
  get() = CommonMainString0.unknown_card

private fun init_unknown_card(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:unknown_card", "unknown_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    3013, 36),
    )
)

internal val Res.string.waiting: StringResource
  get() = CommonMainString0.waiting

private fun init_waiting(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:waiting", "waiting",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    3050, 39),
    )
)

internal val Res.string.you_have_to_pay: StringResource
  get() = CommonMainString0.you_have_to_pay

private fun init_you_have_to_pay(): StringResource = org.jetbrains.compose.resources.StringResource(
  "string:you_have_to_pay", "you_have_to_pay",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/values/strings.commonMain.cvr",
    3090, 43),
    )
)
