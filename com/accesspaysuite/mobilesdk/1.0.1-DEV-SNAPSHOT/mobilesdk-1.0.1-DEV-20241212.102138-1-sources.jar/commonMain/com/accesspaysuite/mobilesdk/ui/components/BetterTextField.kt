package com.accesspaysuite.mobilesdk.ui.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

@Composable
internal expect fun BetterTextField(
    modifier: Modifier = Modifier,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardOptions: KeyboardOptions = KeyboardOptions(),
    textStyle: TextStyle = TextStyle.Default.copy(color = LocalContentColor.current),
    isEnabled: Boolean = true,
    isError: Boolean = false,
    isOutlined: Boolean = false,
    singleLine: Boolean = false,
    shape: Shape = TextFieldDefaults.shape,
    borderColor: Color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
    placeholder: (@Composable () -> Unit)? = null,
    label: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    interactionSource: MutableInteractionSource = MutableInteractionSource(),
    visualTransformation: VisualTransformation = VisualTransformation.None,
    contentPadding: PaddingValues = contentPaddingFor(isOutlined)
)

internal fun contentPaddingFor(isOutlined: Boolean): PaddingValues {
    return if (isOutlined) PaddingValues(16.dp) else PaddingValues(0.dp)
}
