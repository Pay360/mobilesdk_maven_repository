package com.accesspaysuite.mobilesdk.ui.billing

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.common.Country
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.checkbox_billing_address_different
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_city
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_country
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_email
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_line1
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_line2
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_line3
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_line4
import com.accesspaysuite.mobilesdk.sdk.generated.resources.hint_address_postcode
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.BetterTextField
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.components.CountryDropdown
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.theme.lightColorScheme
import com.accesspaysuite.mobilesdk.ui.utils.RegexChecks
import io.github.alexzhirkevich.LocalContentColor
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveSwitch
import io.github.alexzhirkevich.cupertino.adaptive.ExperimentalAdaptiveApi
import kotlinx.serialization.json.Json
import org.jetbrains.compose.resources.stringResource

/**
 * # Billing Address Component
 *
 * @param modifier The modifier to apply to this layout.
 * @param state The billing address state.
 * @param isOutlined Is outlined.
 */
@ExperimentalMobileUI
@Composable
fun BillingAddressComponent(
    modifier: Modifier = Modifier,
    state: BillingAddressState,
    isOutlined: Boolean = true
) = BillingAddressComponent(
    modifier = modifier,
    fontSize = state.fontSize.sp,
    fontWeight = state.fontWeight,
    borderSize = state.borderSize.dp,
    borderCornerRadius = state.borderCornerRadius.dp,
    borderColor = state.borderColor?.let { Color(it) },
    defaultCountryCode = state.defaultCountryCode,
    useDropdown = state.useDropdown,
    showAddressLine2 = state.showAddressLine2,
    showAddressLine3 = state.showAddressLine3,
    showAddressLine4 = state.showAddressLine4,
    skipCheckboxUI = state.skipCheckboxUI,
    defaultAddress = state.defaultAddress,
    onAddressFilled = state.onAddressFilled,
    isOutlined = isOutlined
)

/**
 * # Billing Address Component
 *
 * @param modifier The modifier to apply to this layout.
 * @param fontSize The font size.
 * @param fontWeight The font weight.
 * @param borderSize The border size.
 * @param borderCornerRadius The border corner radius.
 * @param borderColor The border color.
 * @param defaultCountryCode The default country code.
 * @param useDropdown Use dropdown.
 * @param showAddressLine2 Show address line 2.
 * @param showAddressLine3 Show address line 3.
 * @param showAddressLine4 Show address line 4.
 * @param skipCheckboxUI Skip checkbox UI. Adds a checkbox to enable the component control of the billing Address
 * if the billingAddress is different than the one in the defaultAddress.
 * @param defaultAddress The default address.
 * @param onAddressFilled The on address filled.
 * @param isOutlined Is outlined.
 * @param lightColorScheme The light color scheme.
 * @param darkColorScheme The dark color scheme.
 */
@OptIn(ExperimentalAdaptiveApi::class)
@ExperimentalMobileUI
@Composable
fun BillingAddressComponent(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 14.sp,
    fontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    borderSize: Dp = 1.dp,
    borderCornerRadius: Dp = 4.dp,
    borderColor: Color? = null,
    defaultCountryCode: String = "GBR",
    useDropdown: Boolean = false,
    showAddressLine2: Boolean = true,
    showAddressLine3: Boolean = false,
    showAddressLine4: Boolean = false,
    skipCheckboxUI: Boolean = false,
    defaultAddress: BillingAddress? = null,
    onAddressFilled: (BillingAddress) -> Unit,
    isOutlined: Boolean = true,
) {
    PaymentUITheme {
        var address by remember { mutableStateOf(defaultAddress ?: BillingAddress()) }
        var billingIsDifferent by remember { mutableStateOf(true) }
        val countryList = remember { mutableStateListOf<Country>() }

        LaunchedEffect(Unit) {
            val json = Res.readBytes("files/countries_alpha3.json").decodeToString()
            val countries = Json.decodeFromString<List<Country>>(json)
            countryList.clear()
            countryList.addAll(countries)
        }

        LaunchedEffect(address) {
            onAddressFilled(address)
        }

        Column(
            modifier = modifier.fillMaxWidth()
        ) {
            if (!skipCheckboxUI) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(Res.string.checkbox_billing_address_different),
                        fontSize = fontSize,
                        fontWeight = fontWeight.value
                    )
                    AdaptiveSwitch(
                        checked = billingIsDifferent,
                        onCheckedChange = { isChecked -> billingIsDifferent = isChecked }
                    )
                }
            }

            val currentBorderColor = borderColor ?: MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            val localModifier = Modifier
                .fillMaxWidth()
            val contentColor = LocalContentColor.current
            val textStyle = remember(fontSize, fontWeight, contentColor) {
                TextStyle.Default.copy(
                    color = contentColor,
                    fontSize = fontSize,
                    fontWeight = fontWeight.value
                )
            }
            val shape = RoundedCornerShape(size = borderCornerRadius)

            AnimatedVisibility(
                visible = billingIsDifferent,
                enter = enterAnimation,
                exit = exitAnimation
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BillingAddressField(
                        modifier = localModifier,
                        value = address.line1,
                        placeholderText = stringResource(Res.string.hint_address_line1),
                        textStyle = textStyle,
                        borderColor = currentBorderColor,
                        shape = shape,
                        isOutlined = isOutlined,
                        onValueChange = {
                            address = address.copy(line1 = it)
                        }
                    )

                    if (showAddressLine2) {
                        BillingAddressField(
                            modifier = localModifier,
                            value = address.line2,
                            placeholderText = stringResource(Res.string.hint_address_line2),
                            textStyle = textStyle,
                            borderColor = currentBorderColor,
                            shape = shape,
                            isOutlined = isOutlined,
                            onValueChange = {
                                address = address.copy(line2 = it)
                            }
                        )
                    }

                    if (showAddressLine3) {
                        BillingAddressField(
                            modifier = localModifier,
                            value = address.line3,
                            placeholderText = stringResource(Res.string.hint_address_line3),
                            textStyle = textStyle,
                            borderColor = currentBorderColor,
                            shape = shape,
                            isOutlined = isOutlined,
                            onValueChange = {
                                address = address.copy(line3 = it)
                            }
                        )
                    }

                    if (showAddressLine4) {
                        BillingAddressField(
                            modifier = localModifier,
                            value = address.line4,
                            placeholderText = stringResource(Res.string.hint_address_line4),
                            textStyle = textStyle,
                            borderColor = currentBorderColor,
                            shape = shape,
                            isOutlined = isOutlined,
                            onValueChange = {
                                address = address.copy(line4 = it)
                            }
                        )
                    }

                    BillingAddressField(
                        modifier = localModifier,
                        value = address.city,
                        placeholderText = stringResource(Res.string.hint_address_city),
                        textStyle = textStyle,
                        borderColor = currentBorderColor,
                        shape = shape,
                        isOutlined = isOutlined,
                        onValueChange = {
                            address = address.copy(city = it)
                        }
                    )

                    if (useDropdown) {
                        CountryDropdown(
                            countryList = countryList,
                            initialCountryCode = defaultCountryCode,
                            modifier = localModifier
                                .clip(shape = shape)
                                .border(
                                    width = borderSize,
                                    color = currentBorderColor,
                                    shape = shape
                                ),
                            textStyle = textStyle,
                        ) {
                            address = address.copy(
                                countryCode = it.alpha3
                            )
                        }
                    } else {
                        var countryName by remember {
                            mutableStateOf(countryList.firstOrNull { it.alpha3 == defaultCountryCode }?.name)
                        }

                        BillingAddressField(
                            modifier = localModifier,
                            value = countryName,
                            placeholderText = stringResource(Res.string.hint_address_country),
                            textStyle = textStyle,
                            borderColor = currentBorderColor,
                            shape = shape,
                            isOutlined = isOutlined,
                            onValueChange = { newValue ->
                                countryName = newValue
                                address = address.copy(countryCode = countryList.firstOrNull {
                                    it.name.contains(
                                        countryName.toString(),
                                        true
                                    )
                                }?.alpha3)
                            },
                            isError = countryList.firstOrNull {
                                it.name.contains(countryName.toString(), true)
                            } != null
                        )
                    }

                    BillingAddressField(
                        modifier = localModifier,
                        value = address.postcode,
                        placeholderText = stringResource(Res.string.hint_address_postcode),
                        textStyle = textStyle,
                        borderColor = currentBorderColor,
                        shape = shape,
                        isOutlined = isOutlined,
                        onValueChange = {
                            address = address.copy(postcode = it)
                        },
                        isError = (if (address.countryCode.toString().uppercase() == "GBR") {
                            FieldValidation.UK_POSTCODE
                        } else {
                            FieldValidation.NONE
                        }).isValid(address.postcode.toString()) && address.postcode.toString().isNotEmpty()
                    )

                    BillingAddressField(
                        modifier = localModifier,
                        value = address.email,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        placeholderText = stringResource(Res.string.hint_address_email),
                        textStyle = textStyle,
                        borderColor = currentBorderColor,
                        shape = shape,
                        isOutlined = isOutlined,
                        onValueChange = {
                            address = address.copy(email = it)
                        },
                        isError = FieldValidation.EMAIL.isValid(address.email.toString())
                    )
                }
            }

        }
    }

}

@Composable
private fun BillingAddressField(
    modifier: Modifier = Modifier,
    value: String?,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    placeholderText: String,
    textStyle: TextStyle,
    borderColor: Color,
    shape: Shape,
    isOutlined: Boolean,
    onValueChange: (String) -> Unit,
    isError: Boolean = false
) {
    BetterTextField(
        modifier = modifier,
        value = value ?: "",
        keyboardOptions = keyboardOptions,
        placeholder = {
            Text(
                text = placeholderText,
                overflow = TextOverflow.Ellipsis,
                maxLines = 1
            )
        },
        textStyle = textStyle,
        borderColor = borderColor,
        shape = shape,
        isOutlined = isOutlined,
        onValueChange = onValueChange,
        isError = isError
    )
}

private enum class FieldValidation {
    /**
     * None
     *
     * @constructor Create None
     */
    NONE {
        override fun isValid(text: String): Boolean = true
    },

    /**
     * Email
     *
     * @constructor Create Email
     */
    EMAIL {
        override fun isValid(text: String): Boolean =
            text.matches(RegexChecks.EMAIL.toRegex())
    },

    /**
     * Uk Postcode
     *
     * @constructor Create Uk Postcode
     */
    UK_POSTCODE {
        override fun isValid(text: String): Boolean =
            text.matches(RegexChecks.UK_POSTCODE.toRegex())
    };

    /**
     * Is valid
     *
     * @param text
     * @return
     */
    abstract fun isValid(text: String): Boolean
}