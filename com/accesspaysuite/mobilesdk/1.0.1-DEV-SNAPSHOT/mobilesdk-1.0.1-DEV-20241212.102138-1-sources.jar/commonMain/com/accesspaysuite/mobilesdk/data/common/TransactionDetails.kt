package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Transaction Details
 * This class is used to hold the transaction details for the payment request.
 *
 * ### Required
 * - **currency**
 * - **amount**
 *
 * ### Optional
 * - **description**
 * - **merchantRef**
 * - **recurring**
 * - **deferred**
 * - **continuousAuthorityAgreement**
 *
 * @property currency The currency of the transaction. (e.g. "GBP"). Currency Code format: ISO 4217 - ALPHA-3.
 * @property amount The amount of the transaction. (e.g. 10.0).
 * @property description The description of the transaction. (e.g. "Payment for the order").
 * @property merchantRef The merchant reference of the transaction. (e.g. "Order_123"). Recommended to be unique. Used to identify the transaction later.
 * @property recurring Set this field if you want to start a recurring Continuous Authority relationship from this transaction.
 * Possible values: `true`, `false`, `null`.
 * @property deferred Use the “deferred” indicator with the Payment request to indicate that you only want to perform an authorisation.
 * Possible values: `true`, `false`, `null`.
 * @property continuousAuthorityAgreement The continuous authority agreement of the transaction. [ContinuousAuthorityAgreement]
 */
@Parcelize
@Serializable
data class TransactionDetails(
    internal val transactionId: String? = null,
    val currency: String? = null,
    val amount: Double? = null,
    val description: String? = null,
    val merchantRef: String? = null,
    val recurring: Boolean? = null,
    val deferred: Boolean? = null,
    val continuousAuthorityAgreement: ContinuousAuthorityAgreement? = null
) : Parcelable
