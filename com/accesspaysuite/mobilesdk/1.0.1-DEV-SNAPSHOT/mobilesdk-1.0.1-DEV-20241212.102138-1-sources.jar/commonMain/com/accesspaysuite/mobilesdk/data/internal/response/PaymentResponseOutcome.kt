package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseOutcome(
    val reasonCode: String,
    val reasonMessage: String?,
    val status: String
)