package com.accesspaysuite.mobilesdk.data.internal.common

import kotlinx.serialization.Serializable

@Serializable
internal data class ThreeDSResponse(
    val pares: String?
)