package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.cardmanager.CustomerMethod

internal interface CardManagerRepository {

    suspend fun getCustomerId(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String
    ): String?

    suspend fun getCustomerMethods(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String
    ): List<CustomerMethod>

    suspend fun deleteCard(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String,
        cardToken: String
    ): Boolean

    suspend fun makePrimaryCard(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String,
        cardToken: String
    ): Boolean

/*    suspend fun updateCard(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String,
        cardToken: String
    ): Boolean*/

}