package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Financial Service Details
 *
 * > The [FinancialDetails] class is responsible for setting the financial service details.
 * > **Mandatory for UK/Europe-based MCC 6012/6051/some 7299 merchants**
 *
 *
 * ## All parameters are mandatory
 * @property dateOfBirth Date of birth of the loan recipient, in YYYYMMDD format. For example, for Jan 2nd, 1980, this would be “19800102”
 * @property surname Surname of the loan recipient; up to six characters, excluding numbers or special characters.
 * If the name is longer than six characters, then provide the first six.
 * For example, for “Smith”, this would be “Smith”; for “Williams”, this would be “Willia”.
 * @property accountNumber Account number used to identify the customer or loan.
 * If this is a PAN, then provide the first six and last four digits of the PAN.
 * Otherwise, provide up to ten characters of the account number.
 * @property postCode First part of the postal code of the loan recipient; up to six characters.
 * For example, if the postal code is “EC2A 1AE”, this would be “EC2A”.
 */
@Parcelize
@Serializable
data class FinancialDetails(
    val dateOfBirth: String? = null,
    val surname: String? = null,
    val accountNumber: String? = null,
    val postCode: String? = null
) : Parcelable
