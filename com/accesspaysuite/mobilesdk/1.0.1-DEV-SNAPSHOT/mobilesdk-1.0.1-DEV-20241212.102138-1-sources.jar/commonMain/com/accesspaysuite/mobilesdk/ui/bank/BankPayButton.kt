package com.accesspaysuite.mobilesdk.ui.bank

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import com.accesspaysuite.mobilesdk.utils.hasPaymentMethod

/**
 * Bank pay button
 *
 * @param state
 * @param modifier
 */
@Suppress("UNUSED_PARAMETER")
@Composable
internal fun BankPayButton(
    state: BankPayState,
    modifier: Modifier = Modifier
) {
    val methodAvailable by PaymentProcessorFactory.hasPaymentMethod(AcceptPaymentMethods.CARD)
    AnimatedVisibility(
        visible = methodAvailable,
        enter = enterAnimation,
        exit = exitAnimation
    ) {
        PaymentUITheme {
            Button(
                onClick = {
                    /*state.processor?.proceedBankPayment(
                    countryCode = state.countryCode,
                    callback = state.callback
                )*/
                },
                modifier = modifier
            ) {
                Text("Pay with Bank")
            }
        }
    }
}