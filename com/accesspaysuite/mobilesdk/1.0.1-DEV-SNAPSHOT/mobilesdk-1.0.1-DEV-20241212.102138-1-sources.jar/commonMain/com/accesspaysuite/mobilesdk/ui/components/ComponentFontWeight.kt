package com.accesspaysuite.mobilesdk.ui.components

import androidx.compose.ui.text.font.FontWeight

/**
 * Component font weight
 *
 * @property value
 * @constructor Create empty Component font weight
 */
enum class ComponentFontWeight(val value: FontWeight) {
    /**
     * Normal
     *
     * @constructor Create Normal
     */
    NORMAL(FontWeight.Normal),

    /**
     * Bold
     *
     * @constructor Create Bold
     */
    BOLD(FontWeight.Bold),

    /**
     * Light
     *
     * @constructor Create Light
     */
    LIGHT(FontWeight.Light);
}