package com.accesspaysuite.mobilesdk.data.internal.cardmanager

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Serializable
@Parcelize
internal data class CustomerCard(
    val cardHolderName: String,
    val cardNickname: String,
    val cardScheme: String,
    val cardToken: String,
    val cardType: String,
    val cardUsageType: String,
    val expiryDate: String,
    val issuer: String,
    val issuerCountry: String,
    val maskedPan: String
): Parcelable