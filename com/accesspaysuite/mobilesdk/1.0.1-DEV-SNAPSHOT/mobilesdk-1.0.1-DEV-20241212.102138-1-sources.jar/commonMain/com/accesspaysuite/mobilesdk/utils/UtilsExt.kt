package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import kotlinx.datetime.LocalDateTime
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime

internal fun String?.noWhitespace(): String = this?.replace(" ", "")?.replace("\t", "").toString()

internal fun PaymentType.toAPIRequestType(): APIRequestType = when (this) {
    PaymentType.GuestPayment -> APIRequestType.APIRequestGuestPayment
    PaymentType.Verify -> APIRequestType.APIRequestVerify
    PaymentType.TokenPayment -> APIRequestType.APIRequestTokenPayment
    PaymentType.GooglePayPayment -> APIRequestType.APIRequestGooglePayPayment
    PaymentType.ApplePayPayment -> APIRequestType.APIRequestApplePayPayment
}

internal fun APIRequestType?.toPaymentType(): PaymentType = when (this) {
    APIRequestType.APIRequestGuestPayment -> PaymentType.GuestPayment
    APIRequestType.APIRequestVerify -> PaymentType.Verify
    APIRequestType.APIRequestTokenPayment -> PaymentType.TokenPayment
    APIRequestType.APIRequestGooglePayPayment -> PaymentType.GooglePayPayment
    APIRequestType.APIRequestApplePayPayment -> PaymentType.ApplePayPayment
    else -> PaymentType.GuestPayment
}

internal fun isDateInPast(month: Int, year: Int): Boolean {
    val currentMoment: Instant = Clock.System.now()
    val currentDate: LocalDateTime = currentMoment.toLocalDateTime(TimeZone.UTC)
    return (month <= currentDate.monthNumber && year == currentDate.year % 100) ||
            year < currentDate.year % 100
}

/*
    String date format MMyy
 */
internal fun isDateInPast(date: String): Boolean {
    return isDateInPast(
        month = date.take(2).toInt(),
        year = date.takeLast(2).toInt()
    )
}

internal fun expiryDateValid(month: Int, year: Int): Boolean {
    if (isDateInPast(month, year)) return false
    val currentDate: LocalDateTime = Clock.System.now().toLocalDateTime(TimeZone.UTC)
    return if (month !in 1..12) false
    else if (year == currentDate.year % 100) month >= currentDate.monthNumber
    else year < (currentDate.year % 100 + 10)
}

/**
 * Validates an expiryDate String with format
 * MM*YY, where * can be anything between
 */
internal fun expiryDateValid(expiryDateString: String): Boolean {
    return try {
        val valid = expiryDateValid(
            month = expiryDateString.take(2).toInt(),
            year = expiryDateString.takeLast(2).toInt()
        )
        valid
    } catch (e: Exception) {
        false
    }
}

internal fun CharSequence.isDigitsOnly(): Boolean {
    return Regex("[0-9]+").matches(this)
}