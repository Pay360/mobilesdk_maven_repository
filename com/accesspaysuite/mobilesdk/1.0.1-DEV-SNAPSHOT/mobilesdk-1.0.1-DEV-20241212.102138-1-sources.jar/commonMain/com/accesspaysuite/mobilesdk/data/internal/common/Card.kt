package com.accesspaysuite.mobilesdk.data.internal.common

import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.utils.noWhitespace
import kotlinx.serialization.Serializable

/**
 * Represents an Payment Card.
 */
@Serializable
internal data class Card(
    private var pan: String? = null,
    private var cv2: String? = null,
    private var expiryDate: String? = null,
    private var cardHolderName: String? = null,
    private var token: String? = null,
    internal var lastFour: String? = null,
) {

    internal var cardType: CardType? = CardType.NONE

    internal val isTokenized: Boolean
        get() = token != null

    fun setPan(pan: String?): Card {
        this.pan = pan.noWhitespace()
        return this
    }

    fun setCv2(cv2: String?): Card {
        this.cv2 = cv2.noWhitespace()
        return this
    }

    fun setExpiryDate(expiryDate: String?): Card {
        this.expiryDate = expiryDate.noWhitespace()
        return this
    }

    fun setCardHolderName(cardHolderName: String?): Card {
        this.cardHolderName = cardHolderName.noWhitespace()
        return this
    }

    fun setToken(token: String?): Card {
        this.token = token.noWhitespace()
        return this
    }

    fun setLastFour(lastFour: String?): Card {
        this.lastFour = lastFour.noWhitespace()
        return this
    }

    /**
     * Perform a weak card details validation to know
     * where or not to go ahead with the payment request
     */
    fun isWeakValid(tokenPayment: Boolean): Boolean = if (tokenPayment) {
        !token.isNullOrBlank()
    } else pan!!.isNotBlank()

}
