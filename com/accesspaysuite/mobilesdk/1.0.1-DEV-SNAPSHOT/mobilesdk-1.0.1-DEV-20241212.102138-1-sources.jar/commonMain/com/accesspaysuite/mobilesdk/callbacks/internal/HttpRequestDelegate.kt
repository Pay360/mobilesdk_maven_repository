package com.accesspaysuite.mobilesdk.callbacks.internal

import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType

/**
 * Http request delegate
 *
 * @param T
 * @constructor Create empty Http request delegate
 */
internal interface HttpRequestDelegate<T> {

    /**
     * Response received with success
     *
     * @param requestType
     * @param response
     */
    fun responseReceivedWithSuccess(requestType: APIRequestType, response: T)

    /**
     * Response received with failure
     *
     * @param requestType
     * @param reason
     */
    fun responseReceivedWithFailure(requestType: APIRequestType, reason: String?)

}
