package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponsePaymentMethod(
    val card: PaymentResponseCard? = null,
    val googlepay: PaymentResponseGooglePay? = null,
    val applepay: PaymentResponseApplePay? = null,
)