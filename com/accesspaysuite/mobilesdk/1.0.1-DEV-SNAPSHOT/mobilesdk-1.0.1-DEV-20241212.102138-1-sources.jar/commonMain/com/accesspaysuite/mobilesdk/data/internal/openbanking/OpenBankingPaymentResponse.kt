package com.accesspaysuite.mobilesdk.data.internal.openbanking

import com.accesspaysuite.mobilesdk.data.internal.common.PaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponseOutcome
import kotlinx.serialization.Serializable

@Serializable
internal data class OpenBankingPaymentResponse(
    val clientRedirect: OpenBankingClientRedirect? = null,
    val processing: OpenBankingProcessing? = null,
    val paymentMethod: List<PaymentMethod>? = null,
    val transaction: OpenBankingTransaction? = null,
    val outcome: PaymentResponseOutcome // REASON CODE : U100 for suspend
)

@Serializable
internal data class OpenBankingProcessing(
    val authResponse: OpenBankingAuthResponse? = null,
    val route: String? = null
)

@Serializable
internal data class OpenBankingAuthResponse(
    val acquirerName: String? = null,
    val gatewayReference: String? = null,
)

@Serializable
internal data class OpenBankingTransaction(
    val transactionId: String,
    val status: String, // == PENDING
    val amount: String,
    val type: String, // == PAYMENT
    val stage: String, // == AUTHORIZATION
    // TODO: Add missing fields once the API is updated
)
