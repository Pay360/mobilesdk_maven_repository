package com.accesspaysuite.mobilesdk.data.internal.management

import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.cardmanager.CustomerMethod
import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Serializable
@Parcelize
internal data class CardManagerState(
    val isCustomerValid: Boolean = false,
    val cards: List<CustomerMethod> = emptyList(),
    val isLoading: Boolean = true
) : Parcelable


@Serializable
@Parcelize
internal data class CardManagementCredentials(
    val username: String,
    val password: String,
    val installationId: String,
    val environment: Environment
) : Parcelable