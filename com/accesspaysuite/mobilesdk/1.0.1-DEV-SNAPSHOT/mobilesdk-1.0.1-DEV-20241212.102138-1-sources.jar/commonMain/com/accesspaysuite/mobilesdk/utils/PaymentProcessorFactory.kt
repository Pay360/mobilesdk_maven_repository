package com.accesspaysuite.mobilesdk.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.PaymentProcessor
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods

internal object PaymentProcessorFactory {

    private val _paymentProcessor: MutableState<PaymentProcessor?> = mutableStateOf(null)
    val currentProcessor: PaymentProcessor? by _paymentProcessor

    fun create(processor: PaymentProcessor?) {
        this._paymentProcessor.value = processor
    }

    fun dispose() {
        this._paymentProcessor.value = null
    }
}

@Composable
internal fun PaymentProcessorFactory.hasPaymentMethod(paymentMethods: AcceptPaymentMethods): State<Boolean> {
    return remember(currentProcessor) {
        derivedStateOf {
            currentProcessor?.hasPaymentMethod(paymentMethods) ?: false
        }
    }
}