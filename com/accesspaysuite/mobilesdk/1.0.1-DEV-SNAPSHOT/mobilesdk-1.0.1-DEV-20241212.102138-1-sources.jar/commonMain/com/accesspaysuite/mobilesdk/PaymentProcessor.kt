package com.accesspaysuite.mobilesdk

import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.CardError

/**
 * # Payment Processor (Common)
 * Check the platform specific implementation for more details.
 */
expect class PaymentProcessor : PaymentProcessorInternal {

    companion object {
        internal fun newInstance(context: Any? = null, paymentConfig: PaymentConfig): PaymentProcessor

        internal fun newInstance(
            context: Any? = null,
            paymentConfig: PaymentConfig,
            onPaymentSuccess: PaymentProcessor.() -> Unit,
            onPaymentFailed: PaymentProcessor.(String) -> Unit,
            onPaymentMethodCanceled: PaymentProcessor.() -> Unit,
            onCardSubmittedSuccessfully: PaymentProcessor.() -> Unit,
            onCardSubmittedWithErrors: PaymentProcessor.(Array<CardError>) -> Unit,
            onInitiate: PaymentProcessor.(Status) -> Unit
        ): PaymentProcessor
    }
}