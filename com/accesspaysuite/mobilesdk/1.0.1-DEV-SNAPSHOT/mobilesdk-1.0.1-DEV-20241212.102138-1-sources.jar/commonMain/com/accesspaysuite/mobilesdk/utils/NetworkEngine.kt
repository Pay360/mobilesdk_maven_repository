package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.GlobalConfig
import io.ktor.client.HttpClient

internal val ENABLE_SSL_PINNING = GlobalConfig.ENABLE_SSL_PINNING;
internal const val PINNED_HOST_NAME = "domain.com"
internal val pins = arrayOf(
    "sha256/++AAA=======================================",
    "sha256/++BBB=======================================",
    "sha256/CCCCC======================================="
)
/**
 * @suppress
 */
internal expect object NetworkEngine {

    val client: HttpClient
}