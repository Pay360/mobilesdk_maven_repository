package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight

/**
 * Save card state
 *
 * @property fontSize
 * @property fontWeight
 * @property defaultState
 * @constructor Create empty Save card state
 */
@Stable
data class SaveCardState(
    val fontSize: Int = 16,
    val fontWeight: ComponentFontWeight = ComponentFontWeight.BOLD,
    val defaultState: Boolean = false,
) {
    constructor(): this(
        fontSize = 16,
        fontWeight = ComponentFontWeight.BOLD,
        defaultState = false,
    )
}

/**
 * Remember save card state
 *
 * @param key
 * @param fontSize
 * @param fontWeight
 * @param defaultState
 */
@ExperimentalMobileUI
@Composable
fun rememberSaveCardState(
    key: Any = Unit,
    fontSize: Int = 16,
    fontWeight: ComponentFontWeight = ComponentFontWeight.BOLD,
    defaultState: Boolean = false,
) = remember(key) {
    SaveCardState(
        fontSize, fontWeight, defaultState
    )
}

/**
 * Remember save card state
 *
 * @param keys
 * @param fontSize
 * @param fontWeight
 * @param defaultState
 */
@ExperimentalMobileUI
@Composable
fun rememberSaveCardState(
    vararg keys: Any = arrayOf(Unit),
    fontSize: Int = 16,
    fontWeight: ComponentFontWeight = ComponentFontWeight.BOLD,
    defaultState: Boolean = false
) = remember(keys) {
    SaveCardState(
        fontSize, fontWeight, defaultState
    )
}
