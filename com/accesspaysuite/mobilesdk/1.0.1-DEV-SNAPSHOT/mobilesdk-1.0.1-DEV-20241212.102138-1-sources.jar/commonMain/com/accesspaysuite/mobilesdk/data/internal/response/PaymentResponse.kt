package com.accesspaysuite.mobilesdk.data.internal.response

import com.accesspaysuite.mobilesdk.data.common.CustomerDetails
import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponse(
    val customFields: PaymentResponseCustomFields? = null,
    val outcome: PaymentResponseOutcome,
    val paymentMethod: PaymentResponsePaymentMethod? = null,
    val threeDSRedirect: PaymentResponseThreeDSRedirect? = null,
    val threeDSecure: PaymentResponseThreeDSecure? = null,
    val trace: String? = null,
    val transaction: PaymentResponseTransaction? = null,
    val customer: CustomerDetails? = null,
)