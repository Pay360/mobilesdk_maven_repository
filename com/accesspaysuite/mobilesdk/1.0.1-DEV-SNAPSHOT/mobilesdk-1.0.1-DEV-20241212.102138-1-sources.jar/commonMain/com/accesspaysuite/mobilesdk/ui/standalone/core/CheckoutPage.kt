package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_gpay_chip
import org.jetbrains.compose.resources.painterResource

@Composable
internal fun CheckoutPage(
    cardType: CardType = CardType.NONE,
    lastFour: String = "",
    paymentType: PaymentType = PaymentType.GuestPayment,
    onButtonClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .border(
                width = 0.5.dp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                shape = RoundedCornerShape(16.dp)
            )
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onButtonClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        val iconId = cardType.getCardIcon()
        when (paymentType) {
            PaymentType.GuestPayment -> {
                Image(
                    painter = painterResource(iconId),
                    contentDescription = null,
                    modifier = Modifier
                        .height(32.dp)
                        .width(48.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "**** $lastFour",
                    modifier = Modifier.weight(1f),
                    style = TextStyle(
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp
                    )
                )
            }

            PaymentType.TokenPayment -> {
                Image(
                    painter = painterResource(iconId),
                    contentDescription = null,
                    modifier = Modifier
                        .height(32.dp)
                        .width(48.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "**** $lastFour",
                    modifier = Modifier.weight(1f),
                    style = TextStyle(
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp
                    )
                )
            }

            PaymentType.GooglePayPayment -> {
                Image(
                    painter = painterResource(Res.drawable.ic_gpay_chip),
                    contentDescription = null,
                    modifier = Modifier
                        .height(32.dp)
                        .width(48.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Google Pay",
                    modifier = Modifier.weight(1f),
                    style = TextStyle(
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Medium,
                        fontSize = 16.sp
                    )
                )
            }

            else -> {}
        }

        Icon(
            imageVector = Icons.Outlined.Close,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.onBackground
        )
    }
}
