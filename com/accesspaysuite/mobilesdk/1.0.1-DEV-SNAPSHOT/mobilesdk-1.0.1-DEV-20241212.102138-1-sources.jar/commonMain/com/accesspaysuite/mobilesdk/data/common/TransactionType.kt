package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Transaction type
 *
 * Used to define the type of transaction
 */
@Parcelize
@Serializable
enum class TransactionType : Parcelable {
    /**
     * # Payment Transaction
     */
    PAYMENT,

    /**
     * # Authorization Transaction (Pre-authorization)
     */
    AUTHORIZATION
}