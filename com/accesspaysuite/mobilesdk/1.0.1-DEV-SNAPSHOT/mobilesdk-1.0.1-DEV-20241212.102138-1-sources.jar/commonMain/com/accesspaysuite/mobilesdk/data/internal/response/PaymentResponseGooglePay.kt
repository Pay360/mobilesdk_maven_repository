package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseGooglePay(
    val cardScheme: String? = null,
    val displayName: String? = null,
)