package com.accesspaysuite.mobilesdk.data.internal.openbanking

import kotlinx.serialization.Serializable

@Serializable
internal data class OpenBankingClientRedirect(
    val type: String,
    val url: String
)
