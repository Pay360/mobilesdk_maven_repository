package com.accesspaysuite.mobilesdk.ui.bank

/*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.calculateEndPadding
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.ImageLoader
import coil3.annotation.ExperimentalCoilApi
import coil3.compose.AsyncImage
import coil3.compose.setSingletonImageLoaderFactory
import coil3.svg.SvgDecoder
import com.accesspaysuite.mobilesdk.payment.data.openbanking.response.BankData
import com.accesspaysuite.mobilesdk.modules.OpenBankingController
import com.accesspaysuite.mobilesdk.ui.components.BetterTextField
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme

@OptIn(ExperimentalMaterial3Api::class, ExperimentalCoilApi::class)
@Composable
internal fun BankSelectorScreen(
    bankProcessor: OpenBankingController?,
    onBankSelected: (BankData) -> Unit,
    onBackPressed: () -> Unit
) {
    PaymentUITheme {
        setSingletonImageLoaderFactory {
            ImageLoader.Builder(it)
                .components {
                    add(SvgDecoder.Factory())
                }
                .build()
        }
        val gridState = rememberLazyGridState()
        var bankQuery by rememberSaveable { mutableStateOf("") }
        var bankList by rememberSaveable { mutableStateOf(emptyList<BankData>()) }
        LaunchedEffect(bankProcessor, bankQuery) {
            bankProcessor?.getBanks()?.let { bankList = it }
        }
        LaunchedEffect(bankQuery) {
            if (bankQuery.isEmpty()) {
                bankList = bankProcessor?.getBanks() ?: emptyList()
            }
            bankList = bankList.filter { it.name.contains(bankQuery, ignoreCase = true) }
        }
        Scaffold(
            topBar = {
                Column {
                    CenterAlignedTopAppBar(
                        title = {
                            Text(
                                text = "Select Your Bank",
                                style = MaterialTheme.typography.titleLarge
                            )
                        },
                        navigationIcon = {
                            IconButton(
                                onClick = onBackPressed
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back"
                                )
                            }
                        }
                    )
                    BetterTextField(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                            .padding(horizontal = 16.dp),
                        isOutlined = true,
                        value = bankQuery,
                        shape = RoundedCornerShape(4.dp),
                        onValueChange = { bankQuery = it },
                        placeholder = {
                            Text(
                                modifier = Modifier.fillMaxWidth(),
                                text = "Find your bank"
                            )
                        },
                        trailingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search"
                            )
                        }
                    )
                }
            }
        ) { padding ->
            val layoutDirection = LocalLayoutDirection.current
            LazyVerticalGrid(
                state = gridState,
                contentPadding = PaddingValues(
                    start = padding.calculateStartPadding(layoutDirection) + 8.dp,
                    end = padding.calculateEndPadding(layoutDirection) + 8.dp,
                    top = padding.calculateTopPadding() + 8.dp,
                    bottom = padding.calculateBottomPadding()
                ),
                columns = GridCells.Fixed(3)
            ) {
                if (bankList.isEmpty()) {
                    item(
                        span = { GridItemSpan(maxLineSpan) }
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(
                                8.dp,
                                Alignment.CenterVertically
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Warning",
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "No banks found",
                                style = MaterialTheme.typography.bodyLarge,
                            )
                        }
                    }
                }
                items(
                    items = bankList,
                    key = { it.id }
                ) {
                    Column(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .padding(8.dp)
                            .shadow(
                                elevation = 1.dp,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .background(
                                color = MaterialTheme.colorScheme.background,
                                shape = RoundedCornerShape(4.dp)
                            )
                            .clickable { onBankSelected(it) }
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.12f),
                                shape = RoundedCornerShape(4.dp)
                            )
                            .padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterVertically)
                    ) {
                        AsyncImage(
                            model = it.logo,
                            contentDescription = it.name,
                            onError = {
                                it.result.throwable.printStackTrace()
                            },
                            placeholder = rememberVectorPainter(image = Icons.Default.Home),
                            modifier = Modifier
                                .weight(1f)
                                .aspectRatio(1f)
                        )

                        Text(
                            text = it.name,
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2,
                            minLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}*/