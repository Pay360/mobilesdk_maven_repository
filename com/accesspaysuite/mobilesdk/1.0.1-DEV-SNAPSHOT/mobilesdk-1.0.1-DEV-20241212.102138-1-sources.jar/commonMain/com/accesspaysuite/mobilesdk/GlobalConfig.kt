package com.accesspaysuite.mobilesdk

import kotlin.Boolean
import kotlin.String

internal object GlobalConfig {
  public val ENABLE_SSL_PINNING: Boolean = false

  public val SDK_VERSION: String = "1.0.1-DEV-SNAPSHOT"

  public val LOGGING: Boolean = true
}
