package com.accesspaysuite.mobilesdk.utils

import io.github.alexzhirkevich.cupertino.adaptive.Theme

internal expect fun determineTheme(): Theme