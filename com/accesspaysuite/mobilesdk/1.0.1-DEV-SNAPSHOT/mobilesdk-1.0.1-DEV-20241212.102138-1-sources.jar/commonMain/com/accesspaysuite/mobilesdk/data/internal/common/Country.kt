package com.accesspaysuite.mobilesdk.data.internal.common

import kotlinx.serialization.Serializable

/**
 * Country
 *
 * @property name
 * @property alpha3
 * @constructor Create empty Country
 */
@Serializable
internal data class Country(
    val name: String,
    val alpha3: String
) {
    companion object {
        val Default = Country("United Kingdom", "GBR")
    }
}
