package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.data.internal.management.CardManagementCredentials
import com.accesspaysuite.mobilesdk.data.internal.management.CardManagerState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

internal class CardManager(
    private val credentials: CardManagementCredentials,
    private val customerReference: String,
) {

    private val repository = CardManagerRepositoryImpl()

    private val _state = MutableStateFlow(CardManagerState())
    val state = _state.asStateFlow()

    suspend fun update() {
        checkCustomer()
        getCards()
    }

    private suspend fun checkCustomer() = withContext(Dispatchers.IO) {
        _state.value = state.value.copy(
            isCustomerValid = repository.getCustomerId(
                username = credentials.username,
                password = credentials.password,
                installationId = credentials.installationId,
                environment = credentials.environment,
                customerReference = customerReference
            ) != null,
            isLoading = true
        )
    }

    private suspend fun getCards() = withContext(Dispatchers.IO) {
        _state.value = state.value.copy(
            cards = repository.getCustomerMethods(
                username = credentials.username,
                password = credentials.password,
                installationId = credentials.installationId,
                environment = credentials.environment,
                customerReference = customerReference
            ),
            isLoading = false
        )
    }

    suspend fun deleteCard(cardToken: String) = withContext(Dispatchers.IO) {
        repository.deleteCard(
            username = credentials.username,
            password = credentials.password,
            installationId = credentials.installationId,
            environment = credentials.environment,
            customerReference = customerReference,
            cardToken = cardToken
        )
        getCards()
    }

    suspend fun makeDefault(cardToken: String) = withContext(Dispatchers.IO) {
        repository.makePrimaryCard(
            username = credentials.username,
            password = credentials.password,
            installationId = credentials.installationId,
            environment = credentials.environment,
            customerReference = customerReference,
            cardToken = cardToken
        )
        getCards()
    }

}