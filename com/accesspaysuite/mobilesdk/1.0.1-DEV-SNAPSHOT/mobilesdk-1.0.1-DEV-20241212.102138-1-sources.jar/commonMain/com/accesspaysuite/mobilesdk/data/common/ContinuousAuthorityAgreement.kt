package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Continuous authority agreement
 *
 * > The continuous authority agreement established with the cardholder.
 * > Required if you want to process a transaction initiating a recurring or instalment series using 3DSv2
 *
 * @property minFrequency Minimum number of days expected between payments in a recurring or instalment sequence. Must be >= 1.
 * @property expiry Date (YYYY-MM-DD) at which recurring/instalment agreement expires, or at which it will need to be re-authenticated in order to continue. Must be in the future.
 * @property numberOfInstalments Total number of payments in an instalment sequence – including this one, if starting with a payment. Required only for instalments; must be >= 2.
 */
@Parcelize
@Serializable
data class ContinuousAuthorityAgreement(
    val minFrequency: String? = null,
    val expiry: String? = null,
    val numberOfInstalments: String? = null
) : Parcelable