package com.accesspaysuite.mobilesdk.ui.standalone

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.internal.standalone.PaymentStatus
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.paid_amount
import com.accesspaysuite.mobilesdk.sdk.generated.resources.payment_failed
import com.accesspaysuite.mobilesdk.sdk.generated.resources.payment_successfully
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun PaymentStatusPage(
    status: PaymentStatus,
    reason: String?,
    currencyCode: String,
    amount: Double
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 64.dp, bottom = 32.dp)
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val icon = remember(status) {
            if (status == PaymentStatus.Success) Icons.Outlined.CheckCircle else Icons.Outlined.Warning
        }
        val errorColor = MaterialTheme.colorScheme.error
        val color = remember(status) {
            if (status == PaymentStatus.Success) Color(0xff469c24) else errorColor
        }
        val paymentSuccessString = stringResource(Res.string.payment_successfully)
        val paymentFailedString = stringResource(Res.string.payment_failed)
        val text = remember(status) {
            if (status == PaymentStatus.Success) paymentSuccessString
            else paymentFailedString
        }
        Icon(
            modifier = Modifier
                .size(64.dp),
            imageVector = icon,
            contentDescription = null,
            tint = color
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = text,
            style = TextStyle(
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Medium,
                fontSize = 24.sp
            )
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = reason ?: stringResource(Res.string.paid_amount, currencyCode, amount),
            style = TextStyle(
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            ),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
    }
}