package com.accesspaysuite.mobilesdk.ui.standalone

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation

@Composable
internal fun PaymentBottomBar(
    showBottomBar: Boolean,
    canClick: Boolean,
    title: String,
    onClick: () -> Unit,
    paymentType: PaymentType
) {
    AnimatedVisibility(
        visible = showBottomBar,
        enter = enterAnimation,
        exit = exitAnimation
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.background)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 4.dp)
        ) {
            AnimatedVisibility(
                visible = paymentType.isCardPayment(),
                enter = enterAnimation,
                exit = exitAnimation
            ) {
                val alphaValue by animateFloatAsState(
                    targetValue = if (canClick) 1f else 0.4f,
                    label = "alpha"
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .alpha(alphaValue)
                        .background(
                            color = if (isSystemInDarkTheme()) Color.White else Color.Black,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clip(RoundedCornerShape(16.dp))
                        .clickable(enabled = canClick, onClick = onClick)
                ) {
                    Text(
                        modifier = Modifier.align(Alignment.Center),
                        text = title,
                        fontWeight = FontWeight.Medium,
                        fontSize = 18.sp,
                        color = if (isSystemInDarkTheme()) Color.Black else Color.White
                    )
                }
            }
        }
    }
}

internal fun PaymentType.isCardPayment(): Boolean {
    return this != PaymentType.GooglePayPayment || this != PaymentType.ApplePayPayment
}