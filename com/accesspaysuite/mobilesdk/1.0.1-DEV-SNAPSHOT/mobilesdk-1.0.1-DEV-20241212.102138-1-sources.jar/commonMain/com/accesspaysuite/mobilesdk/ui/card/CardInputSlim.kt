package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.CardInputField
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.CVV
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.EXPIRY
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.NAME
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.PAN
import com.accesspaysuite.mobilesdk.ui.utils.CardSubmitter
import com.accesspaysuite.mobilesdk.ui.utils.CardUtils
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import com.accesspaysuite.mobilesdk.utils.hasPaymentMethod
import io.github.aakira.napier.Napier
import io.github.alexzhirkevich.cupertino.LocalContainerColor
import org.jetbrains.compose.resources.painterResource

/**
 * # Card Input Slim Component
 * This component is used to input card details in a slim card input form.
 * The card input form consists of the following fields:
 * - Card Number
 * - Expiry Date
 * - CVV
 * - Card Holder Name
 *
 * @param state The style state of the card input.
 * @param modifier The modifier to apply to this layout node.
 */
@ExperimentalMobileUI
@Composable
fun CardInputSlim(
    state: CardInputSlimStyleState,
    modifier: Modifier = Modifier
) = CardInputSlim(
    textSize = state.textSize.toDouble().sp,
    textFontWeight = state.textFontWeight,
    showCardHolderName = state.showCardHolderName,
    cardHolderName = state.cardHolderName,
    modifier = modifier
)

/**
 * # Card Input Slim Component
 * This component is used to input card details in a slim card input form.
 * The card input form consists of the following fields:
 * - Card Number
 * - Expiry Date
 * - CVV
 * - Card Holder Name
 *
 * @param textSize The size of the text in the card input. Default value is 16.sp.
 * @param textFontWeight The font weight of the text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param showCardHolderName A boolean indicating whether the cardholder's name should be shown. Default value is true.
 * @param cardHolderName The initial name of the card holder. Default value is an empty string.
 * @param modifier The modifier to apply to this layout node.
 * @receiver
 */
@OptIn(ExperimentalLayoutApi::class)
@ExperimentalMobileUI
@Composable
fun CardInputSlim(
    textSize: TextUnit = 16.sp,
    textFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = true,
    cardHolderName: String = "",
    modifier: Modifier = Modifier
) {
    var cardType by remember { mutableStateOf(CardType.NONE) }
    var panInput by rememberSaveable { mutableStateOf("") }
    var panInputError by rememberSaveable { mutableStateOf("") }

    var expiryDateInput by rememberSaveable { mutableStateOf("") }
    var expiryDateInputError by rememberSaveable { mutableStateOf("") }

    var cvvInput by rememberSaveable { mutableStateOf("") }
    var cvvInputError by rememberSaveable { mutableStateOf("") }

    var cardHolderNameInput by rememberSaveable(showCardHolderName) {
        mutableStateOf(if (showCardHolderName) "" else cardHolderName)
    }
    var cardHolderNameInputError by rememberSaveable { mutableStateOf("") }

    val cardSubmitted = rememberSaveable { mutableStateOf(false) }

    val methodAvailable by PaymentProcessorFactory.hasPaymentMethod(AcceptPaymentMethods.CARD)

    LaunchedEffect(showCardHolderName, cardHolderName) {
        if (showCardHolderName) {
            if (cardHolderNameInput.isNotEmpty()) {
                Napier.w {
                    "Pre-filled card holder name will be ignored because showCardHolderName is true"
                }
            }
        } else {
            require(cardHolderName.isNotEmpty()) {
                "Card holder name shouldn't be empty when showCardHolderName is false"
            }
        }
    }

    AnimatedVisibility(
        modifier = Modifier.background(Color.Transparent),
        visible = methodAvailable,
        enter = enterAnimation,
        exit = exitAnimation
    ) {

        PaymentUITheme {
            Surface(
                color = Color.Transparent
            ) {
                CardSubmitter(
                    cardType = cardType,
                    panInput = panInput,
                    expiryDateInput = expiryDateInput,
                    cvvInput = cvvInput,
                    cardHolderName = cardHolderNameInput,
                    cardHolderNameError = cardHolderNameInputError,
                    cardSubmitted = cardSubmitted,
                    panInputError = panInputError,
                    expiryDateInputError = expiryDateInputError,
                    cvvInputError = cvvInputError
                )

                val backgroundColor = LocalContainerColor.current
                val contentColor = LocalContentColor.current

                val textStyle = remember(textSize, textFontWeight, contentColor) {
                    TextStyle.Default.copy(
                        fontWeight = textFontWeight.value,
                        fontSize = textSize,
                        textAlign = TextAlign.Start,
                        color = contentColor
                    )
                }
                val processor = PaymentProcessorFactory.currentProcessor
                LaunchedEffect(panInput) {
                    if (panInput.length < 2) {
                        cardType = CardType.NONE
                        return@LaunchedEffect
                    }
                    if (processor == null) {
                        cardType = CardType.NONE
                        return@LaunchedEffect
                    }
                    cardType = CardUtils.guessCardNumberType(processor.environment, panInput)
                }

                LaunchedEffect(cardType) {
                    val maxLength = if (cardType == CardType.AMEX) 4 else 3
                    cvvInput = cvvInput.take(maxLength)
                }

                FlowRow(
                    modifier = modifier
                        .background(color = backgroundColor)
                        .padding(vertical = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Image(
                            painter = painterResource(cardType.getCardIcon()),
                            contentDescription = null,
                            modifier = Modifier.size(width = 40.dp, height = 24.dp),
                            contentScale = ContentScale.Fit
                        )
                        CardInputField(
                            inputType = PAN,
                            cardType = cardType,
                            text = panInput,
                            onValueChange = { panInput = it },
                            textStyle = textStyle,
                            onError = { panInputError = it },
                            modifier = Modifier.defaultMinSize(minWidth = 164.dp)
                        )
                    }
                    CardInputField(
                        modifier = Modifier.defaultMinSize(minWidth = 64.dp).weight(1f),
                        inputType = EXPIRY,
                        cardType = cardType,
                        text = expiryDateInput,
                        onValueChange = { expiryDateInput = it },
                        textStyle = textStyle,
                        onError = { expiryDateInputError = it }
                    )
                    CardInputField(
                        modifier = Modifier.weight(1f),
                        inputType = CVV,
                        cardType = cardType,
                        text = cvvInput,
                        onValueChange = { cvvInput = it },
                        textStyle = textStyle,
                        onError = { cvvInputError = it },
                        imeAction = if (showCardHolderName) ImeAction.Next else ImeAction.Done
                    )
                    AnimatedVisibility(
                        visible = showCardHolderName,
                        modifier = Modifier.fillMaxWidth().weight(2f)
                    ) {
                        CardInputField(
                            modifier = Modifier.defaultMinSize(minWidth = 160.dp).fillMaxWidth(),
                            inputType = NAME,
                            cardType = cardType,
                            text = cardHolderNameInput,
                            imeAction = ImeAction.Done,
                            onValueChange = { cardHolderNameInput = it },
                            textStyle = textStyle,
                            onError = { cardHolderNameInputError = it }
                        )
                    }
                }
            }
        }
    }
}
