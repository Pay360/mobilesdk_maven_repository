package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Payment Environment
 *
 * The [Environment] enum class is responsible for setting the environment of the transaction.
 *
 */
@Parcelize
@Serializable
enum class Environment : Parcelable {
    /**
     * ## Live Environment
     * All transactions will be processed in the production environment.
     */
    LIVE,

    /**
     * ## Test Environment
     * All transactions will be processed in the test environment.
     */
    TEST;

    override fun toString(): String {
        return name.uppercase()
    }

}