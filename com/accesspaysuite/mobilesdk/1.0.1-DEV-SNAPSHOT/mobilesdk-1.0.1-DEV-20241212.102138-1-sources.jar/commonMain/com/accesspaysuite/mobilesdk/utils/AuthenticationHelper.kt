package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.data.common.Environment
import io.ktor.client.call.body
import io.ktor.client.request.basicAuth
import io.ktor.client.request.headers
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.HttpStatusCode
import io.ktor.http.contentType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlin.coroutines.cancellation.CancellationException

/**
 * Authentication Helper
 *
 * This class is used to retrieve Authorization Credentials (Client Token) for
 * Advanced Payments Platform (AP)
 *
 * This is just the built-in method to ease the process of getting the client token
 * from the server.
 *
 * This method is not required to be used, you can implement your own method to get the
 * client token from the server.
 *
 *  ### API for generating the auth token:
 *  Test environment: `https://api.mite.pay360.com`
 *
 *  Production environment: `https://api.pay360.com`
 *
 *  #### Registered Customer
 *  The customerReference will be the unique reference of the customer
 *  where is registered with the merchant. Using the reference you will be able
 *  to manage the customer's payment methods and other details
 *  ```
 *  Headers: Authorization: Basic base64(username:password)
 *  POST acceptor/rest/authorisation/{{instId}}/authoriseClient
 *  {
 *     "scopes": [
 *         "MOBILE_CUSTOMER_PAYMENT"
 *     ],
 *     "customerReference": "CUST_000001"
 *  }
 *  ```
 *  #### Guest Customer
 *  The customerReference will be null for guest customers.
 *  The payment will be processed as a guest user.
 *  ```
 *  Headers: Authorization: Basic base64(username:password)
 *  POST acceptor/rest/authorisation/{{instId}}/authoriseClient
 *  {
 *     "scopes": [
 *         "MOBILE_GUEST_PAYMENT"
 *     ]
 *  }
 *  ```
 */
object AuthenticationHelper {

    @Serializable
    private data class AuthRequest(
        val customerReference: String? = null,
        val scopes: List<String>
    )

    @Serializable
    private data class AuthResponse(
        val clientToken: String,
        val status: String,
        val message: String,
        val expires: String
    )

    private class AuthorizationException(message: String) : Exception(message)


    /**
     * Async Helper method to retrieve Authorization Credentials (Client Token) for
     * Advanced Payments Platform (AP)
     */
    @Throws(AuthorizationException::class, CancellationException::class)
    suspend fun requestAuthToken(
        environment: Environment,
        instId: String,
        userName: String,
        password: String,
        customerReference: String?,
        guestPayment: Boolean
    ): String = withContext(Dispatchers.IO) {
        val client = NetworkEngine.client
        runCatching {
            val response = client.request(Constants.AP.authURL(environment, instId)) {
                method = HttpMethod.Post
                headers {
                    basicAuth(userName, password)
                }

                contentType(ContentType.Application.Json)
                setBody(
                    body = AuthRequest(
                        customerReference = customerReference,
                        scopes = listOf(
                            if (guestPayment) Constants.GUEST_AUTHORIZATION
                            else Constants.CUSTOMER_AUTHORIZATION
                        )
                    )
                )
            }
            return@runCatching if (response.status == HttpStatusCode.OK) {
                response.body<AuthResponse>().clientToken
            } else {
                throw AuthorizationException("Server error: ${response.status.value}")
            }
        }.getOrElse {
            print(it.message)
            "NULL"
        }
    }

    /**
     * Synchronous Helper method to retrieve Authorization Credentials (Client Token) for
     * Advanced Payments Platform (AP)
     *
     * ## !! This method is blocking the main thread !!
     */
    @Throws(AuthorizationException::class, CancellationException::class)
    fun getAuthToken(
        environment: Environment,
        instId: String,
        userName: String,
        password: String,
        customerReference: String?,
        guestPayment: Boolean
    ): String = runBlocking {
        requestAuthToken(
            environment,
            instId,
            userName,
            password,
            customerReference,
            guestPayment
        )
    }

}