package com.accesspaysuite.mobilesdk.data.internal.common

/**
 * Request Types that can be used
 */
internal enum class APIRequestType {
    APIRequestGuestPayment,
    APIRequestVerify,
    APIRequestTokenPayment,
    APIRequestGooglePayPayment,
    APIRequestApplePayPayment,
    APIRequestOpenBanking,
}
