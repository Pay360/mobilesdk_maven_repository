package com.accesspaysuite.mobilesdk

import androidx.compose.runtime.Composable
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.CardError

/**
 * Payment Processor
 *
 * @param paymentConfig
 * @return [PaymentProcessor]
 */
@Composable
expect fun rememberPaymentProcessor(
    paymentConfig: PaymentConfig
): PaymentProcessor

/**
 * Payment Processor
 *
 * @param paymentConfig
 * @param onPaymentSuccess
 * @param onPaymentFailed
 * @param onPaymentMethodCanceled
 * @param onCardSubmittedSuccessfully
 * @param onCardSubmittedWithErrors
 * @param onInitiate
 * @return [PaymentProcessor]
 */
@Composable
expect fun rememberPaymentProcessor(
    paymentConfig: PaymentConfig,
    onPaymentSuccess: PaymentProcessor.() -> Unit,
    onPaymentFailed: PaymentProcessor.(String) -> Unit,
    onPaymentMethodCanceled: PaymentProcessor.() -> Unit,
    onCardSubmittedSuccessfully: PaymentProcessor.() -> Unit,
    onCardSubmittedWithErrors: PaymentProcessor.(Array<CardError>) -> Unit,
    onInitiate: PaymentProcessor.(Status) -> Unit
): PaymentProcessor