package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.internal.ThreeDSResultCallback
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponseThreeDSRedirect

/**
 * Payment Controller for handling 3DS Checks
 */
internal expect class ThreeDSController() {

    /**
     * Run 3DS process
     *
     * @param delegate
     * @param paymentType
     * @param params
     */
    internal fun run3DSProcess(
        delegate: ThreeDSResultCallback,
        paymentType: PaymentType,
        params: PaymentResponseThreeDSRedirect
    )

}