package com.accesspaysuite.mobilesdk.data.internal.common

import kotlinx.serialization.Serializable

@Serializable
internal enum class SaveCardMethods {
    YES, NO, ASK;

    override fun toString(): String {
        return name.uppercase()
    }
}
