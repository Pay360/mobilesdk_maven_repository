package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * # Customer Details
 *
 * @property email Email address for the Customer.
 * @property dateOfBirth Date of birth for the Customer.
 * @property telephone Telephone number for the Customer.
 * @property customerRef Your reference for the Customer. Not required if registered is set to false, mandatory otherwise.
 */
@Parcelize
@Serializable
data class CustomerDetails(
    val email: String? = null,
    @SerialName("dob")
    val dateOfBirth: String? = null,
    val telephone: String? = null,
    @SerialName("merchantRef")
    val customerRef: String? = null
) : Parcelable {

    constructor(): this(null, null, null, null)
}