package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.common.TransactionType
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.utils.PROVIDER_ID_HEADER
import com.accesspaysuite.mobilesdk.utils.URLProvider
import io.ktor.client.call.body
import io.ktor.client.request.HttpRequestBuilder
import io.ktor.client.request.bearerAuth
import io.ktor.client.request.get
import io.ktor.client.request.headers
import kotlinx.coroutines.launch

/**
 * Production implementation of [RequestRepository].
 */
internal class RequestRepositoryProd : RequestRepositoryBase() {

    override fun initiatePayment(
        environment: Environment,
        installationId: String,
        clientToken: String,
        transactionType: TransactionType,
        currencyCode: String,
        countryCode: String?,
        onSuccess: (InitiateResponse) -> Unit,
        onFailure: (Status) -> Unit
    ) {
        scope.launch {
            val request = client.get(
                URLProvider.getInitiatePaymentUrl(
                    environment = environment,
                    installationId = installationId,
                    countryCode = countryCode,
                    currency = currencyCode,
                    type = transactionType
                )
            ) {
                attachHeaders(clientToken)
            }
            try {
                val response = request.body<InitiateResponse>()
                if (request.status.value == 200) {
                    onSuccess(response)
                } else {
                    onFailure(
                        Status.Error(
                            "Failed to initiate payment\n" +
                                    "HTTP Error ${response.outcome.reasonCode}\n" +
                                    "Reason: ${response.outcome.reasonMessage}"
                        )
                    )
                }
            } catch (_: Exception) {
                try {
                    val response = request.body<PaymentResponse>()
                    if (request.status.value == 200 && response.outcome.status == "FAILED") {
                        val message = response.outcome.reasonMessage
                        onFailure(message?.let { Status.Error(it) } ?: Status.Unknown)
                    } else {
                        onFailure(Status.Error("Failed to initiate payment"))
                    }
                } catch (_: Exception) {
                    onFailure(Status.Error("Failed to initiate payment"))
                }
            }
        }
    }

    private fun HttpRequestBuilder.attachHeaders(clientToken: String) {
        headers {
            bearerAuth(token = clientToken)
            append(
                name = PROVIDER_ID_HEADER,
                value = "AP"
            )
        }
    }

}