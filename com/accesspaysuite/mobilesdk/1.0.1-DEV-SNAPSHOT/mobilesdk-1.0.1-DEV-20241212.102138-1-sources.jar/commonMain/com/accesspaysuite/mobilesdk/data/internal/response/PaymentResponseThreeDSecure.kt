package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseThreeDSecure(
    val protocolVersion: String? = null,
    val status: String? = null,
    val cardHolderMessage: String? = null,
)