package com.accesspaysuite.mobilesdk.data.internal.common

import com.accesspaysuite.mobilesdk.data.common.CardType
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class StoredCard(
    @SerialName("cardHolderName")
    val cardHolderName: String,
    @SerialName("expiryDate")
    val expiryDate: String,
    @SerialName("lastFour")
    val lastFour: String,
    @SerialName("scheme")
    val scheme: String,
    @SerialName("token")
    val token: String
) {

    fun toCard(cv2: String): Card {
        return Card(
            cardHolderName = cardHolderName,
            token = token,
            lastFour = lastFour,
            cv2 = cv2
        ).apply {
            cardType = CardType.valueOf(scheme)
        }
    }
}