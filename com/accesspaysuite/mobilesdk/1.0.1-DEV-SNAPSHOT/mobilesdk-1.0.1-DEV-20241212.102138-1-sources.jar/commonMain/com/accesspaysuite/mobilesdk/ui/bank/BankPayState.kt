package com.accesspaysuite.mobilesdk.ui.bank

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.PaymentProcessor
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback

/**
 * BankPayState State.
 *
 * Android View System
 * ```kotlin
 * processor.initiate { nonNullProcessor ->
 *     val state = BankPayState(
 *         countryCode = "GB",
 *         callback = callback,
 *         processor = nonNullProcessor
 *     )
 *     bankPay.init(state)
 * }
 * ```
 * Jetpack Compose
 * ```kotlin
 * val state = rememberBankPayState(
 *     countryCode = "GB",
 *     callback = callback
 * )
 * LaunchedEffect(processor) {
 *     processor.initiate { nonNullProcessor ->
 *         state = state.setProcessor(nonNullProcessor)
 *     }
 * }
 * BankPayButton(state = state)
 * ```
 * Swift
 * ```swift
 * @State private var state: BankPayState = BankPayState(
 *    countryCode: "GB",
 *    callback: callback
 * )
 *
 * ```
 * ```swift
 * processor.initiate(
 *     onInit: { (processor: PaymentProcessor) in
 *         state = state.setProcessor(processor: processor)
 *     }
 * )
 * ```
 * ```swift
 * BankPayButton(state: state)
 * ```
 * @param countryCode The country code (Alpha-2 format) for the bank payment.
 * @param callback The callback for the bank payment.
 * @param processor The processor for the card input. Default value is null.
 */
internal data class BankPayState(
    val countryCode: String,
    val callback: PaymentResultCallback,
    val processor: PaymentProcessor? = null
) {

    constructor(
        countryCode: String,
        callback: PaymentResultCallback
    ) : this(
        countryCode = countryCode,
        callback = callback,
        processor = null
    )

    constructor(): this(
        countryCode = "GB",
        callback = PaymentResultCallback.Empty
    )

    fun setProcessor(processor: PaymentProcessor?) = copy(processor = processor)
}

/**
 * Remember bank pay state
 *
 * @param key
 * @param countryCode
 * @param callback
 * @param processor
 */
@Composable
internal fun rememberBankPayState(
    key: Any = Unit,
    countryCode: String,
    callback: PaymentResultCallback,
    processor: PaymentProcessor
) = remember(key) {
    BankPayState(
        countryCode,
        callback,
        processor
    )
}

/**
 * Remember bank pay state
 *
 * @param keys
 * @param countryCode
 * @param callback
 * @param processor
 */
@Composable
internal fun rememberBankPayState(
    vararg keys: Any = arrayOf(Unit),
    countryCode: String,
    callback: PaymentResultCallback,
    processor: PaymentProcessor
) = remember(keys) {
    BankPayState(
        countryCode,
        callback,
        processor
    )
}