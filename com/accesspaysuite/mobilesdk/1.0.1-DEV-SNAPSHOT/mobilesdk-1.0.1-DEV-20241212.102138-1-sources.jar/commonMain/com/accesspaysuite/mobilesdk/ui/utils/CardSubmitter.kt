package com.accesspaysuite.mobilesdk.ui.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import com.accesspaysuite.mobilesdk.data.common.CardError
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.common.Card
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory

@Composable
internal fun CardSubmitter(
    cardType: CardType,
    panInput: String,
    expiryDateInput: String,
    cvvInput: String,
    cardSubmitted: MutableState<Boolean> = rememberSaveable { mutableStateOf(false) },
    panInputError: String,
    expiryDateInputError: String,
    cvvInputError: String,
    cardHolderName: String = "",
    cardHolderNameError: String = "",
) {
    LaunchedEffect(
        panInput,
        expiryDateInput,
        cvvInput,
        panInputError,
        expiryDateInputError,
        cvvInputError,
        cardHolderName,
        cardHolderNameError
    ) {
        val errors = mutableListOf<CardError>()
        if (panInputError.isNotBlank()) {
            errors.add(CardError.CardNumber(panInputError))
        }
        if (expiryDateInputError.isNotBlank()) {
            errors.add(CardError.ExpiryDate(expiryDateInputError))
        }
        if (cvvInputError.isNotBlank()) {
            errors.add(CardError.ExpiryDate(cvvInputError))
        }
        if (cardHolderNameError.isNotBlank()) {
            errors.add(CardError.Cardholder(cardHolderNameError))
        }

        cardSubmitted.value = (cardType != CardType.NONE) &&
                panInput.length == 16 &&
                expiryDateInput.length == 4 &&
                cvvInput.length >= 3 &&
                cardHolderName.isNotBlank() &&
                errors.isEmpty()
        val processor = PaymentProcessorFactory.currentProcessor
        val environment = processor?.environment

        val newCard = if (cardSubmitted.value) {
            Card(
                pan = panInput,
                expiryDate = expiryDateInput,
                lastFour = panInput.takeLast(4),
                cv2 = cvvInput,
                cardHolderName = cardHolderName
            ).apply {
                this.cardType = if (environment == Environment.TEST) CardUtils.getTestCardType(panInput) else cardType
            }
        } else {
            null
        }
        processor?.updateCard(newCard, errors.toTypedArray())
    }
}

