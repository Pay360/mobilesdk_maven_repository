package com.accesspaysuite.mobilesdk.data.internal.common

import kotlinx.serialization.Serializable

@Serializable
internal data class AuthCredentials(
    val token: String,
    val providerId: String?
)