package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.you_have_to_pay
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun PaymentHeader(
    amount: Double?,
    currencyCode: String?,
    //merchantName: String = stringResource(id = R.string.payment_details)
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        if (amount != null && currencyCode != null) {
            Text(
                text = stringResource(Res.string.you_have_to_pay),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                fontSize = 16.sp
            )
            Row(
                verticalAlignment = Alignment.Bottom
            ) {
                val onBackgroundColor = MaterialTheme.colorScheme.onBackground
                Text(
                    text = buildAnnotatedString {
                        withStyle(
                            style = SpanStyle(
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                color = onBackgroundColor
                            )
                        ) {
                            append(currencyCode)
                        }
                        withStyle(
                            style = SpanStyle(
                                fontSize = 16.sp
                            )
                        ) {
                            append(" ")
                        }
                        withStyle(
                            style = SpanStyle(
                                fontSize = 38.sp,
                                fontWeight = FontWeight.Bold,
                                color = onBackgroundColor
                            )
                        ) {
                            append(amount.toInt().toString())
                        }
                        withStyle(
                            style = SpanStyle(
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = onBackgroundColor.copy(alpha = 0.5f)
                            )
                        ) {
                            append(
                                ".${amount.toString().substringAfterLast(".")}"
                            )
                        }
                    }
                )
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
        /*Text(
            text = merchantName,
            fontFamily = poppinsFontFamily,
            fontWeight = FontWeight.Medium,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = stringResource(R.string.payment_details_summary),
            fontFamily = poppinsFontFamily,
            fontWeight = FontWeight.Light,
            fontSize = 14.sp,
            lineHeight = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
        )*/
    }
}
