package com.accesspaysuite.mobilesdk.ui.utils

import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.Environment
import io.ktor.utils.io.charsets.Charsets
import io.ktor.utils.io.core.toByteArray

internal fun validateCreditCardNumber(str: String): Boolean {
    val ints = IntArray(str.length)
    for (i in str.indices) {
        ints[i] = str.substring(i, i + 1).toInt()
    }
    var i = ints.size - 2
    while (i >= 0) {
        var j = ints[i]
        j *= 2
        if (j > 9) {
            j = j % 10 + 1
        }
        ints[i] = j
        i -= 2
    }
    var sum = 0
    for (anInt in ints) {
        sum += anInt
    }
    return sum % 10 == 0
}

internal class CardUtils {

    companion object {
        fun guessCardNumberType(environment: Environment, str: String): CardType {
            val visaRegex = "^4[0-9]*$".toRegex()
            val masterCardRegex = "^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)[0-9]*$".toRegex()
            val jcbRegex = "^(?:2131|1800|35)[0-9]*$".toRegex()
            val amexRegex = "^3[47][0-9]*$".toRegex()
            //val dinersRegex = "^3(?:0[0-59]{1}|[689])[0-9]*$".toRegex()
            /*val discoverRegex =
                "^(6011|65|64[4-9]|62212[6-9]|6221[3-9]|622[2-8]|6229[01]|62292[0-5])[0-9]*$".toRegex()*/
            val maestroRegex = "^(5[06789]|6)[0-9]*$".toRegex()
            val miteRegex = "^990[0-9]*$".toRegex()

            return if (str.matches(visaRegex)) CardType.VISA
            else if (str.matches(masterCardRegex)) CardType.MASTERCARD
            else if (str.matches(amexRegex)) CardType.AMEX
            else if (str.matches(jcbRegex)) CardType.JCB
            else if (str.matches(maestroRegex) && str[0] == '5') CardType.MASTERCARD
            else if (str.matches(miteRegex) && environment == Environment.TEST) CardType.MITE
            else CardType.NONE
        }

        private val visaTestCards = listOf(
            "9902000697303071", "9902000671088821", "9902001368432678",
            "9902001342218425", "9902001342177464", "9902000026296350",
            "9902000000082107", "9902000000020669", "9902000167772169"
        )

        private val masterCardTestCards = listOf(
            "9900000697303073", "9900000671088823", "9900001368432670",
            "9900001342218427", "9900001342177466", "9900000026296352",
            "9900000000082109", "9900000000020661", "9900000167772161"
        )

        private val amexTestCards = listOf(
            "9905000697303078", "9905000671088828", "9905001368432675",
            "9905001342218422", "9905001342177461", "9905000026296357",
            "9905000000082104", "9905000000020666", "9905000167772166"
        )

        fun getTestCardType(pan: String): CardType {
            return when {
                visaTestCards.contains(pan) -> CardType.VISA
                masterCardTestCards.contains(pan) -> CardType.MASTERCARD
                amexTestCards.contains(pan) -> CardType.AMEX
                else -> CardType.NONE
            }
        }

        fun isCardHolderNameValid(cardHolderName: String): Boolean {
            // Define a list of allowed characters (letters and spaces) for UK card holder names
            val allowedCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ "

            val lowerCaseName = cardHolderName.lowercase()

            // Check each character in the name
            for (char in lowerCaseName) {
                // Convert the character to bytes using UTF-8 encoding
                val charBytes = char.toString().toByteArray(Charsets.UTF_8)

                // If the character is not in the allowed characters list and its length is greater than 1 (indicating a foreign character),
                // return false, indicating an invalid card holder name
                if (!allowedCharacters.contains(char) && charBytes.size > 1) {
                    return false
                }
            }

            // If all characters are valid, return true
            return true
        }


    }

}