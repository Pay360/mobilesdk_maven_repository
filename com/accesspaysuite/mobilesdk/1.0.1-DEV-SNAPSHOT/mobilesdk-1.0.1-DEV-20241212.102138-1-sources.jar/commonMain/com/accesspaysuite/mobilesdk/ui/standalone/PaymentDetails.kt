package com.accesspaysuite.mobilesdk.ui.standalone

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.card.CardInput
import com.accesspaysuite.mobilesdk.ui.card.CardInputStyleState
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.save.SavedCards
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory

@OptIn(ExperimentalMobileUI::class)
@Composable
internal fun PaymentDetails() {
    AnimatedVisibility(
        visible = PaymentProcessorFactory.currentProcessor != null,
        enter = enterAnimation,
        exit = exitAnimation
    ) {
        Column(
            modifier = Modifier.padding(bottom = 8.dp)
        ) {
            var showCardInput by remember { mutableStateOf(true) }
            SavedCards(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        width = 1.dp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clip(RoundedCornerShape(12.dp))
                    .padding(16.dp),
                onCardSelected = { isNewCardSelected ->
                    showCardInput = isNewCardSelected
                }
            )
            AnimatedVisibility(
                visible = showCardInput
            ) {
                CardInput(
                    state = CardInputStyleState(
                        backgroundCornerSize = 12,
                        labelTextSize = 16,
                        labelTextFontWeight = ComponentFontWeight.NORMAL,
                        fieldTextSize = 16,
                        fieldTextFontWeight = ComponentFontWeight.NORMAL,
                        showCardHolderName = true
                    ),
                )
            }
        }
    }
}