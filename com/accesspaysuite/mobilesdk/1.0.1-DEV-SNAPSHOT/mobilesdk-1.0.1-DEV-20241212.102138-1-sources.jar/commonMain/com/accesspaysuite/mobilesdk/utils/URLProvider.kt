package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.common.TransactionType
import com.accesspaysuite.mobilesdk.utils.Constants.PPO_API_REQUEST_BASE_URL_LIVE
import com.accesspaysuite.mobilesdk.utils.Constants.PPO_API_REQUEST_BASE_URL_TEST

/**
 * @suppress
 */
internal object URLProvider {
    private fun getBaseUrlString(environment: Environment): String {
        return when (environment) {
            Environment.TEST -> PPO_API_REQUEST_BASE_URL_TEST
            Environment.LIVE -> PPO_API_REQUEST_BASE_URL_LIVE
        }
    }

    fun getPaymentProcessUrl(environment: Environment, installationId: String): String =
        "${apiBaseUrl(environment, installationId)}/payment"

    fun getVerifyVerifyUrl(environment: Environment, installationId: String): String =
        "${apiBaseUrl(environment, installationId)}/verify"

    fun getResumePaymentUrl(
        environment: Environment,
        installationId: String,
        transactionId: String
    ): String = "${apiBaseUrl(environment, installationId)}/$transactionId/resume"

    fun getInitiatePaymentUrl(
        environment: Environment,
        installationId: String,
        type: TransactionType,
        currency: String,
        countryCode: String? = null
    ): String = "${
        apiBaseUrl(
            environment,
            installationId
        )
    }/initiate?type=$type&currency=$currency" + if (countryCode != null) "&country=$countryCode" else ""

    fun getInitiatePaymentUrl(
        environment: Environment,
        installationId: String,
        countryCode: String? = null
    ): String = "${
        apiBaseUrl(
            environment,
            installationId
        )
    }/initiate" + if (countryCode != null) "?country=$countryCode" else ""

    private fun apiBaseUrl(environment: Environment, installationId: String): String =
        "${getBaseUrlString(environment)}/acceptor/rest/mobile/transactions/$installationId"
}
