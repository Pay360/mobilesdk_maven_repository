package com.accesspaysuite.mobilesdk.data.internal.common

import androidx.compose.runtime.Stable
import kotlinx.serialization.Serializable

/**
 * Payment type
 *
 * @constructor Create Payment type
 */
@Stable
@Serializable
internal enum class PaymentType {
    /**
     * Guest payment
     *
     * @constructor Create Guest payment
     */
    GuestPayment,

    /**
     * Verify
     *
     * @constructor Create Verify
     */
    Verify,

    /**
     * Token payment
     *
     * @constructor Create Token payment
     */
    TokenPayment,

    /**
     * Google pay payment
     *
     * @constructor Create Google pay payment
     */
    GooglePayPayment,

    /**
     * Apple pay payment
     *
     * @constructor Create Apple pay payment
     */
    ApplePayPayment
}