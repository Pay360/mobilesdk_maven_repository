package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseThreeDSRedirect(
    val acsUrl: String,
    val md: String,
    val termUrl: String? = null,
    val pareq: String? = null,
    val notificationUrl: String,
    val passiveTimeout: Int,
    val sessionTimeout: Int,
    val threeDSServerTransId: String
)