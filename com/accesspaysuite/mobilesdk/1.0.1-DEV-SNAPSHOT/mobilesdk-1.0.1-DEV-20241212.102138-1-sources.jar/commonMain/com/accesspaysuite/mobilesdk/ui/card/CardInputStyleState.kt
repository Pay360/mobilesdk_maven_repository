package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight

/**
 * Card Input Style State.
 *
 * Android View System
 * ```kotlin
 * processor.initiate { nonNullProcessor ->
 *     val styleState = CardInputStyleState()
 *     cardInputView.init(styleState)
 * }
 * ```
 * Jetpack Compose
 * ```kotlin
 * val styleState = rememberCardInputStyleState(
 *     showCardHolderName = true
 * )
 * CardInputSlim(state = styleState)
 * ```
 * Swift
 * ```swift
 * @State private var cardState: CardInputStyleState = CardInputStyleState()
 * @State private var onCardError: (String) -> Void = { error in
 *
 * }
 * ```
 * ```swift
 * CardInput(
 *     state: $cardState,
 *     onError: $onCardError
 * )
 * ```
 * @param backgroundCornerSize The size of the background corner in the card input. Default value is 0.
 * @param labelLocation The location of the label in the card input. Default value is LabelLocation.TOP.
 * @param labelTextSize The size of the label text in the card input. Default value is 12.
 * @param labelTextFontWeight The font weight of the label text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param fieldTextSize The size of the field text in the card input. Default value is 12.
 * @param fieldTextFontWeight The font weight of the field text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param showCardHolderName A boolean indicating whether the cardholder's name should be shown. Default value is true.
 */
@Stable
data class CardInputStyleState(
    val backgroundCornerSize: Int = 0,
    val labelLocation: LabelLocation = LabelLocation.TOP,
    val labelTextSize: Int = 14,
    val labelTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    val fieldTextSize: Int = 14,
    val fieldTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    val showCardHolderName: Boolean = true,
) {

    constructor() : this(
        backgroundCornerSize = 0,
        labelLocation = LabelLocation.TOP,
        labelTextSize = 14,
        labelTextFontWeight = ComponentFontWeight.NORMAL,
        fieldTextSize = 14,
        fieldTextFontWeight = ComponentFontWeight.NORMAL,
        showCardHolderName = true
    )

}

/**
 * Remember card input style state
 *
 * @param key
 * @param backgroundCornerSize
 * @param labelLocation
 * @param labelTextSize
 * @param labelTextFontWeight
 * @param fieldTextSize
 * @param fieldTextFontWeight
 * @param showCardHolderName
 */
@Composable
fun rememberCardInputStyleState(
    key: Any = Unit,
    backgroundCornerSize: Int = 0,
    labelLocation: LabelLocation = LabelLocation.TOP,
    labelTextSize: Int = 14,
    labelTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    fieldTextSize: Int = 14,
    fieldTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = true
) = remember(key) {
    CardInputStyleState(
        backgroundCornerSize,
        labelLocation,
        labelTextSize,
        labelTextFontWeight,
        fieldTextSize,
        fieldTextFontWeight,
        showCardHolderName
    )
}

/**
 * Remember card input style state
 *
 * @param keys
 * @param backgroundCornerSize
 * @param labelLocation
 * @param labelTextSize
 * @param labelTextFontWeight
 * @param fieldTextSize
 * @param fieldTextFontWeight
 * @param showCardHolderName
 */
@Composable
fun rememberCardInputStyleState(
    vararg keys: Any = arrayOf(Unit),
    backgroundCornerSize: Int = 0,
    labelLocation: LabelLocation = LabelLocation.TOP,
    labelTextSize: Int = 14,
    labelTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    fieldTextSize: Int = 14,
    fieldTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = true
) = remember(keys) {
    CardInputStyleState(
        backgroundCornerSize,
        labelLocation,
        labelTextSize,
        labelTextFontWeight,
        fieldTextSize,
        fieldTextFontWeight,
        showCardHolderName
    )
}