package com.accesspaysuite.mobilesdk.callbacks.internal

import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.common.ThreeDSResponse

/**
 * ThreeDS result callback
 *
 * @constructor Create empty ThreeDS result callback
 */
internal interface ThreeDSResultCallback {

    /**
     * ThreeDS process success
     *
     * @param response
     * @param paymentType
     */
    fun threeDSProcessSuccess(response: ThreeDSResponse?, paymentType: PaymentType)

    /**
     * ThreeDS process failure
     *
     * @param reason
     * @param paymentType
     */
    fun threeDSProcessFailure(reason: String?, paymentType: PaymentType)

}