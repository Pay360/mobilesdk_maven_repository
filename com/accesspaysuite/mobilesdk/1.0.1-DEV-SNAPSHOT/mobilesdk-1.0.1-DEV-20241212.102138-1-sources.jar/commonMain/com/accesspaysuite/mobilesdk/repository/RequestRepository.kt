package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentBody
import com.accesspaysuite.mobilesdk.data.common.TransactionType
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateResponse
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBankingPaymentResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.utils.NetworkEngine.client
import com.accesspaysuite.mobilesdk.utils.answerWithDelegate
import com.accesspaysuite.mobilesdk.utils.retrieveResponse

internal interface RequestRepository {

    /**
     * Initiates a payment for AP.
     * @param currencyCode Transaction currency (ISO-4217 alpha-3), e.g.: GBP, EUR, USD, etc.
     * @param countryCode Customer country (ISO-3166 alpha-3), e.g.: GBR, FRA, USA, etc.
     */
    fun initiatePayment(
        environment: Environment,
        installationId: String,
        clientToken: String,
        transactionType: TransactionType,
        currencyCode: String,
        countryCode: String? = null,
        onSuccess: (InitiateResponse) -> Unit,
        onFailure: (Status) -> Unit
    )

    fun request(
        url: String,
        httpMethod: String,
        requestType: APIRequestType,
        authCredentials: AuthCredentials,
        bodyObject: PaymentBody,
        delegate: HttpRequestDelegate<PaymentResponse>,
    )

    fun obRequest(
        url: String,
        httpMethod: String,
        requestType: APIRequestType,
        authCredentials: AuthCredentials,
        bodyObject: PaymentBody,
        delegate: HttpRequestDelegate<OpenBankingPaymentResponse>,
    )

    companion object {
        internal suspend inline fun <reified T> serverRequest(
            url: String,
            httpMethod: String,
            requestType: APIRequestType,
            authCredentials: AuthCredentials,
            bodyObject: PaymentBody,
            delegate: HttpRequestDelegate<T>
        ) {
            try {
                client.retrieveResponse(
                    url = url,
                    httpMethod = httpMethod,
                    authCredentials = authCredentials,
                    bodyObject = bodyObject
                ).answerWithDelegate(
                    requestType = requestType,
                    delegate = delegate
                )
            } catch (e: Exception) {
                e.printStackTrace()
                delegate.responseReceivedWithFailure(
                    requestType = requestType,
                    reason = e.message
                )
            }
        }
    }

}

