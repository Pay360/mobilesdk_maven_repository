package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseApplePay(
    val usageType: String? = null,
    val cardScheme: String? = null,
    val displayName: String? = null
)