package com.accesspaysuite.mobilesdk.ui

@RequiresOptIn("The API of this UI is experimental and is likely to change in the future.")
@Retention(AnnotationRetention.BINARY)
annotation class ExperimentalMobileUI()
