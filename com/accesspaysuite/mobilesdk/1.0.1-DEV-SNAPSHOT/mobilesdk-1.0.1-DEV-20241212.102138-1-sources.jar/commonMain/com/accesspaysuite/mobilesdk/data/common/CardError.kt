package com.accesspaysuite.mobilesdk.data.common

/**
 * # Card error
 */
sealed class CardError(open val message: String) {

    /**
     * # Card Number Error
     *
     * It will trigger when the card number is invalid
     * Validation:
     * - Card number must pass the Luhn algorithm
     *
     * @property message
     */
    data class CardNumber(override val message: String) : CardError(message)

    /**
     * # Expiry Date Error
     *
     * It will trigger when the expiry date is invalid
     * Validation:
     * - Expiry date must be in the future
     *
     * @property message
     */
    data class ExpiryDate(override val message: String): CardError(message)

    /**
     * # CVV/CSC/CV2 Error
     *
     * It will trigger when the CVV is invalid
     * Validation:
     * - CVV must be 3 or 4 digits
     *
     * @property message
     */
    data class Cvv(override val message: String): CardError(message)

    /**
     * # Cardholder Error
     *
     * It will trigger when the cardholder name is invalid
     * Validation:
     * - Cardholder name must not be empty
     * - Cardholder name must not contain special characters
     * - Cardholder name must not contain numbers
     *
     * @property message
     */
    data class Cardholder(override val message: String): CardError(message)
    
}

/**
 * # Map error handling lambda for each error type
 *
 * @param onCardNumberError
 * @param onExpiryDateError
 * @param onCvvError
 * @param onCardholderError
 */
fun Array<CardError>.forError(
    onCardNumberError: (String) -> Unit = {},
    onExpiryDateError: (String) -> Unit = {},
    onCvvError: (String) -> Unit = {},
    onCardholderError: (String) -> Unit = {}
) = forEach {
    when(it) {
        is CardError.CardNumber -> onCardNumberError(it.message)
        is CardError.Cardholder -> onExpiryDateError(it.message)
        is CardError.Cvv -> onCvvError(it.message)
        is CardError.ExpiryDate -> onCardholderError(it.message)
    }
}

/**
 * Map CardError list to a string divided by a separator
 *
 * @return
 */
fun Array<CardError>.mapToString(separator: String = "\n"): String {
    return joinToString(separator = separator) { it.message }
}