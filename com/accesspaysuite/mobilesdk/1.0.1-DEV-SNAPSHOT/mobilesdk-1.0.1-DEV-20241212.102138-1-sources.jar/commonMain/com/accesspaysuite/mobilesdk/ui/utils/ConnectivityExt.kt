package com.accesspaysuite.mobilesdk.ui.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import kotlinx.coroutines.ExperimentalCoroutinesApi

@ExperimentalCoroutinesApi
@Composable
internal expect fun connectivityState(): State<ConnectionState>

internal sealed class ConnectionState {
    data object Available : ConnectionState()
    data object Unavailable : ConnectionState()

    val isConnected: Boolean get() = this is Available
}