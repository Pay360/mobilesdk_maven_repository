package com.accesspaysuite.mobilesdk.data.common

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

/**
 * # Billing Address
 *
 * > The billing address of the Customer. Will be used for AVS checks. We’ll save the billing address when the customer makes their first payment.
 * > Providing a billing address for subsequent payments will update the address we’ve saved if you send new, empty or no values for each field.
 *
 * @property line1 Line 1 of the Customer’s billing address.
 * @property line2 Line 2 of the Customer’s billing address.
 * @property line3 Line 3 of the Customer’s billing address.
 * @property line4 Line 4 of the Customer’s billing address.
 * @property city City of the Customer’s billing address.
 * @property region Region of the Customer’s billing address.
 * @property postcode Postcode of the Customer’s billing address.
 * @property countryCode The 3 character ISO-3166-1 code for the Customer’s billing address country.
 * @property email Email address of the Customer.
 */
@Parcelize
@Serializable
data class BillingAddress(
    var line1: String? = null,
    var line2: String? = null,
    var line3: String? = null,
    var line4: String? = null,
    var city: String? = null,
    var region: String? = null,
    var postcode: String? = null,
    var countryCode: String? = null,
    var email: String? = null
) : Parcelable{

    constructor(): this(
        line1 = "",
        line2 = "",
        line3 = "",
        line4 = "",
        city = "",
        region = "",
        postcode = "",
        countryCode = "",
        email = ""
    )

    /**
     * Set line1
     *
     * @param line1
     * @return
     */
    fun setLine1(line1: String?): BillingAddress {
        this.line1 = line1
        return this
    }

    /**
     * Set line2
     *
     * @param line2
     * @return
     */
    fun setLine2(line2: String?): BillingAddress {
        this.line2 = line2
        return this
    }

    /**
     * Set line3
     *
     * @param line3
     * @return
     */
    fun setLine3(line3: String?): BillingAddress {
        this.line3 = line3
        return this
    }

    /**
     * Set line4
     *
     * @param line4
     * @return
     */
    fun setLine4(line4: String?): BillingAddress {
        this.line4 = line4
        return this
    }

    /**
     * Set city
     *
     * @param city
     * @return
     */
    fun setCity(city: String?): BillingAddress {
        this.city = city
        return this
    }

    /**
     * Set region
     *
     * @param region
     * @return
     */
    fun setRegion(region: String?): BillingAddress {
        this.region = region
        return this
    }

    /**
     * Set postcode
     *
     * @param postcode
     * @return
     */
    fun setPostcode(postcode: String?): BillingAddress {
        this.postcode = postcode
        return this
    }

    /**
     * Set country code
     *
     * @param countryCode
     * @return
     */
    fun setCountryCode(countryCode: String): BillingAddress {
        this.countryCode = countryCode
        return this
    }

    /**
     * Set email
     *
     * @param email
     * @return
     */
    fun setEmail(email: String): BillingAddress {
        this.email = email
        return this
    }

    /**
     * Is empty
     *
     * @return
     */
    internal fun isEmpty(): Boolean {
        return line1.isNullOrEmpty() && line2.isNullOrEmpty() && line3.isNullOrEmpty() && line4.isNullOrEmpty() &&
                city.isNullOrEmpty() && region.isNullOrEmpty() && postcode.isNullOrEmpty() && countryCode.isNullOrEmpty()
    }
}
