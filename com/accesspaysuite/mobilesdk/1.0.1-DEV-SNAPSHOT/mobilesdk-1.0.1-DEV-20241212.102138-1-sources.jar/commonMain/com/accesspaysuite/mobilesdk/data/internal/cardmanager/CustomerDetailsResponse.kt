package com.accesspaysuite.mobilesdk.data.internal.cardmanager

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Parcelize
@Serializable
data class CustomerDetailsResponse(
    val id: String,
): Parcelable
