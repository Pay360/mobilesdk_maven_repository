package com.accesspaysuite.mobilesdk.data.internal.googlepay

import kotlinx.serialization.Serializable

/**
 * Represents an Google Pay Payment Request.
 */
@Serializable
internal data class GooglePayPayment(
    var paymentData: GooglePayPaymentData,
    var paymentMethod: GooglePayPaymentMethod,
    var apiVersion: String?
)

@Serializable
internal data class GooglePayPaymentData(
    val token: String?
)

@Serializable
internal data class GooglePayPaymentMethod(
    val displayName: String?,
    val network: String?,
    val details: String?
)