package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.data.internal.common.DeviceInfo

/**
 * Responsible for providing device information.
 */
internal expect class DeviceInfoController {
    internal val merchantAppVersion: String
    internal val merchantAppName: String
    internal val sdkVersion: String

    /**
     * To device info
     *
     * @return
     */
    internal fun toDeviceInfo(): DeviceInfo
}