package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.cardmanager.CustomerDetailsResponse
import com.accesspaysuite.mobilesdk.data.internal.cardmanager.CustomerMethod
import com.accesspaysuite.mobilesdk.utils.NetworkEngine
import io.github.aakira.napier.DebugAntilog
import io.github.aakira.napier.Napier
import io.ktor.client.request.basicAuth
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.contentType
import io.ktor.http.isSuccess
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json

/**
 * Implementation of [CardManagerRepository]
 *
 * Only available for the Advance Payments Solution
 */
internal class CardManagerRepositoryImpl : CardManagerRepository {

    private val client = NetworkEngine.client
    private val parser = Json {
        explicitNulls = false
        ignoreUnknownKeys = true
    }

    init {
        Napier.base(DebugAntilog("PaysuiteSDK"))
    }

    private fun getBaseUrl(environment: Environment, installationId: String) = when (environment) {
        Environment.TEST -> "https://api.mite.pay360.com/acceptor/rest/customers/$installationId/"
        Environment.LIVE -> "https://api.pay360.com/acceptor/rest/customers/$installationId/"
    }

    override suspend fun getCustomerId(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String
    ): String? = withContext(Dispatchers.IO) {
        val response = client.request(
           getBaseUrl(environment, installationId) + "byRef?merchantRef=$customerReference"
        ) {
            basicAuth(username, password)
            method = HttpMethod.Get
        }
        if (response.status.isSuccess()) {
            try {
                parser.decodeFromString<CustomerDetailsResponse>(response.bodyAsText()).id
            } catch (e: Exception) {
                e.printStackTrace()
                Napier.e("Error getting customer id", e)
                null
            }
        } else null
    }

    override suspend fun getCustomerMethods(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String
    ): List<CustomerMethod> = withContext(Dispatchers.IO) {
        val customerId =
            getCustomerId(username, password, installationId, environment, customerReference)
                ?: return@withContext emptyList()

        val response = client.request(
            getBaseUrl(environment, installationId) + "$customerId/paymentMethods"
        ) {
            basicAuth(username, password)
            method = HttpMethod.Get
        }
        if (response.status.isSuccess()) {
            try {
                parser.decodeFromString<List<CustomerMethod>>(response.bodyAsText())
                    .sortedByDescending { it.paymentClass }
                    .sortedByDescending { it.card.cardScheme }
                    .sortedByDescending { it.isPrimary }
            } catch (e: Exception) {
                e.printStackTrace()
                Napier.e("Error getting customer methods", e)
                emptyList()
            }
        } else emptyList()
    }

    override suspend fun deleteCard(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String,
        cardToken: String
    ): Boolean = withContext(Dispatchers.IO) {
        val customerId =
            getCustomerId(username, password, installationId, environment, customerReference)
                ?: return@withContext false

        val response = client.request(
            getBaseUrl(environment, installationId) + "$customerId/paymentMethod/$cardToken/remove"
        ) {
            basicAuth(username, password)
            method = HttpMethod.Post
            contentType(ContentType.Application.Json)
            setBody("{}")
        }
        response.status.isSuccess()
    }

    override suspend fun makePrimaryCard(
        username: String,
        password: String,
        installationId: String,
        environment: Environment,
        customerReference: String,
        cardToken: String
    ): Boolean = withContext(Dispatchers.IO) {
        val customerId =
            getCustomerId(username, password, installationId, environment, customerReference)
                ?: return@withContext false

        val response = client.request(
            getBaseUrl(environment, installationId) + "$customerId/paymentMethod/$cardToken/makeDefault"
        ) {
            basicAuth(username, password)
            method = HttpMethod.Post
            contentType(ContentType.Application.Json)
            setBody("{}")
        }
        if (response.status.isSuccess()) {
            try {
                parser.decodeFromString<CustomerMethod>(response.bodyAsText()).isPrimary
            } catch (e: Exception) {
                e.printStackTrace()
                Napier.e("Error making card primary", e)
                false
            }
        } else {
            Napier.e("Error making card primary: ${response.status}")
            false
        }
    }

}