package com.accesspaysuite.mobilesdk.data.internal.cardmanager

import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import kotlinx.serialization.Serializable

@Serializable
@Parcelize
internal data class CustomerMethod(
    val paymentClass: String,
    val card: CustomerCard,
    val isPrimary: Boolean
): Parcelable