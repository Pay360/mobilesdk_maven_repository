package com.accesspaysuite.mobilesdk.utils

internal expect class StorageUtils {

    fun getString(key: String, default: String? = ""): String?

    fun putString(key: String, value: String?)

}