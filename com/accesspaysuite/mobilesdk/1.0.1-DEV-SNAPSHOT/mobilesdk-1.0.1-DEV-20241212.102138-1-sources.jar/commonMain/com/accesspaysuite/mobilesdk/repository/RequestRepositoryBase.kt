package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentBody
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBankingPaymentResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.repository.RequestRepository.Companion.serverRequest
import com.accesspaysuite.mobilesdk.utils.NetworkEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Base implementation of [RequestRepository].
 */
internal abstract class RequestRepositoryBase : RequestRepository {


    protected val client by lazy { NetworkEngine.client }
    protected val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    override fun request(
        url: String,
        httpMethod: String,
        requestType: APIRequestType,
        authCredentials: AuthCredentials,
        bodyObject: PaymentBody,
        delegate: HttpRequestDelegate<PaymentResponse>
    ) {
        scope.launch {
            serverRequest(
                url = url,
                httpMethod = httpMethod,
                requestType = requestType,
                authCredentials = authCredentials,
                bodyObject = bodyObject,
                delegate = delegate
            )
        }
    }

    override fun obRequest(
        url: String,
        httpMethod: String,
        requestType: APIRequestType,
        authCredentials: AuthCredentials,
        bodyObject: PaymentBody,
        delegate: HttpRequestDelegate<OpenBankingPaymentResponse>
    ) {
        scope.launch {
            serverRequest(
                url = url,
                httpMethod = httpMethod,
                requestType = requestType,
                authCredentials = authCredentials,
                bodyObject = bodyObject,
                delegate = delegate
            )
        }
    }

}