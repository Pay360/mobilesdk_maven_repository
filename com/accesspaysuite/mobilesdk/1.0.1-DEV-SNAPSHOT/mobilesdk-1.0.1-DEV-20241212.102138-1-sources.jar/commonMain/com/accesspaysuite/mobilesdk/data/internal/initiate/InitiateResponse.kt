package com.accesspaysuite.mobilesdk.data.internal.initiate

import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.common.SaveCardMethods
import com.accesspaysuite.mobilesdk.data.internal.common.StoredCard
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePaymentDataAuthMethods
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** ## TODO: Fix API response when token is expired
### ENDPOINT `/acceptor/rest/mobile/transactions/{{instId}}/initiate`

### ISSUE
Does not return an InitiateResponse object, but a PaymentResponse object when token is expired

EXPECTED:
```json
{
    "acceptPaymentMethods": null,
    "applePay": null,
    "card": null,
    "googlePay": null,
    "openBanking": null,
    "trace": null,
    "outcome": {
        "reasonCode": "3",
        "reasonMessage": "Client token expired",
        "status": "FAILED"
    }
}
```

REALITY:
```json
{
    "paymentMethod":null,
    "transaction":null,
    "customer":null,
    "threeDSRedirect":null,
    "threeDSecure":null,
    "customFields":null,
    "outcome": {
        "status":"FAILED",
        "reasonCode":"3",
        "reasonMessage":"Client token expired"
    },
    "trace":null
}
 */
@Serializable
internal data class InitiateResponse(
    @SerialName("acceptPaymentMethods")
    val acceptPaymentMethods: List<AcceptPaymentMethods>? = null,
    @SerialName("applePay")
    val applePay: InitiateApplePay? = null,
    @SerialName("card")
    val card: InitiateCard? = null,
    @SerialName("googlePay")
    val googlePay: InitiateGooglePay? = null,
    @SerialName("openBanking")
    val openBanking: InitiateOpenBanking? = null,
    @SerialName("outcome")
    val outcome: InitiateOutcome,
    @SerialName("trace")
    val trace: String? = null
)

@Serializable
internal data class InitiateOpenBanking(
    @SerialName("availableCountries")
    val availableCountries: List<String>,
)

@Serializable
enum class AcceptPaymentMethods {
    CARD, APPLEPAY, GOOGLEPAY, OPENBANKING;

    override fun toString(): String {
        return name.uppercase()
    }
}

@Serializable
internal data class InitiateCard(
    @SerialName("acceptSchemes")
    val acceptSchemes: List<CardType>?,
    @SerialName("saveMethod")
    val saveMethod: SaveCardMethods?,
    @SerialName("storedCards")
    val storedCards: List<StoredCard>?
)

@Serializable
internal data class InitiateGooglePay(
    @SerialName("allowedCardAuthMethods")
    val allowedCardAuthMethods: List<GooglePaymentDataAuthMethods>,
    @SerialName("allowedCardNetworks")
    val allowedCardNetworks: List<CardType>,
    @SerialName("environment")
    val environment: Environment,
    @SerialName("merchantInfo")
    val merchantInfo: MerchantInfo,
    @SerialName("tokenizationSpecification")
    val tokenizationSpecification: GooglePayTokenizationSpecification,
    @SerialName("transaction")
    val transaction: GooglePayTransaction
)

@Serializable
internal data class InitiateApplePay(
    @SerialName("amount")
    // Non-null for Evolve/SBS
    val amount: String? = null,
    @SerialName("currencyCode")
    val currencyCode: String,
    @SerialName("merchantCountryCode")
    val merchantCountryCode: String ,
    @SerialName("supportedNetworks")
    val supportedNetworks: List<CardType>
)

@Serializable
internal data class MerchantInfo(
    @SerialName("merchantId")
    val merchantId: String = "",
    @SerialName("merchantName")
    val merchantName: String = ""
)

@Serializable
internal data class InitiateOutcome(
    @SerialName("reasonCode")
    // Simplified numeric code for mobile, e.g. 0 = Success, 1 = Invalid, 2 = Authentication fail, etc.
    val reasonCode: String = "",
    @SerialName("reasonMessage")
    // "Initiated" on success
    val reasonMessage: String,
    @SerialName("status")
    val status: OutcomeStatus
)

@Serializable
internal enum class OutcomeStatus {
    SUCCESS, FAILED, PROCESSING;

    override fun toString(): String {
        return name.uppercase()
    }
}

@Serializable
internal data class Parameters(
    @SerialName("gateway")
    val gateway: String,
    @SerialName("gatewayMerchantId")
    val gatewayMerchantId: String
)

@Serializable
internal data class GooglePayTokenizationSpecification(
    @SerialName("parameters")
    val parameters: Parameters,
    @SerialName("type")
    val type: String
)

@Serializable
internal data class GooglePayTransaction(
    @SerialName("countryCode")
    val countryCode: String,
    @SerialName("currencyCode")
    val currencyCode: String,
    @SerialName("totalPrice")
    // Non-null for Evolve/SBS
    val totalPrice: String? = null,
    @SerialName("totalPriceStatus")
    val totalPriceStatus: String
)