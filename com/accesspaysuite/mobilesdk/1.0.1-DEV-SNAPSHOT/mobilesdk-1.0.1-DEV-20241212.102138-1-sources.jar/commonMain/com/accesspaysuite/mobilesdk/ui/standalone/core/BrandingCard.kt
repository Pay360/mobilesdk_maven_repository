package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.paysuite_legal_notice
import com.accesspaysuite.mobilesdk.sdk.generated.resources.paysuite_logo
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun BrandingCard() {
    Column(
        modifier = Modifier
            .padding(vertical = 24.dp)
            .fillMaxWidth()
    ) {
        Image(
            painter = painterResource(Res.drawable.paysuite_logo),
            colorFilter = ColorFilter.tint(MaterialTheme.colorScheme.onBackground),
            contentDescription = "PaySuite Logo",
            modifier = Modifier.height(32.dp),
            contentScale = ContentScale.FillHeight
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = stringResource(Res.string.paysuite_legal_notice),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Light
        )
    }
}