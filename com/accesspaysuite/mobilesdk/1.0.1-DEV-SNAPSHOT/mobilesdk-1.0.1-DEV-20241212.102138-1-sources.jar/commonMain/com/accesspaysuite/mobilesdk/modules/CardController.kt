package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.callbacks.internal.ThreeDSResultCallback
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.Card
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentBody
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentInfo
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.common.ThreeDSResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.utils.URLProvider
import com.accesspaysuite.mobilesdk.utils.toAPIRequestType
import com.accesspaysuite.mobilesdk.utils.toPaymentType
import io.github.aakira.napier.Napier

/**
 * Payment Controller for card related operations
 *
 * @property repository
 * @property deviceInfoController
 * @property threeDSController
 * @property delegate
 * @constructor Create Card controller
 */
internal class CardController(
    private val repository: RequestRepository,
    private val deviceInfoController: DeviceInfoController,
    private val threeDSController: ThreeDSController,
    private val delegate: PaymentResultCallback
) : ThreeDSResultCallback, HttpRequestDelegate<PaymentResponse> {

    private var paymentInfo: PaymentInfo? = null
    internal var saveCard: Boolean = false

    private val credentials: AuthCredentials by lazy {
        AuthCredentials(
            token = paymentInfo!!.clientToken,
            providerId = paymentInfo!!.providerId
        )
    }

    /**
     * Set payment info
     *
     * @param paymentInfo
     */
    fun setPaymentInfo(paymentInfo: PaymentInfo) {
        this.paymentInfo = paymentInfo
    }

    /**
     * Process token payment
     *
     * @param card
     * @param billingAddress
     */
    fun processTokenPayment(card: Card, billingAddress: BillingAddress?) {
        requireNotNull(paymentInfo) { "PaymentInfo must be set before calling processTokenPayment" }
        val paymentRequestUrl = URLProvider.getPaymentProcessUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId
        )
        val body = paymentInfo!!.newPayment(
            paymentMethod = PaymentMethod(cardToken = card),
            registeredCustomer = true,
            billingAddress = billingAddress,
            deviceInfoController = deviceInfoController
        )
        repository.request(
            url = paymentRequestUrl,
            httpMethod = "POST",
            requestType = APIRequestType.APIRequestTokenPayment,
            authCredentials = credentials,
            bodyObject = body,
            delegate = this@CardController
        )
    }

    /**
     * Process guest payment
     *
     * @param card
     * @param billingAddress
     */
    fun processGuestPayment(card: Card, billingAddress: BillingAddress?) {
        requireNotNull(paymentInfo) { "PaymentInfo must be set before calling processGuestPayment" }
        val paymentRequestUrl = URLProvider.getPaymentProcessUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId
        )
        val body = paymentInfo!!.newPayment(
            paymentMethod = PaymentMethod(card = card),
            registeredCustomer = saveCard,
            billingAddress = billingAddress,
            deviceInfoController = deviceInfoController
        )
        repository.request(
            url = paymentRequestUrl,
            httpMethod = "POST",
            requestType = APIRequestType.APIRequestGuestPayment,
            authCredentials = credentials,
            bodyObject = body,
            delegate = this@CardController
        )
    }

    /**
     * Process verify request
     *
     * @param card
     * @param billingAddress
     */
    fun processVerifyRequest(card: Card, billingAddress: BillingAddress?) {
        requireNotNull(paymentInfo) { "PaymentInfo must be set before calling processVerifyRequest" }
        val paymentRequestUrl = URLProvider.getVerifyVerifyUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId
        )
        val body = paymentInfo!!.newPayment(
            paymentMethod = PaymentMethod(card = card),
            registeredCustomer = saveCard,
            billingAddress = billingAddress,
            deviceInfoController = deviceInfoController
        )
        repository.request(
            url = paymentRequestUrl,
            httpMethod = "POST",
            requestType = APIRequestType.APIRequestVerify,
            authCredentials = credentials,
            bodyObject = body,
            delegate = this@CardController
        )
    }

    /**
     * To be called by once the 3DS process has been completed and token provided.
     */
    private fun resumePayment(pares: String?, paymentType: PaymentType) {
        requireNotNull(paymentInfo) { "PaymentInfo must be set before calling resumePayment" }
        val paymentRequestUrl = URLProvider.getResumePaymentUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId,
            paymentInfo!!.transaction!!.transactionId!!
        )
        val body = PaymentBody(
            threeDSecureResponse = pares?.let { ThreeDSResponse(pares = pares) }
        )
        repository.request(
            paymentRequestUrl,
            "POST",
            paymentType.toAPIRequestType(),
            credentials,
            body,
            this@CardController
        )
    }

    /**
     * PPOThreeDSDelegate Delegate method triggered on successful 3DS Response.
     * @param paymentType the type of payment flow being triggered.
     * @param response the type of the flow being requested
     */
    override fun threeDSProcessSuccess(response: ThreeDSResponse?, paymentType: PaymentType) {
        resumePayment(response?.pares, paymentType)
    }

    /**
     * PPOThreeDSDelegate Delegate method triggered on unsuccessful 3DS Response.
     * @param paymentType the type of payment flow being triggered.
     * @param reason the details on why the call failed.
     */
    override fun threeDSProcessFailure(reason: String?, paymentType: PaymentType) {
        delegate.onPaymentResult(Status.Error(reason ?: "Unknown error"))
    }

    /**
     * PPOHttpRequestDelegate Delegate method triggered on successful HTTP call
     * @param requestType the type of the flow being requested
     * @param response the JSON response body returned by the HTTP call
     */
    override fun responseReceivedWithSuccess(
        requestType: APIRequestType,
        response: PaymentResponse
    ) {
        val paymentType = requestType.toPaymentType()
        val status = response.retrieveStatus()
        if (status is Status.Success) {
            // Update transactionId with the one returned by the server
            paymentInfo = paymentInfo?.copy(
                transaction = paymentInfo?.transaction?.copy(
                    transactionId = response.transaction?.transactionId
                )
            )
            // If 3DS is required, run the 3DS process
            response.threeDSRedirect?.let {
                threeDSController.run3DSProcess(
                    delegate = this@CardController,
                    paymentType = paymentType,
                    params = it
                )
            } ?: delegate.onPaymentResult(status)
        } else {
            delegate.onPaymentResult(status)
        }
    }

    private fun PaymentResponse.retrieveStatus(): Status {
        return if (outcome.status == STATUS_SUCCESS) {
            Status.Success
        } else {
            if (threeDSecure?.cardHolderMessage != null) {
                Status.Error(threeDSecure.cardHolderMessage)
            } else if (outcome.reasonMessage != null) {
                Napier.e { "Payment failed: ${outcome.reasonMessage} | Status: ${outcome.status} | TraceID: $trace" }
                if (outcome.reasonMessage == "Client token expired") {
                    Status.SessionExpired
                } else Status.Error(outcome.reasonMessage)
            } else {
                // Just for unexpected errors, this should never happen, but it's best to have
                // a way to debug if it does
                Napier.e { "Payment failed: Unknown error | Status: ${outcome.status} | TraceID: $trace" }
                Status.Error("Unknown error\nPlease contact administrator.")
            }
        }
    }

    override fun responseReceivedWithFailure(requestType: APIRequestType, reason: String?) {
        delegate.onPaymentResult(Status.Error(reason ?: "Unknown error"))
    }

    companion object {
        internal const val STATUS_SUCCESS = "SUCCESS"
    }

}