package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.PaymentProcessor
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.save_card
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveSwitch
import io.github.alexzhirkevich.cupertino.adaptive.ExperimentalAdaptiveApi
import org.jetbrains.compose.resources.stringResource

/**
 * # Save Card Box Component
 *
 * This component is used to determine if the user wants to save the card details
 *
 * Optional component; can be replaced by merchant's own implementation
 * that invokes the following function:
 * [PaymentProcessor.setSaveCard] to set the switch state
 * [PaymentProcessor.canSaveCards] to check if the user can save the card
 *
 * @param modifier The modifier to be applied to the layout.
 * @param state The state of the save card box.
 */
@Composable
@ExperimentalMobileUI
fun SaveCardBox(
    modifier: Modifier = Modifier,
    state: SaveCardState
) = SaveCardBox(
    modifier = modifier,
    fontSize = state.fontSize.sp,
    fontWeight = state.fontWeight,
    defaultState = state.defaultState
)

/**
 * # Save Card Box Component
 *
 * This component is used to determine if the user wants to save the card details
 *
 * Optional component; can be replaced by merchant's own implementation
 * that invokes the following function:
 * [PaymentProcessor.setSaveCard] to set the switch state
 * [PaymentProcessor.canSaveCards] to check if the user can save the card
 *
 * @param modifier The modifier to be applied to the layout.
 * @param fontSize The font size of the text.
 * @param fontWeight The font weight of the text.
 * @param defaultState The default state of the switch.
 */
@OptIn(ExperimentalAdaptiveApi::class)
@ExperimentalMobileUI
@Composable
fun SaveCardBox(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 16.sp,
    fontWeight: ComponentFontWeight = ComponentFontWeight.BOLD,
    defaultState: Boolean = false,
) {
    PaymentUITheme {
        var checkState by remember { mutableStateOf(defaultState) }
        var isControlEnabled by remember { mutableStateOf(false) }
        val processor = PaymentProcessorFactory.currentProcessor

        LaunchedEffect(processor) {
            isControlEnabled = processor?.isAllowedToSaveCard() ?: false
        }
        LaunchedEffect(checkState) {
            processor?.setSaveCard(checkState)
        }
        AnimatedVisibility(
            visible = isControlEnabled,
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            Row(
                modifier = modifier
                    .fillMaxWidth()
                    .clickable { checkState = !checkState },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = stringResource(Res.string.save_card),
                    fontSize = fontSize,
                    fontWeight = fontWeight.value
                )
                AdaptiveSwitch(
                    checked = checkState,
                    onCheckedChange = { checkState = it },
                    enabled = isControlEnabled
                )
            }
        }
    }
}