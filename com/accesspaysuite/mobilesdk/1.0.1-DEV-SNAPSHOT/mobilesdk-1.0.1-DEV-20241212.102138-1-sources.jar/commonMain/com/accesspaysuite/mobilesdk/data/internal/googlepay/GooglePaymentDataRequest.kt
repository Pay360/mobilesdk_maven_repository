package com.accesspaysuite.mobilesdk.data.internal.googlepay

import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.internal.initiate.GooglePayTokenizationSpecification
import com.accesspaysuite.mobilesdk.data.internal.initiate.GooglePayTransaction
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateGooglePay
import com.accesspaysuite.mobilesdk.data.internal.initiate.MerchantInfo
import kotlinx.serialization.Serializable

internal fun InitiateGooglePay.newRequest(billingAddressRequired: Boolean = true, amount: String? = null): GooglePaymentDataRequest {
    return GooglePaymentDataRequest(
        apiVersion = 2,
        apiVersionMinor = 0,
        merchantInfo = merchantInfo,
        allowedPaymentMethods = listOf(
            GooglePaymentDataPaymentMethods(
                type = "CARD",
                parameters = GooglePaymentDataParameters(
                    allowedAuthMethods = allowedCardAuthMethods,
                    allowedCardNetworks = allowedCardNetworks,
                    billingAddressRequired = billingAddressRequired
                ),
                tokenizationSpecification = tokenizationSpecification,
            )
        ),
        transactionInfo = if (amount.isNullOrEmpty()) transaction else transaction.copy(totalPrice = amount),
    )
}

@Serializable
internal data class GooglePaymentDataRequest(
    val apiVersion: Int,
    val apiVersionMinor: Int,
    val merchantInfo: MerchantInfo,
    val allowedPaymentMethods: List<GooglePaymentDataPaymentMethods>,
    val transactionInfo: GooglePayTransaction,
)

@Serializable
internal data class GooglePaymentDataPaymentMethods(
    val type: String,
    val parameters: GooglePaymentDataParameters,
    val tokenizationSpecification: GooglePayTokenizationSpecification
)

@Serializable
internal data class GooglePaymentDataParameters(
    val allowedAuthMethods: List<GooglePaymentDataAuthMethods>,
    val allowedCardNetworks: List<CardType>,
    val billingAddressRequired: Boolean = true,
    val billingAddressParameters: GooglePaymentDataBillingAddressParameters = GooglePaymentDataBillingAddressParameters()
)

@Serializable
internal data class GooglePaymentDataBillingAddressParameters(
    val format: String = "FULL",
)

@Serializable
internal enum class GooglePaymentDataAuthMethods {
    PAN_ONLY, CRYPTOGRAM_3DS;

    override fun toString(): String {
        return name.uppercase()
    }
}