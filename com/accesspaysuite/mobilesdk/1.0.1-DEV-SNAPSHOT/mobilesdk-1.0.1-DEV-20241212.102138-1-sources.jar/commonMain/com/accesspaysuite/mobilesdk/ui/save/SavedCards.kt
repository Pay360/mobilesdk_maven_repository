package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.accesspaysuite.mobilesdk.data.common.CardError
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.data.internal.common.StoredCard
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_holder_name_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_select
import com.accesspaysuite.mobilesdk.sdk.generated.resources.default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expired
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expiry_date_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_no_card
import com.accesspaysuite.mobilesdk.sdk.generated.resources.new_card
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.CardInputField
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.save.SavedCardsInternalState.Companion.NEW_CARD
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import com.accesspaysuite.mobilesdk.utils.expiryDateValid
import io.github.alexzhirkevich.LocalContentColor
import io.github.alexzhirkevich.LocalTextStyle
import io.github.alexzhirkevich.cupertino.LocalContainerColor
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveAlertDialog
import io.github.alexzhirkevich.cupertino.adaptive.ExperimentalAdaptiveApi
import io.github.alexzhirkevich.cupertino.default
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/**
 * # Saved Cards Component
 *
 * Component to display saved cards and allow the user to select one.
 * If the user selects a card, the CV2 field will be displayed.
 *
 * @param modifier The modifier to be applied to the layout.
 * @param state The style state of the component.
 */
@ExperimentalMobileUI
@Composable
fun SavedCards(
    modifier: Modifier = Modifier,
    state: SavedCardsState
) = SavedCards(
    modifier = modifier,
    onCardSelected = state.onCardSelected,
    tryToUseDefaultCard = state.tryToUseDefaultCard
)

/**
 * # Saved Cards Component
 *
 * Component to display saved cards and allow the user to select one.
 * If the user selects a card, the CV2 field will be displayed.
 *
 * @param modifier The modifier to be applied to the layout.
 * @param onCardSelected The callback to be called when a card is selected. (Boolean) -> Unit, true when no saved card is selected.
 * @param tryToUseDefaultCard If true, the default saved card will be selected automatically.
 */
@OptIn(ExperimentalAdaptiveApi::class)
@ExperimentalMobileUI
@Composable
fun SavedCards(
    modifier: Modifier = Modifier,
    tryToUseDefaultCard: Boolean = false,
    onCardSelected: (isNewCard: Boolean) -> Unit = {},
) {
    val paymentProcessor = PaymentProcessorFactory.currentProcessor
    val internalState = rememberSavedCardsInternalState()

    LaunchedEffect(paymentProcessor) {
        internalState.isVisible = paymentProcessor?.isAllowedToSaveCard() == true

        paymentProcessor?.getSavedMethods {
            internalState.updateCardTokens(it)
            if (tryToUseDefaultCard && it.isNotEmpty()) {
                // The first token received by the SDK is the default/primary card selected by the customer
                internalState.selectedOption = 0
            }
        }
    }

    val currentCard by remember(internalState.selectedOption, internalState.cardTokens) {
        derivedStateOf {
            if (internalState.selectedOption == NEW_CARD) null
            else internalState.cardTokens.getOrNull(internalState.selectedOption)
        }
    }

    val cardIcon = remember(currentCard) {
        currentCard?.let {
            CardType.valueOf(it.scheme).getCardIcon()
        } ?: Res.drawable.ic_no_card
    }
    val newCardString = stringResource(Res.string.new_card)
    val cardTitle = remember(currentCard) {
        currentCard?.let {
            "**** ${it.lastFour}"
        } ?: newCardString
    }
    val cardType = remember(currentCard) {
        currentCard?.let {
            CardType.valueOf(it.scheme)
        } ?: CardType.NONE
    }

    var cvvNumber by rememberSaveable {
        mutableStateOf("")
    }
    LaunchedEffect(cvvNumber) {
        if (cvvNumber.length == cardType.length && currentCard != null) {
            paymentProcessor?.updateCard(currentCard!!.toCard(cvvNumber), emptyArray())
        }
    }
    LaunchedEffect(internalState.selectedOption) {
        cvvNumber = ""
        onCardSelected(internalState.selectedOption == NEW_CARD)
    }

    PaymentUITheme {
        AnimatedVisibility(
            visible = internalState.isVisible,
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            Row(
                modifier = Modifier
                    .clickable {
                        internalState.showCardSelection = !internalState.showCardSelection
                    }
                    .then(modifier),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Image(
                        painter = painterResource(cardIcon),
                        contentDescription = cardTitle,
                        modifier = Modifier.height(24.dp)
                    )
                    Text(
                        text = cardTitle,
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                AnimatedVisibility(
                    visible = internalState.selectedOption != NEW_CARD,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        VerticalDivider(Modifier.height(24.dp))

                        CardInputField(
                            inputType = CardInputType.CVV,
                            cardType = cardType,
                            text = cvvNumber,
                            onValueChange = {
                                cvvNumber = it
                            },
                            textStyle = LocalTextStyle.current.copy(color = LocalContentColor.current),
                            onError = {
                                paymentProcessor?.updateCard(null, arrayOf(CardError.Cvv(it)))
                            }
                        )
                    }
                }
            }

            if (internalState.showCardSelection) {
                AdaptiveAlertDialog(
                    onDismissRequest = {
                        internalState.showCardSelection = false
                    },
                    title = {
                        Text(text = stringResource(Res.string.card_select))
                    },
                    message = {
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item {
                                Spacer(Modifier.height(16.dp))
                            }
                            item {
                                SavedCardSelect(
                                    title = newCardString,
                                    icon = painterResource(Res.drawable.ic_no_card),
                                    onClick = {
                                        internalState.selectedOption = NEW_CARD
                                        internalState.showCardSelection = false
                                    }
                                )
                            }
                            itemsIndexed(
                                items = internalState.cardTokens,
                                key = { _, it -> it.token }
                            ) { index, card ->
                                val defaultString = stringResource(Res.string.default)
                                // The first token received by the SDK is the default/primary card selected by the customer
                                // This is not the case for the direct AP API, only for the Mobile API
                                val title = remember(card, index) {
                                    "**** ${card.lastFour}" + if (index == 0) " ($defaultString)" else ""
                                }
                                val icon = remember(card) {
                                    CardType.valueOf(card.scheme).getCardIcon()
                                }
                                val textStyle = MaterialTheme.typography.bodyMedium
                                val cardholderNameString = stringResource(Res.string.card_holder_name_default)
                                val expiryDateString = stringResource(Res.string.expiry_date_default)
                                val expiredString = stringResource(Res.string.expired)
                                val isExpired = remember(card) {
                                    !expiryDateValid(card.expiryDate)
                                }
                                val summary = remember(card) {
                                    buildAnnotatedString {
                                        append("$cardholderNameString: ")
                                        withStyle(
                                            style = textStyle.copy(
                                                fontWeight = FontWeight.Bold
                                            ).toSpanStyle()
                                        ) {
                                            appendLine(card.cardHolderName)
                                        }
                                        if (!isExpired) {
                                            append("$expiryDateString: ")
                                        }
                                        withStyle(
                                            style = textStyle.copy(
                                                fontWeight = FontWeight.Bold
                                            ).toSpanStyle()
                                        ) {
                                            if (!isExpired) {
                                                append(card.expiryDate.take(2))
                                                append("/")
                                                append(card.expiryDate.takeLast(2))
                                            } else {
                                                append(expiredString)
                                            }
                                        }
                                    }
                                }

                                SavedCardSelect(
                                    title = title,
                                    summary = summary,
                                    icon = painterResource(icon),
                                    onClick = {
                                        internalState.selectedOption = index
                                        internalState.showCardSelection = false
                                    },
                                    enabled = expiryDateValid(card.expiryDate)
                                )
                            }
                        }
                    },
                    buttons = {
                        default(
                            onClick = {
                                internalState.showCardSelection = false
                            },
                            title = {
                                Text(text = "Ok")
                            }
                        )
                    }
                )
            }
        }
    }
}

@Composable
private fun SavedCardSelect(
    modifier: Modifier = Modifier,
    title: String,
    summary: AnnotatedString? = null,
    icon: Painter,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    val alpha by animateFloatAsState(
        targetValue = if (enabled) 1f else 0.5f,
        label = "alpha"
    )
    ListItem(
        colors = ListItemDefaults.colors(
            containerColor = LocalContainerColor.current
        ),
        modifier = modifier.fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.scrim.copy(alpha = 0.1f),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(
                enabled = enabled,
                onClick = onClick
            )
            .alpha(alpha),
        leadingContent = {
            Image(
                painter = icon,
                contentDescription = title,
                modifier = Modifier.height(24.dp)
            )
        },
        headlineContent = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Start
            )
        },
        supportingContent = if (summary != null) {
            {
                Text(
                    text = summary,
                    textAlign = TextAlign.Start
                )
            }
        } else null
    )
}

@ExperimentalMobileUI
@Composable
internal fun rememberSavedCardsInternalState(): SavedCardsInternalState {
    return remember { SavedCardsInternalState() }
}

internal class SavedCardsInternalState {
    var isVisible by mutableStateOf(false)
    val cardTokens = mutableStateListOf<StoredCard>()
    var selectedOption by mutableIntStateOf(-1)
    var showCardSelection by mutableStateOf(false)


    fun updateCardTokens(newCardTokens: List<StoredCard>) {
        cardTokens.clear()
        cardTokens.addAll(newCardTokens)
    }

    companion object {
        const val NEW_CARD = -1
    }
}


