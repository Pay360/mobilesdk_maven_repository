package com.accesspaysuite.mobilesdk.callbacks.internal

/**
 * Google pay result callback
 *
 * @constructor Create empty Google pay result callback
 */
internal interface GooglePayResultCallback {

    /**
     * On google pay success
     *
     * @param data
     */
    fun onGooglePaySuccess(data: Any)

    /**
     * On google pay failed
     *
     * @param errorCode
     * @param reason
     */
    fun onGooglePayFailed(errorCode: Int, reason: String)

    /**
     * On google pay canceled
     *
     */
    fun onGooglePayCanceled()

}