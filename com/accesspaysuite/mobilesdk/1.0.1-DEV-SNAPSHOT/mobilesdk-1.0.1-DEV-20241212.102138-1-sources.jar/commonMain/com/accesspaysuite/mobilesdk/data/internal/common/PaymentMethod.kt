package com.accesspaysuite.mobilesdk.data.internal.common

import com.accesspaysuite.mobilesdk.data.internal.applepay.ApplePayPayment
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePayPayment
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking
import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentMethod(
    val cardToken: Card? = null,
    val googlepay: GooglePayPayment? = null,
    val applepay: ApplePayPayment? = null,
    val openBanking: OpenBanking? = null,
    val card: Card? = null
)