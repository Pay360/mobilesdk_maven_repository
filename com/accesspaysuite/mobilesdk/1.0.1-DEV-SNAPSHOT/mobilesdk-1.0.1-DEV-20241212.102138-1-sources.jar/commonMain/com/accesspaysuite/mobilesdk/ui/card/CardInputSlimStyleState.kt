package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight

/**
 * # Slim Card Input Style State.
 *
 * Android View System
 * ```kotlin
 * processor.initiate { nonNullProcessor ->
 *     val styleState = CardInputSlimStyleState(
 *         showCardHolderName = true
 *     )
 *     cardInputSlimView.init(styleState)
 * }
 * ```
 * Jetpack Compose
 * ```kotlin
 * val styleState = rememberCardInputSlimStyleState(
 *     showCardHolderName = true
 * )
 * CardInputSlim(state = styleState)
 * ```
 * Swift
 * ```swift
 * @State private var cardState: CardInputSlimStyleState = CardInputSlimStyleState()
 *
 * }
 * ```
 * ```swift
 * CardInputSlim(state: $cardState)
 * ```
 * @param textSize The size of the text in the card input. Default value is 16.0.
 * @param textFontWeight The font weight of the text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param showCardHolderName A boolean indicating whether the cardholder's name should be shown. Default value is false.
 * If this is set to true, then the cardHolderName must not be empty.
 * @param cardHolderName The name of the card holder. Default value is an empty string.
 */
@Stable
data class CardInputSlimStyleState(
    val textSize: Number = 16.0,
    val textFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    val showCardHolderName: Boolean = true,
    val cardHolderName: String = ""
) {
    constructor() : this(
        textSize = 14.0,
        textFontWeight = ComponentFontWeight.NORMAL,
        showCardHolderName = true,
        cardHolderName = ""
    )

}

/**
 * Remember card input slim style state
 *
 * @param key
 * @param textSize
 * @param textFontWeight
 * @param showCardHolderName
 * @param cardHolderName
 */
@Composable
fun rememberCardInputSlimStyleState(
    key: Any = Unit,
    textSize: TextUnit = 16.sp,
    textFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = false,
    cardHolderName: String = ""
) = remember(key) {
    CardInputSlimStyleState(
        textSize.value,
        textFontWeight,
        showCardHolderName,
        cardHolderName
    )
}

/**
 * Remember card input slim style state
 *
 * @param keys
 * @param textSize
 * @param textFontWeight
 * @param showCardHolderName
 * @param cardHolderName
 */
@Composable
fun rememberCardInputSlimStyleState(
    vararg keys: Any = arrayOf(Unit),
    textSize: TextUnit = 16.sp,
    textFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = false,
    cardHolderName: String = ""
) = remember(keys) {
    CardInputSlimStyleState(
        textSize.value,
        textFontWeight,
        showCardHolderName,
        cardHolderName
    )
}