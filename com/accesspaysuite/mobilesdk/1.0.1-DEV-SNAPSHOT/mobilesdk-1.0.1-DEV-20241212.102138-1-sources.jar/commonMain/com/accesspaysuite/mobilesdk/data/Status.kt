package com.accesspaysuite.mobilesdk.data

import kotlinx.serialization.Serializable

/**
 * # Payment Status
 *
 * Represents the status of a payment operation.
 */
@Serializable
sealed class Status {

    /**
     * # Success
     * Indicates that the payment operation was successful.
     */
    @Serializable
    data object Success : Status()

    /**
     * # Error
     * Indicates that an error occurred during the payment operation.
     * Contains a message with details about the error.
     */
    @Serializable
    data class Error(val message: String) : Status()

    /**
     * # Canceled
     * Indicates that the payment operation was canceled.
     * This status is typically used when the user cancels the payment operation
     * for a specific payment method.
     */
    @Serializable
    data object Canceled : Status()

    /**
     * # Initiated
     * Indicates that the payment processor was initiated.
     */
    @Serializable
    data object Initiated : Status()

    /**
     * # SessionExpired
     * Indicates that the payment session has expired.
     * This status is typically used when the payment session has expired and
     * a new authentication is required.
     */
    @Serializable
    data object SessionExpired : Status()

    /**
     * # Unknown
     * Indicates that the status of the payment operation is unknown.
     * This status is typically used when the payment operation has an unexpected status.
     */
    @Serializable
    data object Unknown : Status()
}