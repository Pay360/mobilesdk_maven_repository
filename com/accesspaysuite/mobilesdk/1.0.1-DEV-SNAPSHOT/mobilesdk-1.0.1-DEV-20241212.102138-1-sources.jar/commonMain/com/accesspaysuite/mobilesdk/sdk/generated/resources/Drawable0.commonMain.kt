@file:OptIn(org.jetbrains.compose.resources.InternalResourceApi::class)

package com.accesspaysuite.mobilesdk.sdk.generated.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi

private object CommonMainDrawable0 {
  public val ic_americanexpress: DrawableResource by 
      lazy { init_ic_americanexpress() }

  public val ic_delete: DrawableResource by 
      lazy { init_ic_delete() }

  public val ic_dinnerclub: DrawableResource by 
      lazy { init_ic_dinnerclub() }

  public val ic_discover: DrawableResource by 
      lazy { init_ic_discover() }

  public val ic_gpay: DrawableResource by 
      lazy { init_ic_gpay() }

  public val ic_gpay_chip: DrawableResource by 
      lazy { init_ic_gpay_chip() }

  public val ic_jcb: DrawableResource by 
      lazy { init_ic_jcb() }

  public val ic_maestro: DrawableResource by 
      lazy { init_ic_maestro() }

  public val ic_mastercard: DrawableResource by 
      lazy { init_ic_mastercard() }

  public val ic_mite: DrawableResource by 
      lazy { init_ic_mite() }

  public val ic_no_card: DrawableResource by 
      lazy { init_ic_no_card() }

  public val ic_unkown_credit_card: DrawableResource by 
      lazy { init_ic_unkown_credit_card() }

  public val ic_visa: DrawableResource by 
      lazy { init_ic_visa() }

  public val no_underline_edittext_bg: DrawableResource by 
      lazy { init_no_underline_edittext_bg() }

  public val paysuite_logo: DrawableResource by 
      lazy { init_paysuite_logo() }
}

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("ic_americanexpress", CommonMainDrawable0.ic_americanexpress)
  map.put("ic_delete", CommonMainDrawable0.ic_delete)
  map.put("ic_dinnerclub", CommonMainDrawable0.ic_dinnerclub)
  map.put("ic_discover", CommonMainDrawable0.ic_discover)
  map.put("ic_gpay", CommonMainDrawable0.ic_gpay)
  map.put("ic_gpay_chip", CommonMainDrawable0.ic_gpay_chip)
  map.put("ic_jcb", CommonMainDrawable0.ic_jcb)
  map.put("ic_maestro", CommonMainDrawable0.ic_maestro)
  map.put("ic_mastercard", CommonMainDrawable0.ic_mastercard)
  map.put("ic_mite", CommonMainDrawable0.ic_mite)
  map.put("ic_no_card", CommonMainDrawable0.ic_no_card)
  map.put("ic_unkown_credit_card", CommonMainDrawable0.ic_unkown_credit_card)
  map.put("ic_visa", CommonMainDrawable0.ic_visa)
  map.put("no_underline_edittext_bg", CommonMainDrawable0.no_underline_edittext_bg)
  map.put("paysuite_logo", CommonMainDrawable0.paysuite_logo)
}

internal val Res.drawable.ic_americanexpress: DrawableResource
  get() = CommonMainDrawable0.ic_americanexpress

private fun init_ic_americanexpress(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_americanexpress",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_americanexpress.xml", -1, -1),
    )
)

internal val Res.drawable.ic_delete: DrawableResource
  get() = CommonMainDrawable0.ic_delete

private fun init_ic_delete(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_delete",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_delete.xml", -1, -1),
    )
)

internal val Res.drawable.ic_dinnerclub: DrawableResource
  get() = CommonMainDrawable0.ic_dinnerclub

private fun init_ic_dinnerclub(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_dinnerclub",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_dinnerclub.xml", -1, -1),
    )
)

internal val Res.drawable.ic_discover: DrawableResource
  get() = CommonMainDrawable0.ic_discover

private fun init_ic_discover(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_discover",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_discover.xml", -1, -1),
    )
)

internal val Res.drawable.ic_gpay: DrawableResource
  get() = CommonMainDrawable0.ic_gpay

private fun init_ic_gpay(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_gpay",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_gpay.xml", -1, -1),
    )
)

internal val Res.drawable.ic_gpay_chip: DrawableResource
  get() = CommonMainDrawable0.ic_gpay_chip

private fun init_ic_gpay_chip(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_gpay_chip",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_gpay_chip.xml", -1, -1),
    )
)

internal val Res.drawable.ic_jcb: DrawableResource
  get() = CommonMainDrawable0.ic_jcb

private fun init_ic_jcb(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_jcb",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_jcb.xml", -1, -1),
    )
)

internal val Res.drawable.ic_maestro: DrawableResource
  get() = CommonMainDrawable0.ic_maestro

private fun init_ic_maestro(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_maestro",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_maestro.xml", -1, -1),
    )
)

internal val Res.drawable.ic_mastercard: DrawableResource
  get() = CommonMainDrawable0.ic_mastercard

private fun init_ic_mastercard(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_mastercard",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_mastercard.xml", -1, -1),
    )
)

internal val Res.drawable.ic_mite: DrawableResource
  get() = CommonMainDrawable0.ic_mite

private fun init_ic_mite(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_mite",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_mite.xml", -1, -1),
    )
)

internal val Res.drawable.ic_no_card: DrawableResource
  get() = CommonMainDrawable0.ic_no_card

private fun init_ic_no_card(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_no_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_no_card.xml", -1, -1),
    )
)

internal val Res.drawable.ic_unkown_credit_card: DrawableResource
  get() = CommonMainDrawable0.ic_unkown_credit_card

private fun init_ic_unkown_credit_card(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_unkown_credit_card",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_unkown_credit_card.xml", -1, -1),
    )
)

internal val Res.drawable.ic_visa: DrawableResource
  get() = CommonMainDrawable0.ic_visa

private fun init_ic_visa(): DrawableResource = org.jetbrains.compose.resources.DrawableResource(
  "drawable:ic_visa",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/ic_visa.xml", -1, -1),
    )
)

internal val Res.drawable.no_underline_edittext_bg: DrawableResource
  get() = CommonMainDrawable0.no_underline_edittext_bg

private fun init_no_underline_edittext_bg(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:no_underline_edittext_bg",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/no_underline_edittext_bg.xml", -1, -1),
    )
)

internal val Res.drawable.paysuite_logo: DrawableResource
  get() = CommonMainDrawable0.paysuite_logo

private fun init_paysuite_logo(): DrawableResource =
    org.jetbrains.compose.resources.DrawableResource(
  "drawable:paysuite_logo",
    setOf(
      org.jetbrains.compose.resources.ResourceItem(setOf(),
    "composeResources/com.accesspaysuite.mobilesdk.sdk.generated.resources/drawable/paysuite_logo.xml", -1, -1),
    )
)
