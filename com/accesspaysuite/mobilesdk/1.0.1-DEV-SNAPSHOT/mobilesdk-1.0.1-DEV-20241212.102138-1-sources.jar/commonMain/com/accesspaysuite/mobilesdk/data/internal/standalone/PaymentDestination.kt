package com.accesspaysuite.mobilesdk.data.internal.standalone

import kotlinx.serialization.Serializable

@Serializable
internal sealed class PaymentDestination {

    @Serializable
    data object Loading : PaymentDestination()

    @Serializable
    data object Form : PaymentDestination()

    @Serializable
    data class Status(
        val status: String = "Unknown",
        val reason: String? = null,
        val currencyCode: String = "",
        val amount: String = ""
    ) : PaymentDestination()

}


@Serializable
internal enum class PaymentStatus {
    Success,
    Error,
    Canceled,
    SessionExpired,
    Unknown
}