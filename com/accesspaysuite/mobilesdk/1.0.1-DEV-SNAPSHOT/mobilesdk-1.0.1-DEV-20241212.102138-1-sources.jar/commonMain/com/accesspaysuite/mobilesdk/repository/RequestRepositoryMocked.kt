package com.accesspaysuite.mobilesdk.repository

import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.common.SaveCardMethods
import com.accesspaysuite.mobilesdk.data.internal.common.StoredCard
import com.accesspaysuite.mobilesdk.data.common.TransactionType
import com.accesspaysuite.mobilesdk.data.internal.googlepay.GooglePaymentDataAuthMethods
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.data.internal.initiate.GooglePayTokenizationSpecification
import com.accesspaysuite.mobilesdk.data.internal.initiate.GooglePayTransaction
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateApplePay
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateCard
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateGooglePay
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateOutcome
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateResponse
import com.accesspaysuite.mobilesdk.data.internal.initiate.MerchantInfo
import com.accesspaysuite.mobilesdk.data.internal.initiate.OutcomeStatus
import com.accesspaysuite.mobilesdk.data.internal.initiate.Parameters
import kotlinx.coroutines.launch

/**
 * Mocked implementation of [RequestRepository].
 */
internal class RequestRepositoryMocked : RequestRepositoryBase() {

    override fun initiatePayment(
        environment: Environment,
        installationId: String,
        clientToken: String,
        transactionType: TransactionType,
        currencyCode: String,
        countryCode: String?,
        onSuccess: (InitiateResponse) -> Unit,
        onFailure: (Status) -> Unit
    ) {
        scope.launch {
            val response = InitiateResponse(
                acceptPaymentMethods = listOf(
                    AcceptPaymentMethods.APPLEPAY,
                    AcceptPaymentMethods.GOOGLEPAY,
                    AcceptPaymentMethods.CARD,
                    AcceptPaymentMethods.OPENBANKING
                ),
                card = InitiateCard(
                    acceptSchemes = listOf(
                        CardType.VISA,
                        CardType.MASTERCARD
                    ),
                    saveMethod = SaveCardMethods.ASK,
                    storedCards = listOf(
                        StoredCard(
                            scheme = "VISA",
                            expiryDate = "1125",
                            lastFour = "0041",
                            token = "storedCardToken",
                            cardHolderName = "John Doe"
                        )
                    )
                ),
                applePay = InitiateApplePay(
                    supportedNetworks = listOf(
                        CardType.VISA,
                        CardType.MASTERCARD
                    ),
                    currencyCode = "GBP",
                    merchantCountryCode = "GB"
                ),
                googlePay = InitiateGooglePay(
                    environment = Environment.TEST,
                    allowedCardNetworks = listOf(
                        CardType.VISA,
                        CardType.MASTERCARD
                    ),
                    allowedCardAuthMethods = listOf(
                        GooglePaymentDataAuthMethods.CRYPTOGRAM_3DS,
                        GooglePaymentDataAuthMethods.PAN_ONLY
                    ),
                    merchantInfo = MerchantInfo(
                        merchantName = "Example Merchant",
                        merchantId = "0123456789"
                    ),
                    tokenizationSpecification = GooglePayTokenizationSpecification(
                        type = "PAYMENT_GATEWAY",
                        parameters = Parameters(
                            gateway = "pay360",
                            gatewayMerchantId = "AP:$installationId"
                        )
                    ),
                    transaction = GooglePayTransaction(
                        currencyCode = "GBP",
                        totalPriceStatus = "FINAL",
                        countryCode = "GB"
                    )
                ),
                outcome = InitiateOutcome(
                    status = OutcomeStatus.SUCCESS,
                    reasonCode = "0",
                    reasonMessage = "Initiated"
                ),
                trace = "XL4DN1mHCgTCf0s2AiUo7VU"
            )
            onSuccess(response)
        }
    }

}