package com.accesspaysuite.mobilesdk.callbacks

import com.accesspaysuite.mobilesdk.data.common.CardError

/**
 * # Card Callback
 * Callback for card submission
 *
 * [onCardSubmittedSuccessfully] is called when the card is submitted successfully and is valid (passes all validations)
 * [onCardSubmittedWithErrors] is called when the card is submitted with errors
 *
 * @constructor Create empty Card callback
 */
interface CardCallback {

    /**
     * # On card submitted successfully
     * Called when the card is submitted successfully and is valid (passes all validations)
     */
    fun onCardSubmittedSuccessfully()

    /**
     * # On card submitted with errors
     * Called when the card is submitted with errors
     *
     *
     * @param errors
     */
    fun onCardSubmittedWithErrors(errors: Array<CardError>)

}
