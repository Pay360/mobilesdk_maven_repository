@file:Suppress("NAME_SHADOWING")

package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_number
import com.accesspaysuite.mobilesdk.sdk.generated.resources.cardholder_name
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expiration_date
import com.accesspaysuite.mobilesdk.sdk.generated.resources.security_code
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import com.accesspaysuite.mobilesdk.ui.components.CardInputField
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType
import com.accesspaysuite.mobilesdk.ui.utils.CardSubmitter
import com.accesspaysuite.mobilesdk.ui.utils.CardUtils
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import com.accesspaysuite.mobilesdk.utils.hasPaymentMethod
import io.github.aakira.napier.Napier
import io.github.alexzhirkevich.LocalContentColor
import io.github.alexzhirkevich.LocalTextStyle
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

/**
 * # Card Input Component
 * ## Three fields for card input: PAN, Expiry Date, CVV
 *
 * The CardInput component is used to collect card information from the user.
 * It consists of three fields: PAN, Expiry Date, and CVV.
 * The component also includes a field for the cardholder's name.
 *
 * @param state The style state of the card input
 * @param modifier Modifier
 */
@ExperimentalMobileUI
@Composable
fun CardInput(
    state: CardInputStyleState,
    modifier: Modifier = Modifier
) = CardInput(
    backgroundRadius = state.backgroundCornerSize.dp,
    labelLocation = state.labelLocation,
    labelTextSize = state.labelTextSize.sp,
    labelTextFontWeight = state.labelTextFontWeight,
    fieldTextSize = state.fieldTextSize.sp,
    fieldTextFontWeight = state.fieldTextFontWeight,
    showCardHolderName = state.showCardHolderName,
    modifier = modifier
)

/**
 * # Card Input Component
 * ## Three fields for card input: PAN, Expiry Date, CVV
 *
 * The CardInput component is used to collect card information from the user.
 * It consists of three fields: PAN, Expiry Date, and CVV.
 * The component also includes a field for the cardholder's name.
 *
 * @param backgroundRadius The radius of the background in the card input. Default value is 0.dp.
 * @param labelLocation The location of the label in the card input. Default value is LabelLocation.TOP.
 * @param labelTextSize The size of the label text in the card input. Default value is 14.sp.
 * @param labelTextFontWeight The font weight of the label text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param labelComponent The component to display the label in the card input. Default value is a Text component.
 * @param fieldTextSize The size of the field text in the card input. Default value is 14.sp.
 * @param fieldTextFontWeight The font weight of the field text in the card input. Default value is ComponentFontWeight.NORMAL.
 * @param showCardHolderName If true, the cardholder's name field will be shown. Default is true.
 * @param modifier Modifier
 */
@ExperimentalMobileUI
@Composable
fun CardInput(
    backgroundRadius: Dp = 0.dp,
    labelLocation: LabelLocation = LabelLocation.TOP,
    labelTextSize: TextUnit = 14.sp,
    labelTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    labelComponent: @Composable (label: String, labelTextStyle: TextStyle) -> Unit = { label, labelTextStyle ->
        Text(
            text = label,
            style = labelTextStyle,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    },
    fieldTextSize: TextUnit = 14.sp,
    fieldTextFontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    showCardHolderName: Boolean = true,
    cardHolderName: String = "",
    isOutlined: Boolean = true,
    modifier: Modifier = Modifier
) {
    var cardType by remember { mutableStateOf(CardType.NONE) }
    var panInput by rememberSaveable { mutableStateOf("") }
    var panInputError by rememberSaveable { mutableStateOf("") }

    var expiryDateInput by rememberSaveable { mutableStateOf("") }
    var expiryDateInputError by rememberSaveable { mutableStateOf("") }

    var cvvInput by rememberSaveable { mutableStateOf("") }
    var cvvInputError by rememberSaveable { mutableStateOf("") }

    var cardHolderNameInput by rememberSaveable(showCardHolderName) {
        mutableStateOf(if (showCardHolderName) "" else cardHolderName)
    }
    var cardHolderNameInputError by rememberSaveable { mutableStateOf("") }

    val methodAvailable by PaymentProcessorFactory.hasPaymentMethod(AcceptPaymentMethods.CARD)
    val processor = PaymentProcessorFactory.currentProcessor
    val isUsingSavedCard = remember(processor) { processor?.isUsingSavedCard == true }

    LaunchedEffect(showCardHolderName, cardHolderName) {
        if (showCardHolderName) {
            if (cardHolderNameInput.isNotEmpty()) {
                Napier.w {
                    "Pre-filled card holder name will be ignored because showCardHolderName is true"
                }
            }
        } else {
            require(cardHolderName.isNotEmpty()) {
                "Card holder name shouldn't be empty when showCardHolderName is false"
            }
        }
    }

    AnimatedVisibility(
        visible = methodAvailable && !isUsingSavedCard,
        enter = enterAnimation,
        exit = exitAnimation
    ) {
        PaymentUITheme {

            val onSurface = LocalContentColor.current
            val fieldTextStyle = remember(fieldTextSize, fieldTextFontWeight, onSurface) {
                TextStyle(
                    fontSize = fieldTextSize,
                    fontWeight = fieldTextFontWeight.value,
                    lineHeight = (fieldTextSize.value + 2.0).sp,
                    color = onSurface
                )
            }
            val labelTextStyle = remember(labelTextSize, labelTextFontWeight, onSurface) {
                TextStyle(
                    fontSize = labelTextSize,
                    fontWeight = labelTextFontWeight.value,
                    color = onSurface
                )
            }
            val shape = remember(backgroundRadius) { RoundedCornerShape(backgroundRadius) }

            LaunchedEffect(panInput) {
                if (panInput.length < 2) {
                    cardType = CardType.NONE
                    return@LaunchedEffect
                }
                if (processor == null) {
                    cardType = CardType.NONE
                    return@LaunchedEffect
                }
                cardType = CardUtils.guessCardNumberType(processor.environment, panInput)
            }

            ProvideTextStyle(fieldTextStyle) {
                CardSubmitter(
                    cardType = cardType,
                    panInput = panInput,
                    expiryDateInput = expiryDateInput,
                    cvvInput = cvvInput,
                    cardHolderName = cardHolderNameInput,
                    cardHolderNameError = cardHolderNameInputError,
                    panInputError = panInputError,
                    expiryDateInputError = expiryDateInputError,
                    cvvInputError = cvvInputError
                )

                Column(
                    modifier = modifier.fillMaxWidth()
                ) {
                    Spacer(modifier = Modifier.height(16.dp))

                    CardInputFieldWithLabel(
                        text = panInput,
                        errorText = panInputError,
                        cardType = cardType,
                        inputType = CardInputType.PAN,
                        label = stringResource(Res.string.card_number),
                        labelLocation = labelLocation,
                        labelTextStyle = labelTextStyle,
                        labelComponent = labelComponent,
                        isOutlined = isOutlined,
                        shape = shape,
                        onValueChange = { panInput = it },
                        onError = { panInputError = it },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CardInputFieldWithLabel(
                            text = expiryDateInput,
                            errorText = expiryDateInputError,
                            cardType = cardType,
                            inputType = CardInputType.EXPIRY,
                            label = stringResource(Res.string.expiration_date),
                            labelLocation = labelLocation,
                            labelTextStyle = labelTextStyle,
                            labelComponent = labelComponent,
                            isOutlined = isOutlined,
                            shape = shape,
                            onValueChange = { expiryDateInput = it },
                            onError = { expiryDateInputError = it },
                            modifier = Modifier.weight(1f)
                        )
                        CardInputFieldWithLabel(
                            text = cvvInput,
                            errorText = cvvInputError,
                            cardType = cardType,
                            inputType = CardInputType.CVV,
                            label = stringResource(Res.string.security_code),
                            labelLocation = labelLocation,
                            labelTextStyle = labelTextStyle,
                            labelComponent = labelComponent,
                            isOutlined = isOutlined,
                            shape = shape,
                            onValueChange = { cvvInput = it },
                            onError = { cvvInputError = it },
                            modifier = Modifier.weight(1f),
                            imeAction = if (showCardHolderName) ImeAction.Next else ImeAction.Done
                        )
                    }

                    if (showCardHolderName) {
                        CardInputFieldWithLabel(
                            text = cardHolderNameInput,
                            errorText = cardHolderNameInputError,
                            cardType = cardType,
                            inputType = CardInputType.NAME,
                            label = stringResource(Res.string.cardholder_name),
                            labelLocation = labelLocation,
                            labelTextStyle = labelTextStyle,
                            labelComponent = labelComponent,
                            isOutlined = isOutlined,
                            shape = shape,
                            onValueChange = { cardHolderNameInput = it },
                            onError = { cardHolderNameInputError = it },
                            imeAction = ImeAction.Done,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CardInputFieldWithLabel(
    text: String,
    errorText: String,
    cardType: CardType,
    inputType: CardInputType,
    label: String,
    labelLocation: LabelLocation,
    labelTextStyle: TextStyle,
    labelComponent: @Composable (label: String, labelTextStyle: TextStyle) -> Unit = { label, labelTextStyle ->
        Text(
            text = label,
            style = labelTextStyle,
            modifier = Modifier.padding(vertical = 8.dp)
        )
    },
    isOutlined: Boolean = true,
    shape: Shape,
    onValueChange: (String) -> Unit,
    onError: (String) -> Unit,
    imeAction: ImeAction = ImeAction.Next,
    modifier: Modifier = Modifier,
) {
    var currentLabel = remember(label) { label }
    Column(
        modifier = modifier
    ) {
        AnimatedVisibility(
            visible = labelLocation == LabelLocation.TOP,
        ) {
            labelComponent(label, labelTextStyle)
            LaunchedEffect(labelLocation) {
                currentLabel = ""
            }
        }

        CardInputField(
            modifier = Modifier.fillMaxWidth(),
            inputType = inputType,
            cardType = cardType,
            text = text,
            shape = shape,
            onValueChange = onValueChange,
            textStyle = LocalTextStyle.current,
            onError = onError,
            imeAction = imeAction,
            isOutlined = isOutlined,
            label = if (labelLocation == LabelLocation.CONTAINED) {
                {
                    Text(
                        text = currentLabel,
                        style = labelTextStyle
                    )
                }
            } else null,
            trailingIcon = if (inputType == CardInputType.PAN) {
                {
                    androidx.compose.animation.AnimatedVisibility(
                        visible = cardType != CardType.NONE,
                        enter = enterAnimation,
                        exit = exitAnimation
                    ) {
                        Image(
                            painter = painterResource(cardType.getCardIcon()),
                            contentDescription = cardType.name,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }
            } else null
        )

        Text(
            text = errorText,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )
    }
}