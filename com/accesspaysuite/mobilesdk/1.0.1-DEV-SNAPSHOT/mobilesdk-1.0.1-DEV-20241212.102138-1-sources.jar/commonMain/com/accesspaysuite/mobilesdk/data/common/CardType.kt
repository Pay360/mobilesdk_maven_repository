package com.accesspaysuite.mobilesdk.data.common

import androidx.compose.runtime.Stable
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_americanexpress
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_jcb
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_mastercard
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_mite
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_no_card
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_visa
import kotlinx.serialization.Serializable
import org.jetbrains.compose.resources.DrawableResource

@Serializable
@Stable
internal enum class CardType {
    AMEX, JCB, MASTERCARD, VISA, MITE, NONE;

    val length: Int
        get() = when (this) {
            AMEX -> 4
            NONE -> 0
            else -> 3
        }

    override fun toString(): String {
        return name.uppercase()
    }
}

internal fun CardType?.getCardIcon(): DrawableResource {
    return when (this) {
        CardType.VISA -> Res.drawable.ic_visa
        CardType.MASTERCARD -> Res.drawable.ic_mastercard
        CardType.AMEX -> Res.drawable.ic_americanexpress
        CardType.JCB -> Res.drawable.ic_jcb
        CardType.MITE -> Res.drawable.ic_mite
        else -> Res.drawable.ic_no_card
    }
}