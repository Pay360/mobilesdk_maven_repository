package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseTransaction(
    val amount: Double? = null,
    val currency: String? = null,
    val merchantRef: String? = null,
    val transactionId: String? = null,
    val transactionTime: String? = null,
    val type: String? = null
)