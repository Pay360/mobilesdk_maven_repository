package com.accesspaysuite.mobilesdk.ui.standalone

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisallowComposableCalls
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.standalone.PaymentDestination
import com.accesspaysuite.mobilesdk.data.internal.standalone.PaymentState
import com.accesspaysuite.mobilesdk.data.internal.standalone.PaymentStatus
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.cancel
import com.accesspaysuite.mobilesdk.sdk.generated.resources.checkout
import com.accesspaysuite.mobilesdk.sdk.generated.resources.pay
import com.accesspaysuite.mobilesdk.sdk.generated.resources.payment_canceled
import com.accesspaysuite.mobilesdk.sdk.generated.resources.waiting
import com.accesspaysuite.mobilesdk.ui.components.Constants.navigateInAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.navigateUpAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.connectivityState
import com.accesspaysuite.mobilesdk.utils.PaymentProcessorFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.jetbrains.compose.resources.stringResource
import kotlin.time.Duration.Companion.seconds

@Composable
internal inline fun rememberPaymentResultCallback(
    scope: CoroutineScope = rememberCoroutineScope { Dispatchers.Main.immediate },
    crossinline onPaymentSuccess: @DisallowComposableCalls suspend () -> Unit,
    crossinline onPaymentFailed: @DisallowComposableCalls suspend (reason: String?) -> Unit,
    crossinline onPaymentCanceled: @DisallowComposableCalls suspend () -> Unit
): PaymentResultCallback {
    return remember {
        object : PaymentResultCallback {
            override fun onPaymentResult(status: Status) {
                scope.launch {
                    when (status) {
                        Status.Success -> onPaymentSuccess()
                        is Status.Error -> onPaymentFailed(status.message)
                        Status.Canceled -> onPaymentCanceled()
                        else -> Unit
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
@Composable
internal fun PaymentPageContent(
    billingAddress: MutableState<BillingAddress?>,
    origBillingAddress: MutableState<BillingAddress?>,
    merchantName: String?,
    onPaymentSuccess: () -> Unit,
    onPaymentFailed: (reason: String?) -> Unit,
    onPaymentCanceled: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var isLoading by rememberSaveable { mutableStateOf(true) }
    val connectionState by connectivityState()
    val processor = PaymentProcessorFactory.currentProcessor

    val navController = rememberNavController()

    if (isLoading) {
        LaunchedEffect(processor, processor?.initiated) {
            scope.launch {
                while (isLoading) {
                    isLoading =
                        processor == null || !processor.initiated || !connectionState.isConnected
                    delay(100)
                    if (!isLoading) {
                        navController.navigate(PaymentDestination.Form)
                    }
                }
            }
        }
    }
    val paymentState by remember {
        mutableStateOf(
            PaymentState(
                paymentType = PaymentType.GuestPayment
            )
        )
    }

    val paymentCallback = rememberPaymentResultCallback(
        onPaymentSuccess = {
            val transaction = processor?.config?.transaction
            navController.navigate(
                PaymentDestination.Status(
                    status = PaymentStatus.Success.name,
                    currencyCode = transaction?.currency ?: "",
                    amount = (transaction?.amount ?: 0.0).toString()
                )
            )
            delay(2.seconds)
            onPaymentSuccess()
        },
        onPaymentFailed = {
            navController.navigate(
                PaymentDestination.Status(
                    status = PaymentStatus.Error.name,
                    reason = it
                )
            )
            delay(2.seconds)
            onPaymentFailed(it)
        },
        onPaymentCanceled = {
            navController.navigate(PaymentDestination.Form)
            onPaymentCanceled()
        }
    )

    var canClick by rememberSaveable {
        mutableStateOf(false)
    }

    LaunchedEffect(processor) {
        processor?.setPaymentResultCallback(paymentCallback)
        processor?.setCardCallback(
            onCardSubmittedSuccessfully = {
                canClick = true
            },
            onCardSubmittedWithErrors = { errors ->
                canClick = false
                /*          errors.forError(
                              onCardNumberError = {

                              },
                              onExpiryDateError = {

                              },
                              onCvvError = {

                              },
                              onCardholderError = {

                              }
                          )*/
            }
        )
    }

    val currentDestination by navController.currentBackStackEntryAsState()
    val showBottomBar by remember {
        derivedStateOf {
            currentDestination?.destination?.hasRoute<PaymentDestination.Status>() == false
        }
    }

    PaymentUITheme {
        Scaffold(
            topBar = {
                PaymentToolbar(
                    onGoBack = onPaymentCanceled,
                    canGoBack = (currentDestination?.destination?.hasRoute<PaymentDestination.Form>() == true ||
                            currentDestination?.destination?.hasRoute<PaymentDestination.Loading>() == true) &&
                            connectionState.isConnected,
                    text = if (currentDestination?.destination?.hasRoute<PaymentDestination.Form>() == true) {
                        stringResource(Res.string.checkout)
                    } else {
                        stringResource(Res.string.waiting)
                    }
                )
            },
            bottomBar = {
                val cancelString = stringResource(Res.string.cancel)
                val payString = stringResource(Res.string.pay)

                val title by remember(currentDestination) {
                    derivedStateOf {
                        if (currentDestination?.destination?.hasRoute<PaymentDestination.Form>() == true) {
                            if (isLoading) cancelString else payString
                        } else if (currentDestination?.destination?.hasRoute<PaymentDestination.Loading>() == true) {
                            cancelString
                        } else {
                            ""
                        }
                    }
                }

                PaymentBottomBar(
                    title = title,
                    showBottomBar = showBottomBar,
                    paymentType = paymentState.paymentType,
                    canClick = canClick,
                    onClick = {
                        if (currentDestination?.destination?.hasRoute<PaymentDestination.Form>() == true) {
                            requireNotNull(billingAddress.value) { "Billing Address is not set" }
                            navController.navigate(PaymentDestination.Loading)
                            processor?.processCardPayment(billingAddress.value!!)
                        } else if (currentDestination?.destination?.hasRoute<PaymentDestination.Loading>() == true) {
                            navController.navigate(
                                PaymentDestination.Status(
                                    status = PaymentStatus.Canceled.name,
                                )
                            )
                            onPaymentCanceled()
                        }
                    }
                )
            }
        ) {
            NavHost(
                modifier = Modifier.padding(it).fillMaxSize(),
                navController = navController,
                startDestination = PaymentDestination.Loading,
                enterTransition = { navigateInAnimation },
                exitTransition = { navigateUpAnimation },
                popEnterTransition = { navigateInAnimation },
                popExitTransition = { navigateUpAnimation }
            ) {
                composable<PaymentDestination.Loading> {
                    Box(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(128.dp)
                                .align(Alignment.Center)
                        )
                    }
                }

                composable<PaymentDestination.Form> {
                    PaymentForm(
                        merchantName = merchantName,
                        processor = processor,
                        origBillingAddress = origBillingAddress,
                        billingAddress = billingAddress
                    )
                }

                composable<PaymentDestination.Status> { backStack ->
                    val params = backStack.toRoute<PaymentDestination.Status>()

                    PaymentStatusPage(
                        status = PaymentStatus.valueOf(params.status),
                        currencyCode = params.currencyCode,
                        amount = params.amount.toDoubleOrNull() ?: 0.0,
                        reason = params.reason ?: if (params.status == PaymentStatus.Canceled.name) {
                            stringResource(Res.string.payment_canceled)
                        } else null
                    )
                }
            }
        }
    }
}

