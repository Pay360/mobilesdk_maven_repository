package com.accesspaysuite.mobilesdk.ui.management

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.data.internal.cardmanager.CustomerMethod
import com.accesspaysuite.mobilesdk.data.internal.management.CardManagementCredentials
import com.accesspaysuite.mobilesdk.data.internal.management.CardManagerState
import com.accesspaysuite.mobilesdk.repository.CardManager
import com.accesspaysuite.mobilesdk.repository.CardManagerRepositoryImpl
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.cancel
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_holder_name_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.delete_card
import com.accesspaysuite.mobilesdk.sdk.generated.resources.delete_card_confirmation
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expired
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expiry_date_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.make_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.no_saved_cards
import com.accesspaysuite.mobilesdk.sdk.generated.resources.proceed
import com.accesspaysuite.mobilesdk.sdk.generated.resources.saved_cards
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.ui.theme.PaymentUITheme
import com.accesspaysuite.mobilesdk.ui.utils.connectivityState
import com.accesspaysuite.mobilesdk.utils.expiryDateValid
import dev.icerock.moko.parcelize.Parcelable
import dev.icerock.moko.parcelize.Parcelize
import io.github.alexzhirkevich.LocalTextStyle
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveAlertDialog
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveCircularProgressIndicator
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveScaffold
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveTopAppBar
import io.github.alexzhirkevich.cupertino.adaptive.ExperimentalAdaptiveApi
import io.github.alexzhirkevich.cupertino.adaptive.icons.AdaptiveIcons
import io.github.alexzhirkevich.cupertino.adaptive.icons.Close
import io.github.alexzhirkevich.cupertino.adaptive.icons.Refresh
import io.github.alexzhirkevich.cupertino.cancel
import io.github.alexzhirkevich.cupertino.default
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.IO
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@OptIn(ExperimentalAdaptiveApi::class, ExperimentalCoroutinesApi::class)
@Composable
internal fun CardManagementScreen(
    credentials: CardManagementCredentials,
    customerReference: String,
    onBackPress: () -> Unit
) {
    val scope = rememberCoroutineScope { Dispatchers.IO }

    val cardManager = remember(credentials) {
        CardManager(
            credentials = credentials,
            customerReference = customerReference
        )
    }

    val state by cardManager.state.collectAsStateWithLifecycle()
    val connectivity by connectivityState()

    LaunchedEffect(connectivity) {
        cardManager.update()
    }

    var showDeleteConfirmation by rememberSaveable { mutableStateOf(false) }
    var cardToDelete by rememberSaveable { mutableStateOf<CustomerMethod?>(null) }

    PaymentUITheme {
        AdaptiveScaffold(
            topBar = {
                AdaptiveTopAppBar(
                    title = {
                        Text(stringResource(Res.string.saved_cards))
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = onBackPress
                        ) {
                            Icon(
                                imageVector = AdaptiveIcons.Outlined.Close,
                                contentDescription = null
                            )
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = {
                                scope.launch {
                                    cardManager.update()
                                }
                            }
                        ) {
                            Icon(
                                imageVector = AdaptiveIcons.Outlined.Refresh,
                                contentDescription = null
                            )
                        }
                    }
                )
            }
        ) { paddingValues ->

            if (showDeleteConfirmation) {
                AdaptiveAlertDialog(
                    onDismissRequest = {
                        showDeleteConfirmation = false
                        cardToDelete = null
                    },
                    title = {
                        Text(stringResource(Res.string.delete_card) + " **** ${cardToDelete?.card?.maskedPan?.takeLast(4)}")
                    },
                    message = {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(stringResource(Res.string.delete_card_confirmation))
                        }
                    },
                    buttons = {
                        default(
                            onClick = {
                                scope.launch {
                                    cardManager.deleteCard(cardToDelete?.card?.cardToken.toString())
                                    showDeleteConfirmation = false
                                    cardToDelete = null
                                }
                            },
                            title = {
                                Text(stringResource(Res.string.proceed))
                            }
                        )
                        cancel(
                            onClick = {
                                showDeleteConfirmation = false
                                cardToDelete = null
                            },
                            title = {
                                Text(stringResource(Res.string.cancel))
                            }
                        )
                    }
                )
            }

            AnimatedVisibility(
                visible = state.isLoading,
                enter = enterAnimation,
                exit = exitAnimation
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    AdaptiveCircularProgressIndicator()
                }
            }

            AnimatedVisibility(
                visible = state.isCustomerValid && state.cards.isNotEmpty() && !state.isLoading,
                enter = enterAnimation,
                exit = exitAnimation
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = paddingValues
                ) {
                    items(
                        items = state.cards,
                        key = { it.card.cardToken }
                    ) { item ->
                        val isPrimary = rememberSaveable(item) { item.isPrimary }
                        val isExpired = rememberSaveable(item) { !expiryDateValid(item.card.expiryDate) }

                        Column(
                            modifier = Modifier
                                .animateItem()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            horizontalAlignment = Alignment.Start
                        ) {
                            val icon = remember(item) {
                                CardType.valueOf(item.card.cardScheme).getCardIcon()
                            }
                            Image(
                                painter = painterResource(icon),
                                contentDescription = item.card.cardScheme,
                                modifier = Modifier.height(32.dp)
                            )
                            val lastFour = rememberSaveable(item) { item.card.maskedPan.takeLast(4) }
                            val defaultString = stringResource(Res.string.default)

                            Text(
                                text = remember(lastFour, isPrimary) {
                                    "**** $lastFour" + if (isPrimary) " ($defaultString)" else ""
                                },
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Medium
                            )
                            val localTextStyle = LocalTextStyle.current
                            val cardHolderName = stringResource(Res.string.card_holder_name_default)
                            val expiryDate = stringResource(Res.string.expiry_date_default)
                            val expired = stringResource(Res.string.expired)
                            Text(
                                text = remember(item) {
                                    buildAnnotatedString {
                                        append("$cardHolderName: ")
                                        withStyle(
                                            style = localTextStyle.copy(
                                                fontWeight = FontWeight.Bold
                                            ).toSpanStyle()
                                        ) {
                                            appendLine(item.card.cardHolderName)
                                        }
                                        if (!isExpired) {
                                            append("$expiryDate: ")
                                        }
                                        withStyle(
                                            style = localTextStyle.copy(
                                                fontWeight = FontWeight.Bold
                                            ).toSpanStyle()
                                        ) {
                                            if (!isExpired) {
                                                append(item.card.expiryDate.take(2))
                                                append("/")
                                                append(item.card.expiryDate.takeLast(2))
                                            } else {
                                                append(expired)
                                            }
                                        }
                                    }
                                }
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CustomButton(
                                    modifier = Modifier.weight(1f),
                                    containerColor = MaterialTheme.colorScheme.tertiary,
                                    contentColor = MaterialTheme.colorScheme.onTertiary,
                                    onClick = {
                                        scope.launch {
                                            cardManager.makeDefault(item.card.cardToken)
                                        }
                                    },
                                    text = stringResource(Res.string.make_default),
                                    enabled = !isPrimary && !isExpired
                                )

                                CustomButton(
                                    modifier = Modifier.weight(1f),
                                    containerColor = MaterialTheme.colorScheme.error,
                                    contentColor = MaterialTheme.colorScheme.onError,
                                    onClick = {
                                        scope.launch {
                                            cardToDelete = item
                                            showDeleteConfirmation = true
                                        }
                                    },
                                    text = stringResource(Res.string.delete_card)
                                )
                            }
                        }
                    }
                }
            }

            AnimatedVisibility(
                visible = (!state.isCustomerValid || state.cards.isEmpty()) && !state.isLoading,
                enter = enterAnimation,
                exit = exitAnimation
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(stringResource(Res.string.no_saved_cards))
                }
            }
        }
    }
}

@Composable
private fun CustomButton(
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.primary,
    contentColor: Color = MaterialTheme.colorScheme.onPrimary,
    onClick: () -> Unit,
    text: String,
    enabled: Boolean = true,
) {

    val disabledButtonColor = MaterialTheme.colorScheme.surfaceContainerLow.copy(alpha = 0.5f)
    val disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)

    Box(
        modifier = modifier
            .background(
                color = if (!enabled) disabledButtonColor else containerColor,
                shape = RoundedCornerShape(16.dp)
            )
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                enabled = enabled,
                onClick = onClick
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = remember(enabled) { if (!enabled) disabledTextColor else contentColor }
        )
    }
}