package com.accesspaysuite.mobilesdk.data.internal.common

import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CustomerDetails
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.common.FinancialDetails
import com.accesspaysuite.mobilesdk.data.common.TransactionDetails
import com.accesspaysuite.mobilesdk.modules.DeviceInfoController
import kotlinx.serialization.Serializable

/**
 * @param customer The customer details (AP only)
 * @param financial The financial details (AP only)
 * @param transaction The transaction details (AP only)
 */
@Serializable
internal data class PaymentInfo(
    val environment: Environment,
    val installationId: String,
    val clientToken: String,
    val providerId: String,
    val customer: CustomerDetails? = null,
    val financial: FinancialDetails? = null,
    val transaction: TransactionDetails? = null,
    val openBankingCountries: List<String>? = null,
) {

    internal fun newPayment(
        paymentMethod: PaymentMethod,
        registeredCustomer: Boolean = false,
        billingAddress: BillingAddress?,
        deviceInfoController: DeviceInfoController,
    ): PaymentBody {
        return PaymentBody(
            paymentMethod = paymentMethod,
            transaction = transaction,
            customer = if (registeredCustomer) customer else customer?.copy(customerRef = null),
            deviceInfo = deviceInfoController.toDeviceInfo(),
            billingAddress = billingAddress,
            registered = registeredCustomer && !customer?.customerRef.isNullOrEmpty(),
            sdkVersion = deviceInfoController.sdkVersion,
            financialServices = financial,
            merchantAppName = deviceInfoController.merchantAppName,
            merchantAppVersion = deviceInfoController.merchantAppVersion
        )
    }
}

