package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.PopupProperties
import com.accesspaysuite.mobilesdk.data.internal.common.Card
import com.accesspaysuite.mobilesdk.data.common.getCardIcon
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_select
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_delete
import com.accesspaysuite.mobilesdk.sdk.generated.resources.ic_unkown_credit_card
import com.accesspaysuite.mobilesdk.sdk.generated.resources.last_four
import com.accesspaysuite.mobilesdk.sdk.generated.resources.new_card
import com.accesspaysuite.mobilesdk.sdk.generated.resources.unknown_card
import org.jetbrains.compose.resources.painterResource
import org.jetbrains.compose.resources.stringResource

@Composable
internal fun CardsSpinnerView(
    savedCards: List<Card>,
    savedCard: Card?,
    onCardSelected: (Card?) -> Unit,
    onCardDeleted: (Card) -> Unit
) {

    var expanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    var selectedCard by remember { mutableStateOf(savedCard) }

    Box(
        modifier = Modifier.fillMaxWidth()
    ) {
        DropdownMenu(
            expanded = expanded,
            offset = DpOffset(x = 0.dp, y = (-56).dp),
            onDismissRequest = { expanded = false },
            properties = PopupProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false,
            ),
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .fillMaxWidth()
        ) {
            if (savedCards.isNotEmpty()) {
                DropdownMenuItem(
                    onClick = {
                        selectedCard = null
                    },
                    modifier = Modifier
                        .padding(top = 0.dp, bottom = 0.dp, start = 16.dp, end = 8.dp)
                        .fillMaxWidth()
                        .background(Color.White),
                    text = {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(
                                painter = painterResource(Res.drawable.ic_unkown_credit_card),
                                contentDescription = stringResource(Res.string.unknown_card),
                            )
                            Spacer(modifier = Modifier.width(24.dp))
                            Text(
                                text = stringResource(Res.string.new_card),
                                fontSize = 16.sp,
                                modifier = Modifier
                                    .weight(1f)
                            )

                            Spacer(modifier = Modifier.width(48.dp))
                            RadioButton(
                                selected = selectedCard == null,
                                onClick = { }
                            )

                            Image(
                                imageVector = Icons.Rounded.KeyboardArrowUp,
                                contentDescription = stringResource(Res.string.unknown_card),
                            )
                        }
                    }
                )
            }
            savedCards.forEach { card ->
                DropdownMenuItem(
                    onClick = {
                        selectedCard = card
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .padding(top = 0.dp, bottom = 0.dp, start = 16.dp, end = 32.dp)
                        .fillMaxWidth(),
                    text = {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Image(
                                painter = painterResource(card.cardType!!.getCardIcon()),
                                contentDescription = card.cardType!!.name,
                            )
                            Spacer(modifier = Modifier.width(24.dp))
                            Text(
                                text = stringResource(Res.string.last_four, card.lastFour.toString()),
                                fontSize = 16.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(24.dp))
                            IconButton(
                                onClick = { onCardDeleted(card) }
                            ) {
                                Icon(
                                    painter = painterResource(Res.drawable.ic_delete),
                                    contentDescription = null
                                )
                            }
                            RadioButton(
                                selected = selectedCard == card,
                                onClick = { }
                            )
                        }
                    }
                )
            }

            if (savedCards.isNotEmpty()) {
                Button(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),

                    onClick = {
                        expanded = false
                        onCardSelected(selectedCard)
                    },

                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color.Black
                    ),
                    elevation = ButtonDefaults.buttonElevation(
                        defaultElevation = 0.dp,
                        pressedElevation = 2.dp
                    )
                ) {
                    Text(text = stringResource(Res.string.card_select))
                }
            }
        }

        AnimatedVisibility(
            visible = savedCards.isNotEmpty(),
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            Button(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                onClick = {
                    expanded = true
                },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFD4D4D4),
                    contentColor = Color.Black
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 0.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    selectedCard?.let { card ->
                        Image(
                            painter = painterResource(card.cardType!!.getCardIcon()),
                            contentDescription = card.cardType!!.name,
                        )
                        Spacer(modifier = Modifier.width(24.dp))
                    }
                    val newCard = stringResource(Res.string.new_card)
                    val lastFour =
                        selectedCard?.let { stringResource(Res.string.last_four, it.lastFour.toString()) }
                            ?: newCard
                    val text by remember(selectedCard) {
                        mutableStateOf(if (selectedCard != null) lastFour else newCard)
                    }
                    Text(
                        text = text,
                        fontSize = 16.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = null,
                        modifier = Modifier.size(24.dp),
                        tint = MaterialTheme.colorScheme.contentColorFor(Color.Black)
                    )
                }
            }
        }

        LaunchedEffect(savedCards) {
            if (savedCards.isEmpty()) {
                expanded = false
            }
        }

        DisposableEffect(Unit) {
            if (!expanded) {
                focusManager.clearFocus()
            }
            onDispose { }
        }
    }
}