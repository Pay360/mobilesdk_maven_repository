package com.accesspaysuite.mobilesdk.ui.standalone.core

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.contentColorFor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.PopupProperties
import com.accesspaysuite.mobilesdk.data.internal.common.Country
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation

@Composable
internal fun CountryDropdown(
    countryList: List<Country>,
    initialCountryCode: String?,
    modifier: Modifier = Modifier,
    textStyle: TextStyle,
    onSelected: (country: Country) -> Unit
) {

    var expanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    val defaultCountry = countryList.find {
        it.alpha3.uppercase() == initialCountryCode?.uppercase()
    }
    var selectedCountry by remember { mutableStateOf(defaultCountry) }

    Box(
        modifier = Modifier.fillMaxWidth()
    ) {
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            properties = PopupProperties(
                dismissOnBackPress = true,
                dismissOnClickOutside = false,
            ),
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface)
                .fillMaxWidth(0.9f)
                .height(256.dp)
        ) {
            countryList.forEach { country ->
                DropdownMenuItem(
                    onClick = {
                        selectedCountry = country
                        expanded = false
                        onSelected(country)
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .padding(end = 24.dp)
                        .fillMaxWidth(),
                    text = {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                text = country.name,
                                modifier = Modifier.weight(1f),
                                style = textStyle
                            )
                            Spacer(modifier = Modifier.width(24.dp))
                        }
                    }
                )
            }
        }

        AnimatedVisibility(
            visible = countryList.isNotEmpty(),
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            Button(
                modifier = modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                onClick = {
                    expanded = true
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Transparent,
                    contentColor = Color.Black
                ),
                elevation = ButtonDefaults.buttonElevation(
                    defaultElevation = 0.dp,
                    pressedElevation = 2.dp
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    selectedCountry?.let {
                        Text(
                            text = selectedCountry?.name ?: "",
                            modifier = Modifier.weight(1f),
                            style = textStyle
                        )
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowDown,
                            contentDescription = null,
                            modifier = Modifier.size(24.dp),
                            tint = MaterialTheme.colorScheme.contentColorFor(Color.Black)
                        )
                    }
                }
            }

            LaunchedEffect(countryList) {
                if (countryList.isEmpty()) {
                    expanded = false
                }
            }

            DisposableEffect(Unit) {
                if (!expanded) {
                    focusManager.clearFocus()
                }
                onDispose { }
            }
        }
    }
}
