package com.accesspaysuite.mobilesdk.callbacks.internal

import com.accesspaysuite.mobilesdk.callbacks.CardCallback
import com.accesspaysuite.mobilesdk.data.common.CardError

/**
 * # Empty Card Callback
 * Empty implementation of [CardCallback]
 */
internal val EmptyCardCallback = object : CardCallback {
    override fun onCardSubmittedSuccessfully() = Unit

    override fun onCardSubmittedWithErrors(errors: Array<CardError>) = Unit
}