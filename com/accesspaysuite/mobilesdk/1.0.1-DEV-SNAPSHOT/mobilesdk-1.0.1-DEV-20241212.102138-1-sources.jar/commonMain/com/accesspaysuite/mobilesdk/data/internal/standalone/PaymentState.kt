package com.accesspaysuite.mobilesdk.data.internal.standalone

import androidx.compose.runtime.Stable
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import kotlinx.serialization.Serializable

@Stable
@Serializable
internal data class PaymentState(
    val paymentType: PaymentType = PaymentType.GuestPayment,
    val reason: String? = null,
)
