package com.accesspaysuite.mobilesdk.ui.billing

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.ui.components.ComponentFontWeight

/**
 * Billing address state
 *
 * @property fontSize
 * @property fontWeight
 * @property borderSize
 * @property borderCornerRadius
 * @property borderColor
 * @property defaultCountryCode
 * @property useDropdown
 * @property showAddressLine2
 * @property showAddressLine3
 * @property showAddressLine4
 * @property skipCheckboxUI
 * @property defaultAddress
 * @property onAddressFilled
 */
data class BillingAddressState(
    val fontSize: Int = 14,
    val fontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    val borderSize: Int = 1,
    val borderCornerRadius: Int = 4,
    val borderColor: Int? = null,
    val defaultCountryCode: String = "GBR",
    val useDropdown: Boolean = false,
    val showAddressLine2: Boolean = true,
    val showAddressLine3: Boolean = false,
    val showAddressLine4: Boolean = false,
    val skipCheckboxUI: Boolean = false,
    val defaultAddress: BillingAddress? = null,
    val onAddressFilled: (BillingAddress) -> Unit = {}
) {
    constructor() : this(
        fontSize = 14,
        fontWeight = ComponentFontWeight.NORMAL,
        borderSize = 1,
        borderCornerRadius = 4,
        borderColor = null,
        defaultCountryCode = "GBR",
        useDropdown = false,
        showAddressLine2 = true,
        showAddressLine3 = false,
        showAddressLine4 = false,
        skipCheckboxUI = false,
        defaultAddress = null,
        onAddressFilled = {}
    )

    /**
     * Set on address filled
     *
     * @param callback
     * @receiver
     */
    fun setOnAddressFilled(callback: (BillingAddress) -> Unit) = copy(onAddressFilled = callback)
}

/**
 * Remember billing address state
 *
 * @param key
 * @param fontSize
 * @param fontWeight
 * @param borderSize
 * @param borderCornerRadius
 * @param borderColor
 * @param defaultCountryCode
 * @param useDropdown
 * @param showAddressLine2
 * @param showAddressLine3
 * @param showAddressLine4
 * @param skipCheckboxUI
 * @param defaultAddress
 * @param onAddressFilled
 * @receiver
 */
@Composable
fun rememberBillingAddressState(
    key: Any = Unit,
    fontSize: Int = 14,
    fontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    borderSize: Int = 1,
    borderCornerRadius: Int = 4,
    borderColor: Int? = null,
    defaultCountryCode: String = "GBR",
    useDropdown: Boolean = false,
    showAddressLine2: Boolean = true,
    showAddressLine3: Boolean = false,
    showAddressLine4: Boolean = false,
    skipCheckboxUI: Boolean = false,
    defaultAddress: BillingAddress? = null,
    onAddressFilled: (BillingAddress) -> Unit
) = remember(key) {
    BillingAddressState(
        fontSize,
        fontWeight,
        borderSize,
        borderCornerRadius,
        borderColor,
        defaultCountryCode,
        useDropdown,
        showAddressLine2,
        showAddressLine3,
        showAddressLine4,
        skipCheckboxUI,
        defaultAddress,
        onAddressFilled
    )
}

/**
 * Remember billing address state
 *
 * @param keys
 * @param fontSize
 * @param fontWeight
 * @param borderSize
 * @param borderCornerRadius
 * @param borderColor
 * @param defaultCountryCode
 * @param useDropdown
 * @param showAddressLine2
 * @param showAddressLine3
 * @param showAddressLine4
 * @param skipCheckboxUI
 * @param defaultAddress
 * @param onAddressFilled
 * @receiver
 */
@Composable
fun rememberBillingAddressState(
    vararg keys: Any = arrayOf(Unit),
    fontSize: Int = 14,
    fontWeight: ComponentFontWeight = ComponentFontWeight.NORMAL,
    borderSize: Int = 1,
    borderCornerRadius: Int = 4,
    borderColor: Int? = null,
    defaultCountryCode: String = "GBR",
    useDropdown: Boolean = false,
    showAddressLine2: Boolean = true,
    showAddressLine3: Boolean = false,
    showAddressLine4: Boolean = false,
    skipCheckboxUI: Boolean = false,
    defaultAddress: BillingAddress? = null,
    onAddressFilled: (BillingAddress) -> Unit
) = remember(keys) {
    BillingAddressState(
        fontSize,
        fontWeight,
        borderSize,
        borderCornerRadius,
        borderColor,
        defaultCountryCode,
        useDropdown,
        showAddressLine2,
        showAddressLine3,
        showAddressLine4,
        skipCheckboxUI,
        defaultAddress,
        onAddressFilled
    )
}