package com.accesspaysuite.mobilesdk.callbacks

import com.accesspaysuite.mobilesdk.data.Status

/**
 * Payment result callback
 *
 * @constructor Create empty Payment result callback
 */
interface PaymentResultCallback {

    /**
     * # On Payment Result Callback
     *
     * This callback is used to notify the result of the payment.
     *
     * Possible status values:
     * - Success
     * - Error (with a message)
     * - Canceled
     * - Initiated (when the payment is initiated)
     * - SessionExpired (when the session/authentication token is expired)
     *
     * @param status The status of the payment result
     */
    fun onPaymentResult(status: Status)

    companion object {
        internal val Empty = object : PaymentResultCallback {
            override fun onPaymentResult(status: Status) = Unit
        }
    }
}