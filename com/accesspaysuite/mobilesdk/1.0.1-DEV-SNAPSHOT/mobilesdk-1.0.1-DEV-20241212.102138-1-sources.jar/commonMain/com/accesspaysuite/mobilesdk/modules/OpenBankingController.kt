package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentBody
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentInfo
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking.Companion.MODE_REDIRECT
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking.Companion.TEST_RETURN_URL
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBankingPaymentResponse
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.utils.URLProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.seconds

/**
 * Open banking controller
 *
 * @constructor
 *
 * @param repository
 * @param deviceInfoController
 * @param delegate
 */
internal expect class OpenBankingController(
    repository: RequestRepository,
    deviceInfoController: DeviceInfoController,
    delegate: PaymentResultCallback
): OpenBankingControllerCommon {

    /**
     * Process bank payment
     *
     * @param billingAddress
     */
    fun processBankPayment(
        billingAddress: BillingAddress?
    )

}

/**
 * Open banking controller common
 *
 * @property repository
 * @property deviceInfoController
 * @property delegate
 * @constructor Create empty Open banking controller common
 */
internal abstract class OpenBankingControllerCommon(
    private val repository: RequestRepository,
    private val deviceInfoController: DeviceInfoController,
    private val delegate: PaymentResultCallback
): HttpRequestDelegate<OpenBankingPaymentResponse> {

    private val scope by lazy { CoroutineScope(Dispatchers.IO + SupervisorJob()) }
    private var paymentInfo: PaymentInfo? = null
    private var onPaymentUrlReceived: (String) -> Unit = {}

    private val credentials: AuthCredentials by lazy {
        AuthCredentials(
            token = paymentInfo!!.clientToken,
            providerId = paymentInfo!!.providerId
        )
    }

    private var paymentStarted: Boolean = false
    private var paymentObject: PaymentBody? = null
    private var currentBillingAddress: BillingAddress? = null

    /**
     * Set payment info
     *
     * @param paymentInfo
     */
    fun setPaymentInfo(paymentInfo: PaymentInfo) {
        this.paymentInfo = paymentInfo
    }

    /**
     * Pre process bank payment
     *
     * @param billingAddress
     * @param onPaymentUrlReceived
     * @receiver
     */
    protected fun preProcessBankPayment(
        billingAddress: BillingAddress?,
        onPaymentUrlReceived: (String) -> Unit
    ) {
        checkNotNull(paymentInfo) { "PaymentInfo must be set before calling processBankPayment" }
        checkNotNull(billingAddress) { "Billing address is required for Open Banking payments" }
        val paymentSupported = paymentInfo?.openBankingCountries?.contains(billingAddress.countryCode) ?: false
        if (!paymentSupported) {
            delegate.onPaymentResult(Status.Error("Open Banking is not supported in this country"))
            return
        }

        currentBillingAddress = billingAddress

        this.onPaymentUrlReceived = onPaymentUrlReceived
        val paymentRequestUrl = URLProvider.getPaymentProcessUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId
        )
        paymentObject = paymentInfo!!.newPayment(
            paymentMethod = PaymentMethod(
                openBanking = OpenBanking(
                    mode = MODE_REDIRECT,
                    returnUrl = TEST_RETURN_URL
                )
            ),
            billingAddress = billingAddress,
            deviceInfoController = deviceInfoController
        )
        repository.obRequest(
            url = paymentRequestUrl,
            httpMethod = "POST",
            requestType = APIRequestType.APIRequestOpenBanking,
            authCredentials = credentials,
            bodyObject = paymentObject!!,
            delegate = this
        )
    }

    /**
     * Post process bank payment
     *
     * @param isCancelled
     */
    protected fun postProcessBankPayment(
        isCancelled: Boolean
    ) {
        if (isCancelled) {
            delegate.onPaymentResult(Status.Canceled)
            return
        }
        val paymentRequestUrl = URLProvider.getResumePaymentUrl(
            paymentInfo!!.environment,
            paymentInfo!!.installationId,
            paymentInfo!!.transaction!!.transactionId!!
        )
        repository.obRequest(
            url = paymentRequestUrl,
            httpMethod = "POST",
            requestType = APIRequestType.APIRequestOpenBanking,
            authCredentials = credentials,
            bodyObject = paymentInfo!!.newPayment(
                paymentMethod = PaymentMethod(
                    openBanking = OpenBanking(
                        mode = MODE_REDIRECT,
                        returnUrl = TEST_RETURN_URL
                    )
                ),
                billingAddress = currentBillingAddress,
                deviceInfoController = deviceInfoController
            ),
            delegate = this
        )

    }

    override fun responseReceivedWithSuccess(
        requestType: APIRequestType,
        response: OpenBankingPaymentResponse
    ) {
        val clientRedirect = response.clientRedirect
        if (!paymentStarted) {
            clientRedirect?.let {
                paymentStarted = true
                onPaymentUrlReceived(it.url)
                return
            }
        } else {
            // TODO: (OB) Get all status messages and reasonCodes to handle all cases
            val status = response.transaction?.status
            val reasonCode = response.outcome.reasonCode
            if (status == "PENDING" || reasonCode == "U100") {
                scope.launch {
                    // Delay for 1 second before checking the payment status
                    delay(1.seconds)
                    postProcessBankPayment(false)
                }
                return
            } else if (status == "SUCCESS" || reasonCode == "0") {
                delegate.onPaymentResult(Status.Success)
            } else {
                delegate.onPaymentResult(Status.Error("Error processing payment. Please try again. ($reasonCode)"))
            }
            reset()
        }
    }

    override fun responseReceivedWithFailure(requestType: APIRequestType, reason: String?) {
        delegate.onPaymentResult(Status.Error("Error processing payment. Please try again. ($reason)"))
        reset()
    }

    // Reset the payment state after determining the outcome
    private fun reset() {
        paymentStarted = false
        currentBillingAddress = null
        onPaymentUrlReceived = {}
        paymentInfo = null
        paymentObject = null
    }

}