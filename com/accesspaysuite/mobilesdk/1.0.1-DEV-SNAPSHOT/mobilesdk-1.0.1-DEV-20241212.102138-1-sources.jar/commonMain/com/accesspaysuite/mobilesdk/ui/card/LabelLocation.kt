package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.runtime.Stable

/**
 * Label location
 *
 * @constructor Create empty Label location
 */
@Stable
enum class LabelLocation {
    /**
     * Top
     *
     * @constructor Create Top
     */
    TOP,

    /**
     * Contained
     *
     * @constructor Create Contained
     */
    CONTAINED,
}