package com.accesspaysuite.mobilesdk.data.internal.response

import kotlinx.serialization.Serializable

@Serializable
internal data class PaymentResponseCustomFields(
    val fieldState: List<CustomField>
)

@Serializable
internal data class CustomField(
    internal var name: String? = null,
    internal var value: String? = null
) {

    fun setName(name: String?): CustomField {
        this.name = name
        return this
    }

    fun setValue(value: String?): CustomField {
        this.value = value
        return this
    }
}