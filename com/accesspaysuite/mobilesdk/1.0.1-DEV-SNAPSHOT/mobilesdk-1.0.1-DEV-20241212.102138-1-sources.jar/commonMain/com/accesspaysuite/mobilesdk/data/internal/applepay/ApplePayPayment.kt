package com.accesspaysuite.mobilesdk.data.internal.applepay

import kotlinx.serialization.Serializable

@Serializable
internal data class ApplePayPayment(
    val paymentData: String,
    val paymentMethod: ApplePayPaymentMethod,
    val transactionIdentifier: String
)
