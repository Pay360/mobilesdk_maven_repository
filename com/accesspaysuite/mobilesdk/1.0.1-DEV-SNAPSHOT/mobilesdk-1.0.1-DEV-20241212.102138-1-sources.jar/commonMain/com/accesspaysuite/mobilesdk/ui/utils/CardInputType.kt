package com.accesspaysuite.mobilesdk.ui.utils

import androidx.compose.runtime.Stable

@Stable
internal enum class CardInputType {
    PAN, EXPIRY, CVV, NAME
}
