package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentBody
import io.ktor.client.HttpClient
import io.ktor.client.request.bearerAuth
import io.ktor.client.request.headers
import io.ktor.client.request.request
import io.ktor.client.request.setBody
import io.ktor.client.statement.HttpResponse
import io.ktor.client.statement.bodyAsText
import io.ktor.http.ContentType
import io.ktor.http.HttpMethod
import io.ktor.http.contentType
import kotlinx.serialization.json.Json

internal val parser by lazy {
    Json {
        explicitNulls = false
        ignoreUnknownKeys = true
    }
}

internal const val PROVIDER_ID_HEADER = "Pay360-Provider-ID"

private fun getMethod(string: String) =
    if (string == "POST") HttpMethod.Post else HttpMethod.Get

internal suspend inline fun HttpClient.retrieveResponse(
    url: String,
    httpMethod: String,
    authCredentials: AuthCredentials,
    bodyObject: PaymentBody,
) = request(url) {
    method = getMethod(httpMethod)
    headers {
        bearerAuth(authCredentials.token)
        append(
            name = PROVIDER_ID_HEADER,
            value = authCredentials.providerId ?: "AP"
        )
    }
    if (httpMethod == "POST") {
        contentType(ContentType.Application.Json)
        setBody(bodyObject)
    }
}

internal suspend inline fun <reified T> HttpResponse.answerWithDelegate(
    requestType: APIRequestType,
    delegate: HttpRequestDelegate<T>
) {
    if (status.value in 200..500) {
        try {
            delegate.responseReceivedWithSuccess(
                requestType = requestType,
                response = parser.decodeFromString(bodyAsText())
            )
        } catch (e: Exception) {
            e.printStackTrace()
            delegate.responseReceivedWithFailure(
                requestType = requestType,
                reason = e.message
            )
        }
    } else {
        delegate.responseReceivedWithFailure(
            requestType = requestType,
            reason = "Unexpected Response from Server - Status Code: ${status.value}\nBody: ${bodyAsText()}"
        )
    }
}