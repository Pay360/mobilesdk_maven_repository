package com.accesspaysuite.mobilesdk.ui.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.autofill.AutofillType
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.sdk.generated.resources.Res
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_holder_name_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.card_number_placeholder
import com.accesspaysuite.mobilesdk.sdk.generated.resources.cvv_default
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_cvv_incomplete
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_cvv_mandatory
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_date_invalid
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_date_mandatory
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_date_past
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_pan_incomplete
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_pan_invalid
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_pan_mandatory
import com.accesspaysuite.mobilesdk.sdk.generated.resources.err_pan_not_accepted
import com.accesspaysuite.mobilesdk.sdk.generated.resources.expiry_date_default
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.CVV
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.EXPIRY
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.NAME
import com.accesspaysuite.mobilesdk.ui.utils.CardInputType.PAN
import com.accesspaysuite.mobilesdk.ui.utils.CardNumberMask
import com.accesspaysuite.mobilesdk.ui.utils.ExpirationDateMask
import com.accesspaysuite.mobilesdk.ui.utils.autoFillHandler
import com.accesspaysuite.mobilesdk.ui.utils.connectNode
import com.accesspaysuite.mobilesdk.ui.utils.defaultFocusChangeAutoFill
import com.accesspaysuite.mobilesdk.ui.utils.validateCreditCardNumber
import com.accesspaysuite.mobilesdk.utils.expiryDateValid
import com.accesspaysuite.mobilesdk.utils.isDateInPast
import com.accesspaysuite.mobilesdk.utils.noWhitespace
import org.jetbrains.compose.resources.stringResource

@OptIn(ExperimentalComposeUiApi::class)
@Composable
internal fun CardInputField(
    inputType: CardInputType,
    cardType: CardType,
    text: String,
    onValueChange: (String) -> Unit,
    textStyle: TextStyle,
    onError: (error: String) -> Unit,
    modifier: Modifier = Modifier,
    imeAction: ImeAction = ImeAction.Next,
    enabled: Boolean = true,
    isOutlined: Boolean = false,
    borderColor: Color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
    shape: Shape = TextFieldDefaults.shape,
    label: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
) {

    val focusManager = LocalFocusManager.current
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()
    var wasFocused by rememberSaveable { mutableStateOf(false) }
    val fillTypes = remember(inputType) {
        when (inputType) {
            PAN -> listOf(AutofillType.CreditCardNumber)
            EXPIRY -> listOf(AutofillType.CreditCardExpirationDate)
            CVV -> listOf(AutofillType.CreditCardSecurityCode)
            NAME -> listOf(AutofillType.PersonFullName)
        }
    }
    val node = autoFillHandler(
        autofillTypes = fillTypes,
        onFill = {
            var rawValue = it.filter { input ->
                if (inputType == NAME) !input.isDigit() else input.isDigit()
            }.apply {
                if (inputType != NAME) it.noWhitespace()
            }
            val charLimit = when (inputType) {
                PAN -> 16
                EXPIRY -> 4
                CVV -> cardType.length
                else -> null
            }
            charLimit?.let { limit ->
                rawValue = rawValue.take(limit)
            }
            if (it.length > (charLimit ?: 64)) {
                focusManager.moveFocus(FocusDirection.Next)
            }
            onValueChange(rawValue)
        }
    )

    // Card number error messages
    val errorPanNotAccepted = stringResource(Res.string.err_pan_not_accepted)
    val errorPanInvalid = stringResource(Res.string.err_pan_invalid)
    val errorPanMandatory = stringResource(Res.string.err_pan_mandatory)
    val errorPanIncomplete = stringResource(Res.string.err_pan_incomplete)

    // Expiry date error messages
    val errorDateInvalid = stringResource(Res.string.err_date_invalid)
    val errorDatePast = stringResource(Res.string.err_date_past)
    val errorDateMandatory = stringResource(Res.string.err_date_mandatory)

    // CVV error messages
    val errorCVVMandatory = stringResource(Res.string.err_cvv_mandatory)
    val errorCVVIncomplete = stringResource(Res.string.err_cvv_incomplete)

    val isError: Boolean = remember(text, isFocused) {
        if (isFocused || !wasFocused) {
            wasFocused = true
            onError("")
            return@remember false
        }
        when (inputType) {
            PAN -> {
                onError(
                    (if (text.length != 16 && text.isNotBlank()) {
                        errorPanIncomplete
                    } else if (!validateCreditCardNumber(text)) {
                        errorPanInvalid
                    } else if (text.isBlank()) {
                        errorPanMandatory
                    } else if (cardType == CardType.NONE) {
                        errorPanNotAccepted
                    } else "").toString()
                )
                !validateCreditCardNumber(text) || text.length < 16 || cardType == CardType.NONE
            }

            EXPIRY -> {
                onError(
                    (if (!expiryDateValid(text)) errorDateInvalid
                    else if (text.isBlank()) errorDateMandatory
                    else if (isDateInPast(text)) errorDatePast
                    else "").toString()
                )
                !expiryDateValid(text) || text.length < 4
            }

            CVV -> {
                val maxLength = if (cardType == CardType.AMEX) 4 else 3
                onError(
                    (if (text.isBlank()) errorCVVMandatory
                    else if (text.length < maxLength) errorCVVIncomplete
                    else "").toString()
                )
                text.length != maxLength
            }

            NAME -> {
                text.isBlank()
            }
        }
    }


    val placeholderText = when (inputType) {
        PAN -> stringResource(Res.string.card_number_placeholder)
        EXPIRY -> stringResource(Res.string.expiry_date_default)
        CVV -> stringResource(Res.string.cvv_default)
        NAME -> stringResource(Res.string.card_holder_name_default)
    }

    BetterTextField(
        modifier = modifier
            .connectNode(handler = node)
            .defaultFocusChangeAutoFill(handler = node)
            .then(if (inputType == PAN) Modifier.defaultMinSize(minWidth = 156.dp) else Modifier),
        value = text,
        shape = shape,
        isEnabled = enabled,
        trailingIcon = trailingIcon,
        label = label,
        isOutlined = isOutlined,
        interactionSource = interactionSource,
        onValueChange = {
            var rawValue = it.filter { input ->
                if (inputType == NAME) !input.isDigit() else input.isDigit()
            }.apply {
                if (inputType != NAME) it.noWhitespace()
            }
            val charLimit = when (inputType) {
                PAN -> 16
                EXPIRY -> 4
                CVV -> if (cardType == CardType.AMEX) 4 else 3
                else -> null
            }
            charLimit?.let { limit ->
                rawValue = rawValue.take(limit)
            }
            if (it.length > (charLimit ?: 64)) {
                focusManager.moveFocus(FocusDirection.Next)
            } else if (it.isEmpty()) {
                node.requestVerifyManual()
            }
            onValueChange(rawValue)
        },
        textStyle = textStyle,
        borderColor = borderColor,
        visualTransformation = if (text.isEmpty()) {
            PlaceholderTransformation(placeholderText)
        } else {
            when (inputType) {
                PAN -> CardNumberMask()
                EXPIRY -> ExpirationDateMask()
                CVV -> PasswordVisualTransformation()
                NAME -> VisualTransformation.None
            }
        },
        keyboardOptions = KeyboardOptions(
            keyboardType = if (inputType == NAME) KeyboardType.Text else KeyboardType.Number,
            imeAction = imeAction
        ),
        isError = isError,
        singleLine = true,
        placeholder = {
            Text(
                modifier = Modifier.fillMaxWidth(),
                text = placeholderText,
                overflow = TextOverflow.Ellipsis,
                maxLines = 1
            )
        },
    )
}

internal class PlaceholderTransformation(private val placeholder: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        return placeholderFilter(placeholder)
    }

    private fun placeholderFilter(placeholder: String): TransformedText {
        //var out = placeholder
        val numberOffsetTranslator = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int {
                return 0
            }

            override fun transformedToOriginal(offset: Int): Int {
                return 0
            }
        }

        return TransformedText(AnnotatedString(placeholder), numberOffsetTranslator)
    }
}