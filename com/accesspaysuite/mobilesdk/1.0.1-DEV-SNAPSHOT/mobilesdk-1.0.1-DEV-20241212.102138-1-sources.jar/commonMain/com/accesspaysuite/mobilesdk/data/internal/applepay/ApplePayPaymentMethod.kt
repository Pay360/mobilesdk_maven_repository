package com.accesspaysuite.mobilesdk.data.internal.applepay

import kotlinx.serialization.Serializable

@Serializable
internal data class ApplePayPaymentMethod(
    val displayName: String,
    val network: String,
    val type: String
)