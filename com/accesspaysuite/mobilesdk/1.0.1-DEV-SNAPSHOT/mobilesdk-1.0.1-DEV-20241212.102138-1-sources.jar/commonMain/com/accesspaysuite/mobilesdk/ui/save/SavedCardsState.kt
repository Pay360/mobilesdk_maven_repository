package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.remember
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI

/**
 * Saved cards state
 *
 * @property onCardSelected
 * @property tryToUseDefaultCard
 * @constructor Create empty Saved cards state
 */
@Stable
data class SavedCardsState(
    val onCardSelected: (isNewCard: Boolean) -> Unit = {},
    val tryToUseDefaultCard: Boolean = false
) {
    constructor() : this(
        onCardSelected = {},
        tryToUseDefaultCard = false
    )

    /**
     * Set on card selected
     *
     * @param callback
     * @receiver
     */
    fun setOnCardSelected(callback: (isNewCard: Boolean) -> Unit) = copy(onCardSelected = callback)

    /**
     * Set try to use default card
     *
     * @param tryToUseDefaultCard
     * @receiver
     */
    fun setTryToUseDefaultCard(tryToUseDefaultCard: Boolean) = copy(tryToUseDefaultCard = tryToUseDefaultCard)
}

/**
 * Remember saved cards state
 *
 * @param key
 * @param onCardSelected
 * @param tryToUseDefaultCard
 * @receiver
 */
@ExperimentalMobileUI
@Composable
fun rememberSavedCardsState(
    key: Any = Unit,
    onCardSelected: (isNewCard: Boolean) -> Unit = {},
    tryToUseDefaultCard: Boolean = false
) = remember(key) {
    SavedCardsState(onCardSelected, tryToUseDefaultCard)
}

/**
 * Remember saved cards state
 *
 * @param keys
 * @param onCardSelected
 * @param tryToUseDefaultCard
 * @receiver
 */
@ExperimentalMobileUI
@Composable
fun rememberSavedCardsState(
    vararg keys: Any = arrayOf(Unit),
    onCardSelected: (isNewCard: Boolean) -> Unit = {},
    tryToUseDefaultCard: Boolean = false
) = remember(keys) {
    SavedCardsState(onCardSelected, tryToUseDefaultCard)
}