package com.accesspaysuite.mobilesdk.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import com.accesspaysuite.mobilesdk.data.internal.common.Country
import com.accesspaysuite.mobilesdk.ui.components.Constants.enterAnimation
import com.accesspaysuite.mobilesdk.ui.components.Constants.exitAnimation
import io.github.alexzhirkevich.LocalContentColor
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveAlertDialog
import io.github.alexzhirkevich.cupertino.adaptive.AdaptiveWidget
import io.github.alexzhirkevich.cupertino.adaptive.ExperimentalAdaptiveApi
import io.github.alexzhirkevich.cupertino.cancel
import io.github.alexzhirkevich.cupertino.default

@OptIn(ExperimentalAdaptiveApi::class)
@Composable
internal fun CountryDropdown(
    countryList: List<Country>,
    initialCountryCode: String?,
    modifier: Modifier = Modifier,
    textStyle: TextStyle,
    onSelected: (country: Country) -> Unit
) {

    var expanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current

    val defaultCountry = countryList.find {
        it.alpha3.uppercase() == initialCountryCode?.uppercase()
    } ?: Country.Default
    var selectedCountry by remember { mutableStateOf(defaultCountry) }

    Box(
        modifier = Modifier.fillMaxWidth()
    ) {
        AnimatedVisibility(
            visible = expanded,
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            AdaptiveAlertDialog(
                onDismissRequest = {
                    expanded = false
                },
                title = { Text("Select Country") },
                properties = DialogProperties(
                    dismissOnBackPress = false,
                    dismissOnClickOutside = false
                ),
                message = {
                    val state = rememberLazyListState(
                        initialFirstVisibleItemIndex = countryList.indexOf(selectedCountry)
                    )

                    LazyColumn(
                        state = state,
                        modifier = Modifier.fillMaxHeight(0.5f)
                    ) {
                        items(
                            items = countryList
                        ) { item ->
                            AdaptiveWidget(
                                material = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth()
                                            .clickable {
                                                selectedCountry = item
                                            }
                                            .padding(vertical = 8.dp)
                                            .padding(end = 16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            modifier = Modifier.fillMaxWidth(),
                                            text = item.name,
                                        )
                                        RadioButton(
                                            selected = selectedCountry == item,
                                            onClick = null
                                        )
                                    }
                                },
                                cupertino = {
                                    Row(
                                        modifier = Modifier.fillMaxWidth()
                                            .clickable {
                                                selectedCountry = item
                                            }
                                            .padding(vertical = 8.dp)
                                            .padding(end = 16.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            modifier = Modifier.fillMaxWidth(),
                                            text = item.name,
                                        )
                                        RadioButton(
                                            selected = selectedCountry == item,
                                            onClick = null
                                        )
                                    }
                                }
                            )
                        }
                    }
                },
                buttons = {
                    default(
                        title = { Text("Ok") },
                        onClick = {
                            expanded = false
                            onSelected(selectedCountry)
                        }
                    )
                    cancel(title = { Text("Cancel") }, onClick = { expanded = false })
                },
            )
        }

        AnimatedVisibility(
            visible = countryList.isNotEmpty(),
            enter = enterAnimation,
            exit = exitAnimation
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = modifier
                    .fillMaxSize()
                    .clickable {
                        expanded = true
                    }
                    .padding(16.dp)
            ) {
                Text(
                    text = selectedCountry.name,
                    modifier = Modifier.weight(1f),
                    style = textStyle
                )
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowDown,
                    contentDescription = null,
                    modifier = Modifier.size(24.dp),
                    tint = LocalContentColor.current
                )
            }

            LaunchedEffect(countryList) {
                if (countryList.isEmpty()) {
                    expanded = false
                }
            }

            DisposableEffect(Unit) {
                if (!expanded) {
                    focusManager.clearFocus()
                }
                onDispose { }
            }
        }
    }
}
