package com.accesspaysuite.mobilesdk.data.internal.openbanking


import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
internal data class OpenBanking(
    @SerialName("mode")
    val mode: String? = null,
    @SerialName("returnUrl")
    val returnUrl: String? = null,
    @SerialName("remittanceReference")
    val remittanceReference: String? = null,
) {

    companion object {
        const val MODE_REDIRECT = "REDIRECT"
        const val TEST_RETURN_URL = "pay360://openBankingReturnUrl"
    }
}