package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import platform.UIKit.UIViewController

/**
 * Saved Cards Controller
 */
object SavedCardsController {
    private val state = mutableStateOf(SavedCardsState())

    @OptIn(ExperimentalComposeApi::class, ExperimentalMobileUI::class)
    fun make(): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            SavedCards()
        }
    }

    fun update(state: SavedCardsState) {
        this.state.value = state
    }
}
