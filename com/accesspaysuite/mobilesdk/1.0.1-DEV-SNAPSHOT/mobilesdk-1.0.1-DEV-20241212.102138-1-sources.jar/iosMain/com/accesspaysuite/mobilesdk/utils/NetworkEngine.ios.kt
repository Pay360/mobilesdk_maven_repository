package com.accesspaysuite.mobilesdk.utils

import com.accesspaysuite.mobilesdk.GlobalConfig
import io.ktor.client.HttpClient
import io.ktor.client.engine.darwin.Darwin
import io.ktor.client.engine.darwin.certificates.CertificatePinner
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.HttpTimeoutConfig
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json

internal actual object NetworkEngine {
    actual val client: HttpClient
        get() = HttpClient(Darwin) {
            install(HttpTimeout) {
                // Disable timeout for network calls to avoid any drops
                // for slower network connections
                requestTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                connectTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
                socketTimeoutMillis = HttpTimeoutConfig.INFINITE_TIMEOUT_MS
            }
            install(ContentNegotiation) {
                json(
                    json = parser
                )
            }
            if (GlobalConfig.LOGGING) {
                install(Logging) {
                    level = LogLevel.ALL
                }
            }

            engine {
                val builder = CertificatePinner.Builder()

                if (ENABLE_SSL_PINNING) {
                    builder.add(pattern = PINNED_HOST_NAME, pins = pins)
                }
                handleChallenge(builder.build())
            }
        }
}