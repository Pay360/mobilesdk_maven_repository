package com.accesspaysuite.mobilesdk.utils

import platform.Foundation.NSUserDefaults
import platform.Foundation.setValue

internal actual class StorageUtils {

    private val prefs by lazy { NSUserDefaults.standardUserDefaults }

    actual fun getString(key: String, default: String?): String? =
        prefs.stringForKey(defaultName = key)

    actual fun putString(key: String, value: String?) {
        prefs.setValue(value = value, forKey = key)
    }
}