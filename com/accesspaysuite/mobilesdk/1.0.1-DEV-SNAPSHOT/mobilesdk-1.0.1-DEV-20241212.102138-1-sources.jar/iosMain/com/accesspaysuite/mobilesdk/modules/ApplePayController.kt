package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.callbacks.internal.HttpRequestDelegate
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CardType
import com.accesspaysuite.mobilesdk.data.internal.applepay.ApplePayPayment
import com.accesspaysuite.mobilesdk.data.internal.applepay.ApplePayPaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.common.APIRequestType
import com.accesspaysuite.mobilesdk.data.internal.common.AuthCredentials
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentInfo
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentMethod
import com.accesspaysuite.mobilesdk.data.internal.initiate.InitiateApplePay
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponse
import com.accesspaysuite.mobilesdk.modules.CardController.Companion.STATUS_SUCCESS
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.utils.URLProvider
import com.accesspaysuite.mobilesdk.utils.presentViewController
import io.github.aakira.napier.Napier
import platform.Foundation.NSDataBase64EncodingOptions
import platform.Foundation.NSDecimalNumber
import platform.Foundation.base64EncodedStringWithOptions
import platform.PassKit.PKMerchantCapability3DS
import platform.PassKit.PKPayment
import platform.PassKit.PKPaymentAuthorizationController
import platform.PassKit.PKPaymentAuthorizationResult
import platform.PassKit.PKPaymentAuthorizationStatus
import platform.PassKit.PKPaymentAuthorizationViewController
import platform.PassKit.PKPaymentAuthorizationViewControllerDelegateProtocol
import platform.PassKit.PKPaymentMethodTypeCredit
import platform.PassKit.PKPaymentMethodTypeDebit
import platform.PassKit.PKPaymentMethodTypePrepaid
import platform.PassKit.PKPaymentMethodTypeStore
import platform.PassKit.PKPaymentNetwork
import platform.PassKit.PKPaymentNetworkAmex
import platform.PassKit.PKPaymentNetworkJCB
import platform.PassKit.PKPaymentNetworkMasterCard
import platform.PassKit.PKPaymentNetworkVisa
import platform.PassKit.PKPaymentRequest
import platform.PassKit.PKPaymentSummaryItem
import platform.darwin.NSObject

/**
 * Apple pay controller
 *
 * @constructor Create ApplePay controller
 */
internal class ApplePayController : NSObject, PKPaymentAuthorizationViewControllerDelegateProtocol {

    private val STATUS_FAILED = "FAILED"
    private val countryCodeDict: HashMap<String, String>
    private val customItemLabel: String
    private val paymentInfo: PaymentInfo
    private val repository: RequestRepository
    private val delegate: PaymentResultCallback
    private val credentials: AuthCredentials

    constructor(
        customItemLabel: String,
        paymentInfo: PaymentInfo,
        repository: RequestRepository,
        delegate: PaymentResultCallback
    ) : super() {
        this.customItemLabel = customItemLabel
        this.paymentInfo = paymentInfo
        this.repository = repository
        this.delegate = delegate
        this.deviceInfoController = DeviceInfoController()
        this.countryCodeDict = hashMapOf(
            "AFG" to "AF",
            "ALB" to "AL",
            "DZA" to "DZ",
            "ASM" to "AS",
            "AND" to "AD",
            "AGO" to "AO",
            "AIA" to "AI",
            "ATA" to "AQ",
            "ATG" to "AG",
            "ARG" to "AR",
            "ARM" to "AM",
            "ABW" to "AW",
            "AUS" to "AU",
            "AUT" to "AT",
            "AZE" to "AZ",
            "BHS" to "BS",
            "BHR" to "BH",
            "BGD" to "BD",
            "BRB" to "BB",
            "BLR" to "BY",
            "BEL" to "BE",
            "BLZ" to "BZ",
            "BEN" to "BJ",
            "BMU" to "BM",
            "BTN" to "BT",
            "BOL" to "BO",
            "BES" to "BQ",
            "BIH" to "BA",
            "BWA" to "BW",
            "BVT" to "BV",
            "BRA" to "BR",
            "IOT" to "IO",
            "BRN" to "BN",
            "BGR" to "BG",
            "BFA" to "BF",
            "BDI" to "BI",
            "CPV" to "CV",
            "KHM" to "KH",
            "CMR" to "CM",
            "CAN" to "CA",
            "CYM" to "KY",
            "CAF" to "CF",
            "TCD" to "TD",
            "CHL" to "CL",
            "CHN" to "CN",
            "CXR" to "CX",
            "CCK" to "CC",
            "COL" to "CO",
            "COM" to "KM",
            "COD" to "CD",
            "COG" to "CG",
            "COK" to "CK",
            "CRI" to "CR",
            "HRV" to "HR",
            "CUB" to "CU",
            "CUW" to "CW",
            "CYP" to "CY",
            "CZE" to "CZ",
            "CIV" to "CI",
            "DNK" to "DK",
            "DJI" to "DJ",
            "DMA" to "DM",
            "DOM" to "DO",
            "ECU" to "EC",
            "EGY" to "EG",
            "SLV" to "SV",
            "GNQ" to "GQ",
            "ERI" to "ER",
            "EST" to "EE",
            "SWZ" to "SZ",
            "ETH" to "ET",
            "FLK" to "FK",
            "FRO" to "FO",
            "FJI" to "FJ",
            "FIN" to "FI",
            "FRA" to "FR",
            "GUF" to "GF",
            "PYF" to "PF",
            "ATF" to "TF",
            "GAB" to "GA",
            "GMB" to "GM",
            "GEO" to "GE",
            "DEU" to "DE",
            "GHA" to "GH",
            "GIB" to "GI",
            "GRC" to "GR",
            "GRL" to "GL",
            "GRD" to "GD",
            "GLP" to "GP",
            "GUM" to "GU",
            "GTM" to "GT",
            "GGY" to "GG",
            "GIN" to "GN",
            "GNB" to "GW",
            "GUY" to "GY",
            "HTI" to "HT",
            "HMD" to "HM",
            "VAT" to "VA",
            "HND" to "HN",
            "HKG" to "HK",
            "HUN" to "HU",
            "ISL" to "IS",
            "IND" to "IN",
            "IDN" to "ID",
            "IRN" to "IR",
            "IRQ" to "IQ",
            "IRL" to "IE",
            "IMN" to "IM",
            "ISR" to "IL",
            "ITA" to "IT",
            "JAM" to "JM",
            "JPN" to "JP",
            "JEY" to "JE",
            "JOR" to "JO",
            "KAZ" to "KZ",
            "KEN" to "KE",
            "KIR" to "KI",
            "PRK" to "KP",
            "KOR" to "KR",
            "KWT" to "KW",
            "KGZ" to "KG",
            "LAO" to "LA",
            "LVA" to "LV",
            "LBN" to "LB",
            "LSO" to "LS",
            "LBR" to "LR",
            "LBY" to "LY",
            "LIE" to "LI",
            "LTU" to "LT",
            "LUX" to "LU",
            "MAC" to "MO",
            "MDG" to "MG",
            "MWI" to "MW",
            "MYS" to "MY",
            "MDV" to "MV",
            "MLI" to "ML",
            "MLT" to "MT",
            "MHL" to "MH",
            "MTQ" to "MQ",
            "MRT" to "MR",
            "MUS" to "MU",
            "MYT" to "YT",
            "MEX" to "MX",
            "FSM" to "FM",
            "MDA" to "MD",
            "MCO" to "MC",
            "MNG" to "MN",
            "MNE" to "ME",
            "MSR" to "MS",
            "MAR" to "MA",
            "MOZ" to "MZ",
            "MMR" to "MM",
            "NAM" to "NA",
            "NRU" to "NR",
            "NPL" to "NP",
            "NLD" to "NL",
            "NCL" to "NC",
            "NZL" to "NZ",
            "NIC" to "NI",
            "NER" to "NE",
            "NGA" to "NG",
            "NIU" to "NU",
            "NFK" to "NF",
            "MNP" to "MP",
            "NOR" to "NO",
            "OMN" to "OM",
            "PAK" to "PK",
            "PLW" to "PW",
            "PSE" to "PS",
            "PAN" to "PA",
            "PNG" to "PG",
            "PRY" to "PY",
            "PER" to "PE",
            "PHL" to "PH",
            "PCN" to "PN",
            "POL" to "PL",
            "PRT" to "PT",
            "PRI" to "PR",
            "QAT" to "QA",
            "MKD" to "MK",
            "ROU" to "RO",
            "RUS" to "RU",
            "RWA" to "RW",
            "REU" to "RE",
            "BLM" to "BL",
            "SHN" to "SH",
            "KNA" to "KN",
            "LCA" to "LC",
            "MAF" to "MF",
            "SPM" to "PM",
            "VCT" to "VC",
            "WSM" to "WS",
            "SMR" to "SM",
            "STP" to "ST",
            "SAU" to "SA",
            "SEN" to "SN",
            "SRB" to "RS",
            "SYC" to "SC",
            "SLE" to "SL",
            "SGP" to "SG",
            "SXM" to "SX",
            "SVK" to "SK",
            "SVN" to "SI",
            "SLB" to "SB",
            "SOM" to "SO",
            "ZAF" to "ZA",
            "SGS" to "GS",
            "SSD" to "SS",
            "ESP" to "ES",
            "LKA" to "LK",
            "SDN" to "SD",
            "SUR" to "SR",
            "SJM" to "SJ",
            "SWE" to "SE",
            "CHE" to "CH",
            "SYR" to "SY",
            "TWN" to "TW",
            "TJK" to "TJ",
            "TZA" to "TZ",
            "THA" to "TH",
            "TLS" to "TL",
            "TGO" to "TG",
            "TKL" to "TK",
            "TON" to "TO",
            "TTO" to "TT",
            "TUN" to "TN",
            "TUR" to "TR",
            "TKM" to "TM",
            "TCA" to "TC",
            "TUV" to "TV",
            "UGA" to "UG",
            "UKR" to "UA",
            "ARE" to "AE",
            "GBR" to "GB",
            "UMI" to "UM",
            "USA" to "US",
            "URY" to "UY",
            "UZB" to "UZ",
            "VUT" to "VU",
            "VEN" to "VE",
            "VNM" to "VN",
            "VGB" to "VG",
            "VIR" to "VI",
            "WLF" to "WF",
            "ESH" to "EH",
            "YEM" to "YE",
            "ZMB" to "ZM",
            "ZWE" to "ZW",
            "ALA" to "AX"
        )
        this.credentials = AuthCredentials(
            token = paymentInfo.clientToken,
            providerId = paymentInfo.providerId
        )
    }

    private var applePayIntent: InitiateApplePay? = null
    private var currentBillingAddress: BillingAddress? = null
    private val deviceInfoController: DeviceInfoController

    /**
     * Set apple pay intent
     *
     * @param intent
     */
    fun setApplePayIntent(intent: InitiateApplePay) {
        applePayIntent = intent
    }

    /**
     * Pay
     *
     * @param appleMerchantId
     * @param billingAddress
     */
    fun pay(appleMerchantId: String, billingAddress: BillingAddress) {
        currentBillingAddress = billingAddress
        val controller = PKPaymentAuthorizationViewController(
            paymentRequest = createPaymentRequest(
                appleMerchantId = appleMerchantId,
                amount = if (paymentInfo.transaction != null) paymentInfo.transaction.amount.toString() else null
            )
        ).apply { delegate = this@ApplePayController }
        presentViewController(controller)
    }

    /**
     * Is available
     *
     * @return
     */
    fun isAvailable(): Boolean {
        return PKPaymentAuthorizationController.canMakePayments() ||
                PKPaymentAuthorizationController.canMakePaymentsUsingNetworks(
                    applePayIntent!!.supportedNetworks.mapToPKPaymentNetworks()
                )
    }

    override fun paymentAuthorizationViewController(
        controller: PKPaymentAuthorizationViewController,
        didAuthorizePayment: PKPayment,
        completion: (PKPaymentAuthorizationStatus) -> Unit
    ) {
        controller.dismissWithResponse(didAuthorizePayment)
    }

    override fun paymentAuthorizationViewController(
        controller: PKPaymentAuthorizationViewController,
        didAuthorizePayment: PKPayment,
        handler: (PKPaymentAuthorizationResult?) -> Unit
    ) {
        controller.dismissWithResponse(didAuthorizePayment)
    }

    override fun paymentAuthorizationViewControllerDidFinish(controller: PKPaymentAuthorizationViewController) {
        controller.dismissWithResponse(null)
    }

    private fun createPaymentRequest(appleMerchantId: String, amount: String? = null): PKPaymentRequest {
        return PKPaymentRequest().apply {
            supportedNetworks = applePayIntent!!.supportedNetworks.mapToPKPaymentNetworks()
            merchantIdentifier = appleMerchantId
            merchantCapabilities = PKMerchantCapability3DS
            // Defaults to GB if not found
            countryCode = countryCodeDict[applePayIntent!!.merchantCountryCode] ?: "GB"
            currencyCode = applePayIntent!!.currencyCode
            paymentSummaryItems = listOf(
                PKPaymentSummaryItem.summaryItemWithLabel(
                    label = customItemLabel,
                    amount = NSDecimalNumber(
                        if (amount.isNullOrEmpty()) {
                            applePayIntent!!.amount.toString()
                        } else {
                            amount
                        }
                    )
                )
            )
            //requiredBillingAddressFields = PKAddressFieldAll
        }
    }

    private fun List<CardType>.mapToPKPaymentNetworks(): List<PKPaymentNetwork> {
        return map {
            when (it) {
                CardType.VISA -> PKPaymentNetworkVisa
                CardType.MASTERCARD -> PKPaymentNetworkMasterCard
                CardType.AMEX -> PKPaymentNetworkAmex
                CardType.JCB -> PKPaymentNetworkJCB
                else -> PKPaymentNetworkVisa
            }
        }
    }

    private fun PKPaymentAuthorizationViewController.dismissWithResponse(response: PKPayment?) {
        if (response != null) {
            try {
                val paymentData =
                    response.token.paymentData.base64EncodedStringWithOptions(NSDataBase64EncodingOptions.MIN_VALUE)
                val type = when (response.token.paymentMethod.type) {
                    PKPaymentMethodTypeCredit -> "credit"
                    PKPaymentMethodTypeDebit -> "debit"
                    PKPaymentMethodTypePrepaid -> "prepaid"
                    PKPaymentMethodTypeStore -> "store"
                    else -> "unknown"
                }
                val paymentMethod = ApplePayPaymentMethod(
                    displayName = response.token.paymentMethod.displayName.toString(),
                    network = response.token.paymentMethod.network.toString(),
                    type = type
                )
                val paymentRequestUrl = URLProvider.getPaymentProcessUrl(
                    paymentInfo.environment,
                    paymentInfo.installationId
                )
                val request = paymentInfo.newPayment(
                    paymentMethod = PaymentMethod(
                        applepay = ApplePayPayment(
                            paymentData = paymentData,
                            paymentMethod = paymentMethod,
                            transactionIdentifier = response.token.transactionIdentifier.toString()
                        )
                    ),
                    billingAddress = currentBillingAddress,
                    deviceInfoController = deviceInfoController
                )
                repository.request(
                    url = paymentRequestUrl,
                    httpMethod = "POST",
                    requestType = APIRequestType.APIRequestApplePayPayment,
                    authCredentials = credentials,
                    bodyObject = request,
                    delegate = object : HttpRequestDelegate<PaymentResponse> {

                        override fun responseReceivedWithSuccess(
                            requestType: APIRequestType,
                            response: PaymentResponse
                        ) {
                            this@ApplePayController.delegate.onPaymentResult(response.retrieveStatus())
                        }

                        override fun responseReceivedWithFailure(requestType: APIRequestType, reason: String?) {
                            this@ApplePayController.delegate.onPaymentResult(Status.Error(reason ?: "Unknown error"))
                        }
                    }
                )
            } catch (e: Exception) {
                e.printStackTrace()
                this@ApplePayController.delegate.onPaymentResult(Status.Error(e.message ?: "Unknown error"))
            }
        } else {
            this@ApplePayController.delegate.onPaymentResult(Status.Canceled)
        }
        dismissModalViewControllerAnimated(true)
    }

    private fun PaymentResponse.retrieveStatus(): Status {
        return if (outcome.status == STATUS_SUCCESS) {
            Status.Success
        } else {
            if (threeDSecure?.cardHolderMessage != null) {
                Status.Error(threeDSecure.cardHolderMessage)
            } else if (outcome.reasonMessage != null) {
                Napier.e { "Payment failed: ${outcome.reasonMessage} | Status: ${outcome.status} | TraceID: $trace" }
                if (outcome.reasonMessage == "Client token expired") {
                    Status.SessionExpired
                } else Status.Error(outcome.reasonMessage)
            } else {
                // Just for unexpected errors, this should never happen, but it's best to have
                // a way to debug if it does
                Napier.e { "Payment failed: Unknown error | Status: ${outcome.status} | TraceID: $trace" }
                Status.Error("Unknown error\nPlease contact administrator.")
            }
        }
    }


}
