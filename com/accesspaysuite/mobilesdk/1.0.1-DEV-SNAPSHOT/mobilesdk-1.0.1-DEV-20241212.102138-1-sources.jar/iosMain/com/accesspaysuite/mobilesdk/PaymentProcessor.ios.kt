package com.accesspaysuite.mobilesdk

import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.common.CardError
import com.accesspaysuite.mobilesdk.data.internal.initiate.AcceptPaymentMethods
import com.accesspaysuite.mobilesdk.modules.ApplePayController
import com.accesspaysuite.mobilesdk.modules.DeviceInfoController
import com.accesspaysuite.mobilesdk.modules.OpenBankingController
import com.accesspaysuite.mobilesdk.modules.ThreeDSController

/**
 * # Payment Processor (iOS)
 *
 *
 *  The [PaymentProcessor] class is responsible for handling the payment process.
 *  It is responsible for initiating the payment process,
 *  processing the Card, Google Pay payment methods, and handling the payment result.
 *
 *  ## Available functions
 *  - [initiate] - Initiates the payment processor
 *  - [processCardPayment] - Processes the card payment
 *  - [processApplePayPayment] - Processes the Apple Pay payment
 *  - [setPaymentResultCallback] - Sets the payment result callback
 *  - [setCardCallback] - Sets the card callback
 *  - [isApplePayAvailable] - Checks if Apple Pay is available
 *  - [detach] - Detaches the payment processor
 *  - [isCardEntered] - Checks if the card is entered
 *
 *
 *  ## Usage
 *  ### Kotlin
 *  ```kotlin
 *  val paymentProcessor = PaymentProcessor(
 *      paymentConfig = paymentConfig,
 *      context = context
 *  )
 *  paymentProcessor.initiate {
 *    // Payment Processor is initiated
 *  }
 *    // Set the payment result callback
 *  paymentProcessor.setPaymentResultCallback(
 *      onPaymentSuccess = {
 *          // Payment is successful
 *      },
 *      onPaymentFailed = { error ->
 *          // Payment failed
 *      },
 *      onPaymentMethodCanceled = {
 *          // Payment method is canceled
 *      }
 *  )
 *  // Set the card callback
 *  paymentProcessor.setCardCallback(
 *      onCardSubmittedSuccessfully = {
 *          // Card is submitted successfully
 *      },
 *      onCardSubmittedWithErrors = { errors ->
 *          // Card is submitted with errors
 *      }
 *  )
 *
 *
 *  // Process the card payment
 *  paymentProcessor.processCardPayment(billingAddress)
 *
 *  // Process the Apple Pay payment
 *  paymentProcessor.processApplePayPayment(appleMerchantId, billingAddress)
 *  ```
 *  ### Swift
 *  ```swift
 *  let processor = PaymentProcessor(config: paymentConfig)
 *  processor.initiate(
 *      onInit: { status in
 *          // Payment Processor is initiated
 *          // if Success, status should be an instance of Status.Initiated
 *      }
 *  )
 *  ...
 *  // Process the card payment
 *  processor.processCardPayment(billingAddress: billingAddress)
 *
 *  // Process the Apple Pay payment
 *  processor.processApplePayPayment(appleMerchantId: appleMerchantId, billingAddress: billingAddress)
 *  ```
 *
 *  @param config The payment configuration; see [PaymentConfig]
 *
 */
actual class PaymentProcessor(
    config: PaymentConfig
) : PaymentProcessorInternal(
    config = config,
    deviceInfoController = DeviceInfoController(),
    threeDSController = ThreeDSController()
) {

    private val applePayController by lazy {
        ApplePayController(
            customItemLabel = "Total",
            paymentInfo = paymentInfo,
            repository = repository,
            delegate = paymentResultCallback
        )
    }
    private val openBankingController by lazy {
        OpenBankingController(
            repository = repository,
            deviceInfoController = deviceInfoController,
            delegate = paymentResultCallback
        ).apply { setPaymentInfo(paymentInfo) }
    }

    /**
     * # Check if Apple Pay is available
     *
     * Perform a check to see if Apple Pay is available on the device
     *
     * @return [Boolean]
     */
    fun isApplePayAvailable(): Boolean {
        return applePayController.isAvailable()
    }

    /**
     * ## Start the Apple Pay Payment Process
     *
     * ### Requirements:
     * - The PaymentResultCallback must be set before starting an Apple Pay payment
     * - The PaymentProcessor must be initiated before starting an Apple Pay payment
     * - The Apple Pay Merchant ID must be provided
     * - The billing address must be provided
     * - Apple Pay must be available on the device
     * - The transaction must not have Continuous Authority Agreement set
     * - The transaction must not have Recurring Payment set
     * - The transaction must not have Deferred Payment set
     *
     * @param appleMerchantId The Apple Merchant ID
     * @param billingAddress The billing address
     * @throws IllegalArgumentException
     */
    @Throws(IllegalArgumentException::class)
    fun processApplePayPayment(appleMerchantId: String, billingAddress: BillingAddress) {
        performNullChecks()
        initResponse?.let {
            if (it.acceptPaymentMethods?.contains(AcceptPaymentMethods.APPLEPAY) == false) {
                return paymentResultCallback.onPaymentResult(Status.Error("Apple Pay Payments are not allowed"))
            }
            paymentInfo.transaction?.continuousAuthorityAgreement?.let {
                return paymentResultCallback.onPaymentResult(Status.Error("Cannot process Apple Pay with Continuous Authority Agreement"))
            }
            paymentInfo.transaction?.recurring?.let { recurring ->
                if (recurring) {
                    return paymentResultCallback.onPaymentResult(Status.Error("Cannot process Apple Pay with Recurring Payment"))
                }
            }
            paymentInfo.transaction?.deferred?.let { deferred ->
                if (deferred) {
                    return paymentResultCallback.onPaymentResult(Status.Error("Cannot process Apple Pay with Deferred Payment"))
                }
            }
        }
        if (isApplePayAvailable()) {
            applePayController.setApplePayIntent(initResponse!!.applePay!!)
            applePayController.pay(appleMerchantId, billingAddress)
        } else {
            paymentResultCallback.onPaymentResult(Status.Error("Apple Pay is not available on this device"))
        }
    }

    /**
     * Process bank payment
     *
     * TODO: Remove internal modifier after payment method is complete
     *
     * @throws IllegalArgumentException
     * @param billingAddress
     */
    @Throws(IllegalArgumentException::class)
    internal fun processBankPayment(billingAddress: BillingAddress?) {
        performNullChecks()
        initResponse?.let {
            if (it.acceptPaymentMethods?.contains(AcceptPaymentMethods.OPENBANKING) == false) {
                paymentResultCallback.onPaymentResult(Status.Error("Open Banking Payments are not allowed"))
                return
            }
        }
        openBankingController.processBankPayment(billingAddress)
    }

    actual companion object {
        internal actual fun newInstance(
            context: Any?,
            paymentConfig: PaymentConfig
        ): PaymentProcessor {
            return PaymentProcessor(paymentConfig)
        }

        internal actual fun newInstance(
            context: Any?,
            paymentConfig: PaymentConfig,
            onPaymentSuccess: PaymentProcessor.() -> Unit,
            onPaymentFailed: PaymentProcessor.(String) -> Unit,
            onPaymentMethodCanceled: PaymentProcessor.() -> Unit,
            onCardSubmittedSuccessfully: PaymentProcessor.() -> Unit,
            onCardSubmittedWithErrors: PaymentProcessor.(Array<CardError>) -> Unit,
            onInitiate: PaymentProcessor.(Status) -> Unit
        ): PaymentProcessor {
            return newInstance(context, paymentConfig).apply {
                setPaymentResultCallback(
                    onPaymentSuccess = { onPaymentSuccess() },
                    onPaymentFailed = { onPaymentFailed(it) },
                    onPaymentMethodCanceled = { onPaymentMethodCanceled() }
                )
                setCardCallback(
                    onCardSubmittedSuccessfully = { onCardSubmittedSuccessfully() },
                    onCardSubmittedWithErrors = { onCardSubmittedWithErrors(it) }
                )
                initiate { onInitiate(it) }
            }
        }
    }

}