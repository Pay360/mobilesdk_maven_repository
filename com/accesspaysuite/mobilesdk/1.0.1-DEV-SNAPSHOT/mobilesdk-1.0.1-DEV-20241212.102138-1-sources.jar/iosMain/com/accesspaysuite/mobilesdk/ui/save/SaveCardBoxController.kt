package com.accesspaysuite.mobilesdk.ui.save

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import platform.UIKit.UIViewController

/**
 * Save Card Box Controller
 */
object SaveCardBoxController {
    private val state = mutableStateOf(SaveCardState())

    @OptIn(ExperimentalComposeApi::class, ExperimentalMobileUI::class)
    fun make(): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            SaveCardBox(state = state.value)
        }
    }

    fun update(state: SaveCardState) {
        this.state.value = state
    }
}
