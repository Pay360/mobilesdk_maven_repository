package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.data.internal.common.DeviceInfo
import com.accesspaysuite.mobilesdk.utils.Constants.PPO_SDK_VERSION
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import platform.Foundation.NSBundle
import platform.Foundation.NSString
import platform.Foundation.NSUUID
import platform.Foundation.NSUserDefaults
import platform.Foundation.setValue
import platform.Foundation.stringWithFormat
import platform.Foundation.valueForKey
import platform.UIKit.UIDevice
import platform.UIKit.UIScreen
import kotlin.math.roundToInt

/**
 * Device info controller
 * @suppress
 */
internal actual class DeviceInfoController {

    internal actual val sdkVersion: String = PPO_SDK_VERSION

    internal actual val merchantAppName: String =
        checkPropertySet(
            property = NSBundle.mainBundle.bundleIdentifier,
            maxLength = MAX_LENGTH_MERCHANT_APP_NAME
        )

    internal actual val merchantAppVersion: String =
        checkPropertySet(
            property = NSBundle.mainBundle.infoDictionary?.get("CFBundleShortVersionString")
                .toString(),
            maxLength = MAX_LENGTH_MERCHANT_APP_VERSION
        )

    private val type: String
        get() = if (UIDevice.currentDevice.name.contains("iPhone")) TYPE_SMARTPHONE
        else if (UIDevice.currentDevice.name.contains("iPad")) TYPE_TABLET
        else TYPE_OTHER

    @OptIn(ExperimentalForeignApi::class)
    private val screenRes: String
        get() {
            val scale = UIScreen.mainScreen.scale
            val width = NSString.stringWithFormat(
                "%.0f",
                UIScreen.mainScreen.bounds.useContents { size.width * scale })
            val height = NSString.stringWithFormat(
                "%.0f",
                UIScreen.mainScreen.bounds.useContents { size.height * scale })
            return if (width > height) "${height}x${width}"
            else "${width}x${height}"
        }

    private fun checkPropertySet(property: String?, maxLength: Int): String {
        // return "unknown" if property not set
        var newProperty = property
        return if (newProperty.isNullOrBlank()) {
            PROPERTY_UNKNOWN
        } else {
            // check max length
            if (newProperty.length > maxLength) {
                newProperty = newProperty.substring(0, maxLength)
            }
            newProperty
        }
    }

    private val installId: String
        get() {
            val userDefaults = NSUserDefaults.standardUserDefaults
            var value: String? = userDefaults.valueForKey(PPO_UNIQUE_IDENTIFIER) as String?
            return if (!value.isNullOrEmpty()) value
            else {
                value = NSUUID.UUID().UUIDString
                userDefaults.setValue(value = value, forKey = PPO_UNIQUE_IDENTIFIER)
                value
            }
        }

    /**
     * To device info
     *
     * @return
     */
    internal actual fun toDeviceInfo(): DeviceInfo = DeviceInfo(
        sdkVersion = sdkVersion,
        merchantAppName = merchantAppName,
        merchantAppVersion = merchantAppVersion,
        manufacturer = "Apple",
        modelName = UIDevice.currentDevice.name,
        modelFamily = UIDevice.currentDevice.model,
        type = type,
        screenDpi = (UIScreen.mainScreen.scale * 160).roundToInt().toString(),
        screenRes = screenRes,
        osFamily = "IOS",
        osName = "iOS ${UIDevice.currentDevice.systemVersion}",
        sdkInstallId = installId
    )

    companion object {
        private const val PROPERTY_UNKNOWN = "unknown"
        private const val MAX_LENGTH_MERCHANT_APP_NAME = 256
        private const val MAX_LENGTH_MERCHANT_APP_VERSION = 32

        private const val TYPE_SMARTPHONE = "SMARTPHONE"
        private const val TYPE_TABLET = "TABLET"
        private const val TYPE_OTHER = "OTHER"

        private const val PPO_UNIQUE_IDENTIFIER = "ppo_unique_identifier"
    }

}