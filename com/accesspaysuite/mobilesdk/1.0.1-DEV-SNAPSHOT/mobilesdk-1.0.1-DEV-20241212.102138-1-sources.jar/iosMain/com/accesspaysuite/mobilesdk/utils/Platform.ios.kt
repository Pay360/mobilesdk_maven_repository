package com.accesspaysuite.mobilesdk.utils

import io.github.alexzhirkevich.cupertino.adaptive.Theme

internal actual fun determineTheme(): Theme = Theme.Cupertino