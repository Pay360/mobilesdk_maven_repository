package com.accesspaysuite.mobilesdk.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.window.ComposeUIViewController
import platform.UIKit.UIApplication
import platform.UIKit.UIModalPresentationOverFullScreen
import platform.UIKit.UINavigationController
import platform.UIKit.UITabBarController
import platform.UIKit.UIViewController
import platform.UIKit.UIWindow
import platform.UIKit.modalInPresentation


/**
 * Compose controller
 *
 * @param content
 * @receiver
 * @return
 */
@OptIn(ExperimentalComposeApi::class)
internal fun composeController(
    content: @Composable (onDismiss: () -> Unit) -> Unit,
): UIViewController {
    var dismissCallback: () -> Unit by mutableStateOf({})
    return ComposeUIViewController(
        configure = {
            opaque = false
        }
    ) {
        content(dismissCallback)
    }.also {
        dismissCallback = { it.dismissViewControllerAnimated(true, null) }
    }
}

/**
 * Present modal view controller
 *
 * @param controller
 * @param onCompletion
 */
internal fun presentModalViewController(
    controller: UIViewController,
    onCompletion: (() -> Unit)? = null
) {
    val navController = UINavigationController(controller).apply {
        modalPresentationStyle = UIModalPresentationOverFullScreen
        setNavigationBarHidden(true)
        modalInPresentation = true
    }
    presentViewController(
        controller = navController,
        onCompletion = onCompletion
    )
}


/**
 * Present view controller
 *
 * @param controller
 * @param base
 * @param onCompletion
 */
internal fun presentViewController(
    controller: UIViewController,
    base: UIViewController? = null,
    onCompletion: (() -> Unit)? = null
) {
    (base ?: UIApplication.topViewController())?.presentViewController(
        viewControllerToPresent = controller,
        animated = true,
        completion = onCompletion
    )
}

/**
 * Top view controller
 *
 * @param base
 * @return
 */
internal fun UIApplication.Companion.topViewController(
    base: UIViewController? = UIApplication.sharedApplication.windows.map { it as UIWindow }.first { it.isKeyWindow() }.rootViewController
): UIViewController? {
    base?.let {
        println(it)
    }
    if (base is UINavigationController) {
        return topViewController(base.visibleViewController)
    }
    if (base is UITabBarController) {
        return topViewController(base.selectedViewController)
    }
    base?.presentedViewController?.let {
        return topViewController(it)
    }
    return base
}


