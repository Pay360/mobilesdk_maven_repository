package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import platform.UIKit.UIViewController

/**
 * CardInputController
 */
object CardInputController {
    private val state = mutableStateOf(CardInputStyleState())
    @OptIn(ExperimentalComposeApi::class, ExperimentalMobileUI::class)
    fun make(
    ): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            CardInput(
                state = state.value,
            )
        }
    }

    fun update(state: CardInputStyleState) {
        this.state.value = state
    }
}