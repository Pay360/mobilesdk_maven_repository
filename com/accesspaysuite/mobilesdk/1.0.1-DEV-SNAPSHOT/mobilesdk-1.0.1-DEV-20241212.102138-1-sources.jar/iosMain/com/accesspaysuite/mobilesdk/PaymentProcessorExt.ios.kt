package com.accesspaysuite.mobilesdk

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.CardError

/**
 * Payment Processor
 *
 * @param paymentConfig
 * @return [PaymentProcessor]
 */
@Composable
actual fun rememberPaymentProcessor(
    paymentConfig: PaymentConfig
): PaymentProcessor {
    var paymentProcessor by remember {
        mutableStateOf(PaymentProcessor.newInstance(paymentConfig = paymentConfig))
    }
    DisposableEffect(paymentConfig) {
        paymentProcessor = PaymentProcessor.newInstance(paymentConfig = paymentConfig)
        onDispose {
            paymentProcessor.detach()
        }
    }
    return paymentProcessor
}

/**
 * Payment Processor
 *
 * @param paymentConfig
 * @param onPaymentSuccess
 * @param onPaymentFailed
 * @param onPaymentMethodCanceled
 * @param onCardSubmittedSuccessfully
 * @param onCardSubmittedWithErrors
 * @param onInitiate
 * @return [PaymentProcessor]
 */
@Composable
actual fun rememberPaymentProcessor(
    paymentConfig: PaymentConfig,
    onPaymentSuccess: PaymentProcessor.() -> Unit,
    onPaymentFailed: PaymentProcessor.(String) -> Unit,
    onPaymentMethodCanceled: PaymentProcessor.() -> Unit,
    onCardSubmittedSuccessfully: PaymentProcessor.() -> Unit,
    onCardSubmittedWithErrors: PaymentProcessor.(Array<CardError>) -> Unit,
    onInitiate: PaymentProcessor.(Status) -> Unit
): PaymentProcessor {
    var paymentProcessor by remember {
        mutableStateOf(
            PaymentProcessor.newInstance(
                paymentConfig = paymentConfig,
                onPaymentSuccess = onPaymentSuccess,
                onPaymentFailed = onPaymentFailed,
                onPaymentMethodCanceled = onPaymentMethodCanceled,
                onCardSubmittedSuccessfully = onCardSubmittedSuccessfully,
                onCardSubmittedWithErrors = onCardSubmittedWithErrors,
                onInitiate = onInitiate
            )
        )
    }
    DisposableEffect(paymentConfig) {
        paymentProcessor = PaymentProcessor.newInstance(
            paymentConfig = paymentConfig,
            onPaymentSuccess = onPaymentSuccess,
            onPaymentFailed = onPaymentFailed,
            onPaymentMethodCanceled = onPaymentMethodCanceled,
            onCardSubmittedSuccessfully = onCardSubmittedSuccessfully,
            onCardSubmittedWithErrors = onCardSubmittedWithErrors,
            onInitiate = onInitiate
        )
        onDispose {
            paymentProcessor.detach()
        }
    }
    return paymentProcessor
}