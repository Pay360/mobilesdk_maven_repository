package com.accesspaysuite.mobilesdk.ui.billing

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import platform.UIKit.UIViewController

/**
 * Billing Address Controller
 */
object BillingAddressController {
    private val state = mutableStateOf(BillingAddressState())

    @OptIn(ExperimentalComposeApi::class, ExperimentalMobileUI::class)
    fun make(): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            BillingAddressComponent(
                state = state.value
            )
        }
    }

    fun update(state: BillingAddressState) {
        this.state.value = state
    }
}