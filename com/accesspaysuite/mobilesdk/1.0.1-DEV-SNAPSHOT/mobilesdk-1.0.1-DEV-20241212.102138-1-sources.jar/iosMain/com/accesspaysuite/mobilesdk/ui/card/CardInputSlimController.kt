package com.accesspaysuite.mobilesdk.ui.card

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import com.accesspaysuite.mobilesdk.ui.ExperimentalMobileUI
import platform.UIKit.UIViewController

/**
 * Card Input Slim Controller
 */
object CardInputSlimController {
    private val state = mutableStateOf(CardInputSlimStyleState())

    @OptIn(ExperimentalComposeApi::class, ExperimentalMobileUI::class)
    fun make(
    ): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            CardInputSlim(
                state = state.value
            )
        }
    }

    fun update(state: CardInputSlimStyleState) {
        this.state.value = state
    }
}