@file:Suppress("unused")

package com.accesspaysuite.mobilesdk

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.data.Status
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.ui.standalone.PaymentPageContent
import com.accesspaysuite.mobilesdk.utils.composeController
import com.accesspaysuite.mobilesdk.utils.presentModalViewController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Standalone Payment Page
 *
 * This class is used to display a standalone payment page
 * that can be used to process payments.
 *
 * Initialization:
 * ```swift
 * var paymentPage = PaymentPage()
 * ```
 *
 * Setup:
 * ```swift
 * // config is type of PaymentConfig
 * paymentPage.setConfiguration(config: config)
 * // billingAddress is type of BillingAddress
 * // billingAddress can be null if the PaymentPlatform used is Evolve or SBS
 * paymentPage.setBillingAddress(billingAddress: billingAddress)
 * paymentPage.setResultCallback {
 *     // Payment Success
 * } onPaymentFailed: { reason in
 *     // Payment Failed (with reason)
 * } onPaymentCanceled: {
 *     // Payment Canceled by user
 * }
 * // Optionally (if you want to set the merchant name)
 * paymentPage.setMerchantName(name: "Merchant Name")
 * ```
 * Launch: (Display the payment page)
 * ```swift
 * // Display the payment page
 * paymentPage.display()
 * // Optionally you can handle the displaying of the payment page manually
 * // by using the uiController property
 * let uiController: UIViewController = paymentPage.uiController
 *
 * ```
 * @constructor Create a Standalone Payment Page
 * @property billing The billing address to be used for the payment
 * @property config The payment configuration
 * @property merchantName The name of the merchant
 * @property resultCallback The callback to be called when the payment is completed
 */
class PaymentPage {
    private var billing = mutableStateOf<BillingAddress?>(null)

    // A copy of the billing address provided by payment config
    // Used to fall back when the users opts out from using a different
    // billing address other than the one provided already
    private var originalBilling = mutableStateOf<BillingAddress?>(null)
    private var merchantName: String? = null
    private var config: PaymentConfig? by mutableStateOf(null)

    private var resultCallback: PaymentResultCallback? = null
    private var paymentProcessor: PaymentProcessor? by mutableStateOf(null)

    private val scope = CoroutineScope(Job() + Dispatchers.IO)

    /**
     * Set the payment configuration
     */
    fun setConfiguration(config: PaymentConfig) {
        this.config = config
    }

    /**
     * Set the billing address
     */
    fun setBillingAddress(billingAddress: BillingAddress) {
        billing.value = billingAddress
    }

    /**
     * Set the merchant name
     */
    fun setMerchantName(name: String) {
        this.merchantName = name
    }

    /**
     * Set the result callback
     */
    fun setResultCallback(paymentResultCallback: PaymentResultCallback) {
        this.resultCallback = paymentResultCallback
    }

    /**
     * Overload Function to set the result callback
     */
    fun setResultCallback(
        onPaymentSuccess: () -> Unit,
        onPaymentFailed: (String) -> Unit,
        onPaymentCanceled: () -> Unit
    ) {
        resultCallback = object : PaymentResultCallback {
            override fun onPaymentResult(status: Status) {
                when (status) {
                    is Status.Success -> onPaymentSuccess()
                    is Status.Error -> onPaymentFailed(status.message)
                    is Status.Canceled -> onPaymentCanceled()
                    else -> Unit
                }
            }
        }
    }

    /**
     * Display the PaymentPage
     */
    fun display() = presentModalViewController(controller = uiController)

    private fun initProcessor(config: PaymentConfig) {
        paymentProcessor = PaymentProcessor(config = config)

        paymentProcessor?.initiate {
            // No need to pass processor again
            // since it's a mutable state and
            // the UI will be updated accordingly
            originalBilling.value = billing.value
        }
    }

    /**
     * UIViewController
     *
     * Optionally you can handle the displaying of the payment page manually
     * by using the uiController property
     */
    @Suppress("MemberVisibilityCanBePrivate")
    val uiController get() = composeController { dismissCallback ->
        PaymentPageContent(
            billingAddress = billing,
            origBillingAddress = originalBilling,
            merchantName = merchantName,
            onPaymentFailed = {
                resultCallback?.onPaymentResult(Status.Error(it.toString()))
                dismissCallback()
            },
            onPaymentSuccess = {
                resultCallback?.onPaymentResult(Status.Success)
                dismissCallback()
            },
            onPaymentCanceled = {
                resultCallback?.onPaymentResult(Status.Canceled)
                dismissCallback()
            }
        )
        LaunchedEffect(Unit) {
            scope.launch(Dispatchers.IO) {
                while (config == null) {
                    delay(100)
                }
                withContext(Dispatchers.Main) {
                    initProcessor(config!!)
                }
            }
        }
    }

}