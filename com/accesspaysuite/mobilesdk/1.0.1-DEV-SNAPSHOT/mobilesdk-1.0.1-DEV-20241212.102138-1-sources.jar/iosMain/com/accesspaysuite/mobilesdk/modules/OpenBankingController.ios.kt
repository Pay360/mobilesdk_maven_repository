package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.PaymentResultCallback
import com.accesspaysuite.mobilesdk.data.common.BillingAddress
import com.accesspaysuite.mobilesdk.data.internal.openbanking.OpenBanking.Companion.TEST_RETURN_URL
import com.accesspaysuite.mobilesdk.repository.RequestRepository
import com.accesspaysuite.mobilesdk.utils.presentViewController
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import platform.CoreGraphics.CGRectMake
import platform.Foundation.NSURL
import platform.Foundation.NSURLRequest
import platform.UIKit.UIAdaptivePresentationControllerDelegateProtocol
import platform.UIKit.UIPresentationController
import platform.UIKit.UIScreen
import platform.UIKit.UISheetPresentationControllerDetent
import platform.UIKit.UIViewController
import platform.UIKit.sheetPresentationController
import platform.WebKit.WKContentMode
import platform.WebKit.WKDataDetectorTypeNone
import platform.WebKit.WKNavigationAction
import platform.WebKit.WKNavigationActionPolicy
import platform.WebKit.WKNavigationDelegateProtocol
import platform.WebKit.WKPreferences
import platform.WebKit.WKWebView
import platform.WebKit.WKWebViewConfiguration
import platform.WebKit.WKWebpagePreferences
import platform.WebKit.javaScriptEnabled

@OptIn(ExperimentalForeignApi::class)
internal actual class OpenBankingController actual constructor(
    repository: RequestRepository,
    deviceInfoController: DeviceInfoController,
    delegate: PaymentResultCallback
) : OpenBankingControllerCommon(repository, deviceInfoController, delegate) {

    private val iosScope = CoroutineScope(Dispatchers.Main.immediate)

    actual fun processBankPayment(billingAddress: BillingAddress?) {
        preProcessBankPayment(billingAddress) { paymentUrl ->
            iosScope.launch {
                launchWebView(paymentUrl)
            }
        }
    }

    private fun launchWebView(
        url: String
    ) {
        val width = UIScreen.mainScreen().bounds().useContents { size.width }
        val height = UIScreen.mainScreen().bounds().useContents { size.height }
        val configuration = WKWebViewConfiguration().apply {
            suppressesIncrementalRendering = true
            ignoresViewportScaleLimits = false
            preferences = WKPreferences().apply {
                javaScriptEnabled = true
                textInteractionEnabled = true
            }
            defaultWebpagePreferences = WKWebpagePreferences().apply {
                allowsContentJavaScript = true
                preferredContentMode = WKContentMode.WKContentModeMobile
            }
            dataDetectorTypes = WKDataDetectorTypeNone
        }
        val frame = CGRectMake(0.0, 0.0, width, height)
        frame.useContents {
            size.height = height
            size.width = width
        }

        val controller = WebViewController(TEST_RETURN_URL) { isCancelled ->
            postProcessBankPayment(isCancelled)
        }
        val webView = WKWebView(frame, configuration).apply {
            navigationDelegate = controller
        }
        presentViewController(
            controller = controller.getPresentable(webView)
        )
        webView.loadRequest(NSURLRequest.requestWithURL(NSURL.URLWithString(url)!!))
    }

    private class WebViewController(
        private val returnUrl: String,
        private val onDismiss: (Boolean) -> Unit
    ) : UIViewController(null, null), WKNavigationDelegateProtocol,
        UIAdaptivePresentationControllerDelegateProtocol {

        private var webView: WKWebView? = null

        fun getPresentable(webView: WKWebView): WebViewController {
            sheetPresentationController?.apply {
                detents = listOf(UISheetPresentationControllerDetent.largeDetent())
                this@WebViewController.webView = webView
                setView(webView)
                delegate = this@WebViewController
            }
            return this
        }

        override fun webView(
            webView: WKWebView,
            decidePolicyForNavigationAction: WKNavigationAction,
            decisionHandler: (WKNavigationActionPolicy) -> Unit,
        ) {
            if (decidePolicyForNavigationAction.request.URL!!.absoluteString!! == returnUrl) {
                webView.dismiss(false)
            }
            decisionHandler(WKNavigationActionPolicy.WKNavigationActionPolicyAllow)
        }

        private fun WKWebView.dismiss(
            isCancelled: Boolean
        ) {
            stopLoading()
            onDismiss(isCancelled)
            dismissModalViewControllerAnimated(true)
        }

        override fun presentationControllerDidDismiss(presentationController: UIPresentationController) {
            webView?.stopLoading()
            onDismiss(true)
        }

    }

}
