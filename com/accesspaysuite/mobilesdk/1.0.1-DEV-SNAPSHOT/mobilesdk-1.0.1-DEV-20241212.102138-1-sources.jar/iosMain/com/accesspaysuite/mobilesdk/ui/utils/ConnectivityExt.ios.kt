package com.accesspaysuite.mobilesdk.ui.utils

import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import dev.tmapps.konnection.Konnection
import dev.tmapps.konnection.NetworkConnection
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.map

@Composable
@ExperimentalCoroutinesApi
internal actual fun connectivityState(): State<ConnectionState> {
    return remember { Konnection(enableDebugLog = false) }
        .observeNetworkConnection().map {
        when(it) {
            NetworkConnection.WIFI, NetworkConnection.MOBILE -> ConnectionState.Available
            null -> ConnectionState.Unavailable
        }
    }.collectAsState(initial = ConnectionState.Available)
}