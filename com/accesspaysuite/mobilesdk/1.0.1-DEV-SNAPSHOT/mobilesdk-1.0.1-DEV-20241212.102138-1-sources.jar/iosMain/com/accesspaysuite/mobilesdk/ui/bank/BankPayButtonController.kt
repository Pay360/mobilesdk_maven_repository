package com.accesspaysuite.mobilesdk.ui.bank

import androidx.compose.runtime.ExperimentalComposeApi
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.window.ComposeUIViewController
import platform.UIKit.UIViewController

/**
 * BankPayButtonController
 */
internal object BankPayButtonController {
    private val state = mutableStateOf(BankPayState())
    @OptIn(ExperimentalComposeApi::class)
    fun make(): UIViewController {
        return ComposeUIViewController(
            configure = {
                opaque = false
            }
        ) {
            BankPayButton(
                state = state.value
            )
        }
    }

    fun update(state: BankPayState) {
        this.state.value = state
    }
}