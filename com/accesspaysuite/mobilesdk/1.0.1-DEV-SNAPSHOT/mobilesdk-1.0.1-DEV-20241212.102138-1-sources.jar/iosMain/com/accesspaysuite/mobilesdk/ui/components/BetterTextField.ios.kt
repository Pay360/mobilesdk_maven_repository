package com.accesspaysuite.mobilesdk.ui.components

import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.TextSelectionColors
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.OutlinedTextFieldDefaults.Container
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import io.github.alexzhirkevich.LocalContentColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal actual fun BetterTextField(
    modifier: Modifier,
    value: String,
    onValueChange: (String) -> Unit,
    keyboardOptions: KeyboardOptions,
    textStyle: TextStyle,
    isEnabled: Boolean,
    isError: Boolean,
    isOutlined: Boolean,
    singleLine: Boolean,
    shape: Shape,
    borderColor: Color,
    placeholder: @Composable (() -> Unit)?,
    label: @Composable (() -> Unit)?,
    trailingIcon: @Composable (() -> Unit)?,
    interactionSource: MutableInteractionSource,
    visualTransformation: VisualTransformation,
    contentPadding: PaddingValues
) {
    val surfaceColor = Color.Transparent
    val onSurfaceColor = LocalContentColor.current
    val errorColor = MaterialTheme.colorScheme.error


    val colors = if (isOutlined) {
        OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = surfaceColor,
            focusedContainerColor = surfaceColor,
            errorContainerColor = surfaceColor,
            unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            focusedPlaceholderColor = onSurfaceColor.copy(alpha = 0.6f),
            disabledPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            errorPlaceholderColor = errorColor,
            errorTextColor = errorColor,
            errorLabelColor = errorColor,
            cursorColor = MaterialTheme.colorScheme.primary,
            selectionColors = TextSelectionColors(
                handleColor = MaterialTheme.colorScheme.primary,
                backgroundColor = MaterialTheme.colorScheme.scrim.copy(alpha = 0.4f)
            ),
            focusedBorderColor = borderColor,
            unfocusedBorderColor = borderColor,
            errorCursorColor = errorColor,
            focusedTextColor = onSurfaceColor,
            unfocusedTextColor = onSurfaceColor
        )
    } else {
        TextFieldDefaults.colors(
            unfocusedContainerColor = surfaceColor,
            focusedContainerColor = surfaceColor,
            errorContainerColor = surfaceColor,
            unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            focusedPlaceholderColor = onSurfaceColor.copy(alpha = 0.6f),
            disabledPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
            errorPlaceholderColor = errorColor,
            errorTextColor = errorColor,
            errorLabelColor = errorColor,
            focusedIndicatorColor = Color.Transparent,
            errorIndicatorColor = errorColor,
            disabledIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            cursorColor = MaterialTheme.colorScheme.primary,
            selectionColors = TextSelectionColors(
                handleColor = MaterialTheme.colorScheme.primary,
                backgroundColor = MaterialTheme.colorScheme.scrim.copy(alpha = 0.4f)
            ),
            errorCursorColor = MaterialTheme.colorScheme.error,
            focusedTextColor = onSurfaceColor,
            unfocusedTextColor = onSurfaceColor
        )
    }

    BasicTextField(
        modifier = modifier
            .then(
                if (label != null) Modifier
                    .semantics(mergeDescendants = true) {}
                    .padding(top = 8.dp)
                else Modifier
            ),
        value = value,
        textStyle = textStyle,
        onValueChange = onValueChange,
        visualTransformation = visualTransformation,
        interactionSource = interactionSource,
        keyboardOptions = keyboardOptions,
        singleLine = singleLine,
        cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
    ) { innerTextField ->
        if (isOutlined) {
            OutlinedTextFieldDefaults.DecorationBox(
                value = value,
                innerTextField = innerTextField,
                enabled = isEnabled,
                singleLine = singleLine,
                visualTransformation = visualTransformation,
                interactionSource = interactionSource,
                colors = colors,
                isError = isError,
                placeholder = placeholder,
                contentPadding = contentPadding,
                label = label,
                trailingIcon = trailingIcon,
                container = {
                    Container(
                        enabled = isEnabled,
                        isError = isError,
                        interactionSource = interactionSource,
                        colors = colors,
                        shape = shape,
                    )
                }
            )
        } else {
            TextFieldDefaults.DecorationBox(
                value = value,
                innerTextField = innerTextField,
                enabled = isEnabled,
                singleLine = singleLine,
                visualTransformation = visualTransformation,
                interactionSource = interactionSource,
                colors = colors,
                isError = isError,
                placeholder = placeholder,
                contentPadding = contentPadding,
                label = label,
                trailingIcon = trailingIcon,
                shape = shape
            )
        }
    }
}