package com.accesspaysuite.mobilesdk.modules

import com.accesspaysuite.mobilesdk.callbacks.internal.ThreeDSResultCallback
import com.accesspaysuite.mobilesdk.data.internal.common.PaymentType
import com.accesspaysuite.mobilesdk.data.internal.common.ThreeDSResponse
import com.accesspaysuite.mobilesdk.data.internal.response.PaymentResponseThreeDSRedirect
import com.accesspaysuite.mobilesdk.utils.presentViewController
import kotlinx.cinterop.BetaInteropApi
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import platform.CoreGraphics.CGRectMake
import platform.Foundation.HTTPBody
import platform.Foundation.NSCharacterSet
import platform.Foundation.NSData
import platform.Foundation.NSMutableURLRequest
import platform.Foundation.NSString
import platform.Foundation.NSURL
import platform.Foundation.NSUTF8StringEncoding
import platform.Foundation.URLQueryAllowedCharacterSet
import platform.Foundation.componentsSeparatedByString
import platform.Foundation.containsString
import platform.Foundation.create
import platform.Foundation.dataUsingEncoding
import platform.Foundation.setHTTPBody
import platform.Foundation.setHTTPMethod
import platform.Foundation.setValue
import platform.Foundation.stringByAddingPercentEncodingWithAllowedCharacters
import platform.Foundation.stringByRemovingPercentEncoding
import platform.Foundation.stringWithFormat
import platform.UIKit.UIAdaptivePresentationControllerDelegateProtocol
import platform.UIKit.UIPresentationController
import platform.UIKit.UIScreen
import platform.UIKit.UISheetPresentationControllerDetent
import platform.UIKit.UIViewController
import platform.UIKit.sheetPresentationController
import platform.WebKit.WKContentMode
import platform.WebKit.WKDataDetectorTypeNone
import platform.WebKit.WKNavigationAction
import platform.WebKit.WKNavigationActionPolicy
import platform.WebKit.WKNavigationDelegateProtocol
import platform.WebKit.WKPreferences
import platform.WebKit.WKWebView
import platform.WebKit.WKWebViewConfiguration
import platform.WebKit.WKWebpagePreferences
import platform.WebKit.javaScriptEnabled

@OptIn(ExperimentalForeignApi::class)
@Suppress("CAST_NEVER_SUCCEEDS")
internal actual class ThreeDSController {

    private val scope = CoroutineScope(Dispatchers.Main.immediate)

    /**
     * Run 3DS process
     *
     * @param delegate
     * @param paymentType
     * @param params
     */
    internal actual fun run3DSProcess(
        delegate: ThreeDSResultCallback,
        paymentType: PaymentType,
        params: PaymentResponseThreeDSRedirect
    ) {
        scope.launch {
            val acsUrl = params.acsUrl
            val md = params.md
            val termUrl = params.termUrl
            val pareq = params.pareq
            val notificationUrl = params.notificationUrl
            val threeDSServerTransId = params.threeDSServerTransId
            //val sessionTimeout = params.sessionTimeout
            //val passiveTimeout = params.passiveTimeout
            val isThreeDSv1 = notificationUrl.isEmpty() || threeDSServerTransId.isEmpty()

            val reqUrl = NSURL.URLWithString(acsUrl)
            val requestBody: NSData = (if (isThreeDSv1) {
                (NSString.stringWithFormat(
                    "TermUrl=%@&MD=%@&PaReq=%@",
                    termUrl!!.encode(), md.encode(), pareq!!.encode()
                ) as NSString)
            } else {
                (NSString.stringWithFormat(
                    "notificationUrl=%@&MD=%@&transactionId=%@",
                    notificationUrl.encode(), md.encode(), threeDSServerTransId.encode()
                ) as NSString)
            }).dataUsingEncoding(NSUTF8StringEncoding)!!


            val request = NSMutableURLRequest(uRL = reqUrl!!).apply {
                setValue("application/x-www-form-urlencoded", forHTTPHeaderField = "Content-Type")
                setValue(
                    NSString.stringWithFormat("%ld", requestBody.length),
                    forHTTPHeaderField = "Content-Length"
                )
                setValue(
                    "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                    forHTTPHeaderField = "Accept"
                )
                setHTTPMethod("POST")
                setHTTPBody(requestBody)
            }

            launchWebView(delegate, params, paymentType, request)
        }
    }

    private fun launchWebView(
        delegate: ThreeDSResultCallback,
        params: PaymentResponseThreeDSRedirect,
        paymentType: PaymentType,
        request: NSMutableURLRequest
    ) {
        val width = UIScreen.mainScreen().bounds().useContents { size.width }
        val height = UIScreen.mainScreen().bounds().useContents { size.height }
        val configuration = WKWebViewConfiguration().apply {
            suppressesIncrementalRendering = true
            ignoresViewportScaleLimits = false
            preferences = WKPreferences().apply {
                javaScriptEnabled = true
                textInteractionEnabled = true
            }
            defaultWebpagePreferences = WKWebpagePreferences().apply {
                allowsContentJavaScript = true
                preferredContentMode = WKContentMode.WKContentModeMobile
            }
            dataDetectorTypes = WKDataDetectorTypeNone
        }
        val frame = CGRectMake(0.0, 0.0, width, height)
        frame.useContents {
            size.height = height
            size.width = width
        }

        val controller = WebViewController(delegate, params, paymentType)
        val webView = WKWebView(frame, configuration).apply {
            navigationDelegate = controller
        }
        presentViewController(
            controller = controller.getPresentable(webView)
        )
        webView.loadRequest(request)
    }

    private class WebViewController(
        private val delegate: ThreeDSResultCallback,
        private val params: PaymentResponseThreeDSRedirect,
        private val paymentType: PaymentType
    ) : UIViewController(null, null), WKNavigationDelegateProtocol,
        UIAdaptivePresentationControllerDelegateProtocol {

        private var webView: WKWebView? = null


        /**
         * Get presentable
         *
         * @param webView
         * @return
         */
        fun getPresentable(webView: WKWebView): WebViewController {
            sheetPresentationController?.apply {
                detents = listOf(UISheetPresentationControllerDetent.largeDetent())
                this@WebViewController.webView = webView
                setView(webView)
                delegate = this@WebViewController
            }
            return this
        }

        @OptIn(BetaInteropApi::class)
        override fun webView(
            webView: WKWebView,
            decidePolicyForNavigationAction: WKNavigationAction,
            decisionHandler: (WKNavigationActionPolicy) -> Unit,
        ) {
            if (decidePolicyForNavigationAction.request.URL!!.absoluteString!! == params.termUrl ||
                decidePolicyForNavigationAction.request.URL!!.absoluteString!! == params.notificationUrl
            ) {
                val body = decidePolicyForNavigationAction.request.HTTPBody!!
                decodeParams(
                    webView = webView,
                    delegate = delegate,
                    postData = NSString.create(body, NSUTF8StringEncoding) as NSString
                )
            }
            decisionHandler(WKNavigationActionPolicy.WKNavigationActionPolicyAllow)
        }

        private fun decodeParams(
            webView: WKWebView,
            delegate: ThreeDSResultCallback,
            postData: NSString
        ) {
            val isThreeDSv1 =
                params.notificationUrl.isEmpty() || params.threeDSServerTransId.isEmpty()
            if (isThreeDSv1) {
                var pares: String? = null
                val params = postData.componentsSeparatedByString("&")
                for (param in params) {
                    if (param is NSString && param.containsString("PaRes")) {
                        val paresEncoded = param.componentsSeparatedByString("=")[1] as NSString
                        pares = paresEncoded.stringByRemovingPercentEncoding()
                    }
                }
                webView.dismiss(delegate, ThreeDSResponse(pares))
            } else {
                webView.dismiss(delegate)
            }
        }

        private fun WKWebView.dismiss(
            delegate: ThreeDSResultCallback,
            response: ThreeDSResponse? = null
        ) {
            stopLoading()
            delegate.threeDSProcessSuccess(
                response = response,
                paymentType = paymentType
            )
            dismissModalViewControllerAnimated(true)
        }

        override fun presentationControllerDidDismiss(presentationController: UIPresentationController) {
            webView?.stopLoading()
            delegate.threeDSProcessFailure(
                reason = "Canceled",
                paymentType = paymentType
            )
        }

    }

    private fun String.encode(): NSString {
        return (this as NSString).stringByAddingPercentEncodingWithAllowedCharacters(NSCharacterSet.URLQueryAllowedCharacterSet)
            .toString() as NSString
    }

}