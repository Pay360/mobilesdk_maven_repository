@file:Suppress("unused")

package com.accesspaysuite.mobilesdk

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.accesspaysuite.mobilesdk.data.common.Environment
import com.accesspaysuite.mobilesdk.data.internal.management.CardManagementCredentials
import com.accesspaysuite.mobilesdk.ui.management.CardManagementScreen
import com.accesspaysuite.mobilesdk.utils.composeController
import com.accesspaysuite.mobilesdk.utils.presentModalViewController

/**
 * Card Management Page
 *
 * This class is used to display a card management page
 * that can be used to manage cards.
 *
 **/
class CardManagementPage {
    private var username: String by mutableStateOf("")
    private var password: String by mutableStateOf("")
    private var installationId: String by mutableStateOf("")
    private var environment: Environment by mutableStateOf(Environment.TEST)
    private var customerReference: String by mutableStateOf("")


    /**
     * Set the username and password for the CardManagementPage
     */
    fun setCredentials(
        username: String,
        password: String,
        installationId: String,
        environment: Environment
    ) {
        this.username = username
        this.password = password
        this.installationId = installationId
        this.environment = environment
    }

    /**
     * Set the customer reference for the CardManagementPage
     */
    fun setCustomerReference(customerReference: String) {
        this.customerReference = customerReference
    }

    /**
     * Display the CardManagementPage
     */
    fun display() = presentModalViewController(controller = uiController)

    /**
     * UIViewController
     *
     * Optionally you can handle the displaying of the payment page manually
     * by using the uiController property
     */
    @Suppress("MemberVisibilityCanBePrivate")
    val uiController get() = composeController { dismissCallback ->
        CardManagementScreen(
            credentials = CardManagementCredentials(
                username = username,
                password = password,
                installationId = installationId,
                environment = environment,
            ),
            customerReference = customerReference,
            onBackPress = dismissCallback
        )
    }

}